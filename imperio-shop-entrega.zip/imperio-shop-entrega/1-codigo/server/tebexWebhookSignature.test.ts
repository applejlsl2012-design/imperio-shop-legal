import crypto from "node:crypto";
import { describe, expect, it } from "vitest";
import { verifyTebexSignature } from "./tebex";

/**
 * Firma de los avisos de pago de Tebex.
 *
 * Esta es la prueba que confirma que el secreto del webhook quedó bien
 * cargado: sin la firma correcta, la web rechaza cualquier aviso de pago y
 * jamás marca un pedido como pagado por un mensaje falso.
 *
 * Algoritmo de Tebex: HMAC-SHA256( campo SHA256 en hex del cuerpo crudo, secreto ).
 */
function firmar(cuerpo: string, secreto: string): string {
  const hash = crypto.createHash("sha256").update(cuerpo, "utf-8").digest("hex");
  return crypto.createHmac("sha256", secreto).update(hash, "utf-8").digest("hex");
}

describe("firma del webhook de Tebex", () => {
  const secreto = process.env.TEBEX_WEBHOOK_SECRET ?? "";
  const cuerpo = JSON.stringify({
    id: "evt_1",
    type: "payment.completed",
    subject: { transaction_id: "tx_123", status: "Complete" },
  });

  it("el secreto del webhook está configurado", () => {
    // Sin secreto no se puede comprobar el origen de un aviso de pago.
    expect(secreto.length).toBeGreaterThan(10);
  });

  it("acepta la firma correcta calculada con el secreto real", () => {
    const firma = firmar(cuerpo, secreto);
    expect(verifyTebexSignature(cuerpo, firma)).toBe(true);
  });

  it("rechaza una firma inventada", () => {
    const falsa = firmar(cuerpo, "secreto-que-no-es");
    expect(verifyTebexSignature(cuerpo, falsa)).toBe(false);
  });

  it("rechaza un cuerpo alterado con firma vieja", () => {
    const firma = firmar(cuerpo, secreto);
    const alterado = cuerpo.replace("tx_123", "tx_999");
    expect(verifyTebexSignature(alterado, firma)).toBe(false);
  });

  it("rechaza cuando no hay firma", () => {
    expect(verifyTebexSignature(cuerpo, "")).toBe(false);
  });
});