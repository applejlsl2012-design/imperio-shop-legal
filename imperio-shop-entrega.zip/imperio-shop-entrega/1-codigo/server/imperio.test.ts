import { describe, expect, it, vi } from "vitest";

vi.mock("./_core/sdk", () => ({
  sdk: {
    exchangeCodeForToken: vi.fn(async () => ({ accessToken: "token-de-prueba" })),
    getUserInfo: vi.fn(async () => ({
      openId: "openid-de-prueba",
      name: "Cliente Google",
      email: "cliente.google@ejemplo.com",
      loginMethod: "google",
      platform: "google",
    })),
  },
}));

vi.mock("./db", async (importOriginal) => {
  const actual = await importOriginal<typeof import("./db")>();
  return {
    ...actual,
    getCatalog: vi.fn(async () => [
      {
        id: 1,
        slug: "bots-discord",
        name: "Bots de Discord",
        tagline: "Bots a medida",
        description: "Descripción",
        imageUrl: "/manus-storage/service-bots.jpg",
        icon: "bot",
        badge: "Más vendido",
        accent: "#FF1F3D",
        features: JSON.stringify(["Código fuente", "Tickets"]),
        deliveryTime: "24 a 72 horas",
        sortOrder: 1,
        active: true,
        createdAt: new Date(),
        updatedAt: new Date(),
        plans: [
          {
            id: 10,
            serviceId: 1,
            name: "Bot Avanzado",
            priceCents: 3500,
            currency: "USD",
            billing: "once" as const,
            summary: "El más pedido",
            specs: JSON.stringify(["Tickets"]),
            features: JSON.stringify(["Soporte"]),
            popular: true,
            stockLabel: "Disponible",
            sortOrder: 1,
            active: true,
            createdAt: new Date(),
            updatedAt: new Date(),
          },
        ],
      },
    ]),
    getSettingsMap: vi.fn(async () => ({ "brand.name": "Imperio Shop" })),
    getPlanById: vi.fn(async (id: number) =>
      id === 10
        ? {
            id: 10,
            serviceId: 1,
            name: "Bot Avanzado",
            priceCents: 3500,
            currency: "USD",
            billing: "once" as const,
            summary: "",
            specs: "[]",
            features: "[]",
            popular: true,
            stockLabel: "",
            sortOrder: 1,
            active: true,
            createdAt: new Date(),
            updatedAt: new Date(),
          }
        : undefined,
    ),
    getServiceById: vi.fn(async () => ({ id: 1, name: "Bots de Discord" })),
    createOrder: vi.fn(async () => 1),
    updateOrderPayment: vi.fn(async () => undefined),
    getOrderByCode: vi.fn(async (code: string) =>
      code === "IMP-ABC123"
        ? {
            id: 1,
            code: "IMP-ABC123",
            serviceId: 1,
            serviceName: "Bots de Discord",
            planId: 10,
            planName: "Bot Avanzado",
            amountCents: 3500,
            currency: "USD",
            billing: "once",
            customerName: "Cliente",
            customerEmail: "cliente@ejemplo.com",
            customerDiscord: "",
            customerNote: "",
            paymentMethod: "plex",
            payerAccount: "",
            paymentReference: "",
            status: "pending_payment",
            staffNote: "",
            userId: null,
            createdAt: new Date(),
            updatedAt: new Date(),
          }
        : undefined,
    ),
    findActiveStaffCodes: vi.fn(async () => [
      { id: 1, label: "Dueño", codeHash: "", role: "owner" as const },
    ]),
    logStaffLogin: vi.fn(async () => undefined),
    touchStaffCode: vi.fn(async () => undefined),
    listStaffCodes: vi.fn(async () => []),
    listStaffLogins: vi.fn(async () => []),
    getOrderStats: vi.fn(async () => ({
      total: 0,
      pending: 0,
      review: 0,
      paid: 0,
      inProgress: 0,
      delivered: 0,
      cancelled: 0,
      revenueCents: 0,
      last30: 0,
    })),
    listOrders: vi.fn(async () => ({ rows: [], total: 0 })),
    findCustomerByEmail: vi.fn(async () => undefined),
    createCustomer: vi.fn(async () => 7),
    touchCustomer: vi.fn(async () => undefined),
    updateCustomerProfile: vi.fn(async () => undefined),
    listCustomerOrders: vi.fn(async () => []),
    listPublishedReviews: vi.fn(async () => [
      {
        id: 3,
        customerId: 7,
        authorName: "Cliente Prueba",
        authorEmail: "cliente@ejemplo.com",
        serviceId: 1,
        serviceName: "Bots de Discord",
        orderId: 1,
        rating: 5,
        comment: "Todo perfecto, muy recomendados.",
        status: "approved" as const,
        staffNote: "",
        featured: false,
        reply: "",
        publishedAt: new Date(),
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ]),
    listServiceReviews: vi.fn(async () => []),
    listCustomerReviews: vi.fn(async () => []),
    findReviewByOrder: vi.fn(async () => undefined),
    createReview: vi.fn(async () => 3),
    listReviews: vi.fn(async () => []),
    getReviewById: vi.fn(async () => undefined),
    getReviewStats: vi.fn(async () => ({
      pending: 0,
      approved: 0,
      rejected: 0,
      total: 0,
      average: 0,
    })),
    setReviewStatus: vi.fn(async () => undefined),
    setReviewFeatured: vi.fn(async () => undefined),
    setReviewReply: vi.fn(async () => undefined),
    deleteReview: vi.fn(async () => undefined),
    listCustomers: vi.fn(async () => []),
    findCustomerByOpenId: vi.fn(async () => undefined),
    upsertCustomerFromOAuth: vi.fn(async () => 9),
    getCustomerById: vi.fn(async (id: number) =>
      id === 9 || id === 7
        ? {
            id,
            email: "cliente@ejemplo.com",
            name: "Cliente Prueba",
            passwordHash: "",
            provider: id === 9 ? "google" : "email",
            manusOpenId: id === 9 ? "openid-google-123" : null,
            discord: "cliente#0001",
            active: true,
            lastSignedIn: new Date(),
            createdAt: new Date(),
          }
        : undefined,
    ),
    createVerificationCode: vi.fn(async () => 21),
    getLatestVerificationCode: vi.fn(async () => undefined),
    recordVerificationAttempt: vi.fn(async () => undefined),
    consumeVerificationCode: vi.fn(async () => undefined),
    listPendingInvitations: vi.fn(async () => []),
    cancelInvitationById: vi.fn(async () => undefined),
    setCustomerActive: vi.fn(async () => undefined),
    getInvitationStats: vi.fn(async () => ({ pending: 0, expired: 0, activated: 0 })),
  };
});

vi.mock("./seed", () => ({
  ensureSeeded: vi.fn(async () => undefined),
}));

import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import {
  codeHint,
  generateStaffCode,
  hashStaffCode,
  issueStaffToken,
  readStaffSession,
  verifyStaffCodeHash,
} from "./staffAuth";
import {
  hashPassword,
  issueCustomerToken,
  normalizeEmail,
  verifyPassword,
} from "./customerAuth";
import { generateCode, hashCode, verifyCode } from "./verification";

/** Contexto con una sesión de equipo (dueño) iniciada. */
function staffContext(role: "owner" | "staff" = "owner") {
  const ctx = publicContext();
  const token = issueStaffToken({ codeId: 1, label: "Dueño", role });
  (ctx.req as unknown as { headers: Record<string, string> }).headers = {
    cookie: `imperio_staff=${token}`,
  };
  return ctx;
}

/** Contexto con una cuenta de cliente con sesión iniciada. */
function customerContext(customerId = 7, email = "cliente@ejemplo.com") {
  const ctx = publicContext();
  const token = issueCustomerToken({ customerId, email, name: "Cliente Prueba" });
  (ctx.req as unknown as { headers: Record<string, string> }).headers = {
    cookie: `imperio_customer=${token}`,
  };
  return ctx;
}

function publicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
      cookies: {},
      ip: "127.0.0.1",
    } as unknown as TrpcContext["req"],
    res: {
      cookie: () => undefined,
      clearCookie: () => undefined,
    } as unknown as TrpcContext["res"],
  };
}

describe("catálogo público", () => {
  it("devuelve los servicios con sus planes ya parseados", async () => {
    const caller = appRouter.createCaller(publicContext());
    const result = await caller.catalog.list();

    expect(result.services).toHaveLength(1);
    expect(result.services[0].slug).toBe("bots-discord");
    expect(result.services[0].features).toEqual(["Código fuente", "Tickets"]);
    expect(result.services[0].plans[0].name).toBe("Bot Avanzado");
    expect(result.services[0].plans[0].priceCents).toBe(3500);
    expect(result.settings["brand.name"]).toBe("Imperio Shop");
  });
});

describe("pedidos", () => {
  // Esta prueba arma una canasta real en Tebex, así que necesita más tiempo
  // que una prueba común: le damos margen para que la red no la haga fallar.
  it("crea un pedido vinculado a la cuenta del cliente", { timeout: 30000 }, async () => {
    const caller = appRouter.createCaller(customerContext());
    const result = await caller.orders.create({
      planId: 10,
      details: {
        customerName: "Cliente Prueba",
        customerEmail: "cliente@ejemplo.com",
        customerDiscord: "cliente#0001",
        customerNote: "Necesito tickets",
        payerAccount: "mi-cuenta",
        paymentReference: "",
      },
    });

    expect(result.code).toMatch(/^IMP-[A-Z0-9]{6}$/);
    expect(result.amountCents).toBe(3500);
    expect(result.serviceName).toBe("Bots de Discord");
    expect(result.planName).toBe("Bot Avanzado");
  });

  it("explica cuando la cuenta existe pero no tiene contraseña", async () => {
    // Caso real: cuentas creadas a mano desde el panel, sin contraseña.
    const db = await import("./db");
    vi.mocked(db.findCustomerByEmail).mockResolvedValueOnce({
      id: 7,
      email: "sinclave@ejemplo.com",
      name: "Cuenta Sin Clave",
      passwordHash: "",
      discord: "",
      provider: "email",
      active: true,
      lastSignedIn: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    } as never);

    const caller = appRouter.createCaller(publicContext());
    await expect(
      caller.customer.login({ email: "sinclave@ejemplo.com", password: "cualquiera123" }),
    ).rejects.toThrow(/todavía no tiene contraseña/i);
  });

  it("no revela si el correo existe cuando la contraseña es incorrecta", async () => {
    // Mensaje genérico: no se puede usar el login para descubrir cuentas.
    const db = await import("./db");
    vi.mocked(db.findCustomerByEmail).mockResolvedValueOnce(undefined);

    const caller = appRouter.createCaller(publicContext());
    await expect(
      caller.customer.login({ email: "noexiste@ejemplo.com", password: "cualquiera123" }),
    ).rejects.toThrow(/Correo o contraseña incorrectos/i);
  });

  it("exige una cuenta con sesión antes de dejar comprar", async () => {
    const caller = appRouter.createCaller(publicContext());
    await expect(
      caller.orders.create({
        planId: 10,
        details: {
          customerName: "Sin Cuenta",
          customerEmail: "sin@cuenta.com",
          customerDiscord: "",
          customerNote: "",
          payerAccount: "",
          paymentReference: "",
        },
      }),
    ).rejects.toThrow(/Iniciá sesión o creá tu cuenta/i);
  });

  it("rechaza un plan que no existe", async () => {
    const caller = appRouter.createCaller(customerContext());
    await expect(
      caller.orders.create({
        planId: 999,
        details: {
          customerName: "Cliente Prueba",
          customerEmail: "cliente@ejemplo.com",
          customerDiscord: "",
          customerNote: "",
          payerAccount: "",
          paymentReference: "",
        },
      }),
    ).rejects.toThrow(/no está disponible/i);
  });

});

describe("acceso privado del panel", () => {
  it("genera códigos con el formato esperado y los verifica hasheados", () => {
    const code = generateStaffCode();
    expect(code).toMatch(/^IMP-[A-Z0-9]{4}-[A-Z0-9]{4}$/);

    const hash = hashStaffCode(code);
    expect(hash.startsWith("scrypt:")).toBe(true);
    expect(verifyStaffCodeHash(code, hash)).toBe(true);
    expect(verifyStaffCodeHash("IMP-XXXX-XXXX", hash)).toBe(false);
    expect(codeHint(code)).toBe(`••••${code.slice(-4)}`);
  });

  it("acepta el código sin importar mayúsculas o espacios sobrantes", () => {
    const code = generateStaffCode();
    const hash = hashStaffCode(code);
    expect(verifyStaffCodeHash(`  ${code.toLowerCase()}  `, hash)).toBe(true);
  });

  it("firma la sesión y la rechaza cuando la firma fue alterada", () => {
    const token = issueStaffToken({ codeId: 1, label: "Dueño", role: "owner" });
    const req = {
      headers: { cookie: `imperio_staff=${token}` },
    } as unknown as TrpcContext["req"];
    const session = readStaffSession(req);
    expect(session?.label).toBe("Dueño");
    expect(session?.role).toBe("owner");

    const tampered = `${token.split(".")[0]}.firmafalsa`;
    const badReq = {
      headers: { cookie: `imperio_staff=${tampered}` },
    } as unknown as TrpcContext["req"];
    expect(readStaffSession(badReq)).toBeNull();
  });

  it("bloquea las consultas del panel sin sesión de equipo", async () => {
    const caller = appRouter.createCaller(publicContext());
    await expect(caller.admin.overview()).rejects.toThrow(/sesión del panel/i);
  });

  it("acepta el panel con una sesión de equipo válida", async () => {
    const token = issueStaffToken({ codeId: 1, label: "Dueño", role: "owner" });
    const ctx = publicContext();
    (ctx.req as unknown as { headers: Record<string, string> }).headers = {
      cookie: `imperio_staff=${token}`,
    };

    const caller = appRouter.createCaller(ctx);
    const result = await caller.admin.overview();
    expect(result.stats.total).toBe(0);
  });
});

describe("cuentas de clientes", () => {
  it("hashea y verifica la contraseña sin guardarla en texto plano", () => {
    const hash = hashPassword("clave-segura-123");
    expect(hash.startsWith("scrypt:")).toBe(true);
    expect(hash.includes("clave-segura-123")).toBe(false);
    expect(verifyPassword("clave-segura-123", hash)).toBe(true);
    expect(verifyPassword("otra-clave", hash)).toBe(false);
  });

  it("normaliza el correo para evitar cuentas duplicadas", () => {
    expect(normalizeEmail("  Cliente@Ejemplo.COM ")).toBe("cliente@ejemplo.com");
  });

  it("mantiene la sesión del cliente separada de la del panel", async () => {
    // Una sesión de cliente no debe abrir el panel privado del equipo.
    const caller = appRouter.createCaller(customerContext());
    await expect(caller.admin.overview()).rejects.toThrow(/sesión del panel/i);
  });

  it("expone el estado de sesión del cliente", async () => {
    const anonymous = appRouter.createCaller(publicContext());
    expect(await anonymous.customer.me()).toEqual({ authenticated: false });

    const logged = appRouter.createCaller(customerContext());
    const me = await logged.customer.me();
    expect(me.authenticated).toBe(true);
    if (me.authenticated) {
      expect(me.customer.email).toBe("cliente@ejemplo.com");
    }
  });
});

describe("códigos de verificación por correo", () => {
  it("genera códigos de 6 dígitos con hash distinto del original", () => {
    const code = generateCode();
    expect(code).toMatch(/^\d{6}$/);
    expect(hashCode(code)).not.toBe(code);
    expect(verifyCode(code, hashCode(code))).toBe(true);
    expect(verifyCode("000000", hashCode(code))).toBe(false);
  });

  it("no expone el código en claro al iniciar el registro", async () => {
    const caller = appRouter.createCaller(publicContext());
    const result = await caller.customer.register({
      name: "Cliente Nuevo",
      email: "nuevo@ejemplo.com",
      password: "clave-segura-123",
      discord: "@nuevo",
    });

    // La cuenta todavía no existe: se crea recién al confirmar el código.
    expect(result.email).toBe("nuevo@ejemplo.com");
    expect(JSON.stringify(result)).not.toMatch(/\d{6}/);
  });

  it("exige una cuenta válida para comprar", async () => {
    const anonymous = appRouter.createCaller(publicContext());
    await expect(
      anonymous.orders.create({
        serviceSlug: "bots-discord",
        planId: 10,
        customerName: "Sin Sesión",
        customerEmail: "sin@sesion.com",
        customerDiscord: "",
        customerNote: "",
        paymentMethod: "paypal",
        payerAccount: "",
      } as never),
    ).rejects.toThrow();
  });

  it("rechaza códigos incorrectos con un mensaje claro", async () => {
    const caller = appRouter.createCaller(publicContext());
    await expect(
      caller.customer.verifySignup({ email: "nuevo@ejemplo.com", code: "123456" }),
    ).rejects.toThrow(/código/i);
  });

  it("mantiene las invitaciones del panel separadas de las cuentas creadas", async () => {
    const caller = appRouter.createCaller(staffContext());
    const invitations = await caller.admin.customers.invitations({ search: "", limit: 50 });
    expect(invitations.invitations).toEqual([]);
    expect(invitations.stats).toEqual({ pending: 0, expired: 0, activated: 0 });
  });
});

describe("sistema de reseñas", () => {
  it("publica solo las reseñas aprobadas en el sitio", async () => {
    const caller = appRouter.createCaller(publicContext());
    const extras = await caller.catalog.extras();
    // El listado público sale del filtro `approved`, así que nunca muestra
    // reseñas pendientes ni descartadas.
    expect(Array.isArray(extras.reviews)).toBe(true);
    for (const review of extras.reviews) {
      expect(review.rating).toBeGreaterThanOrEqual(1);
      expect(review.rating).toBeLessThanOrEqual(5);
      expect(review.author.length).toBeGreaterThan(0);
    }
  });

  it("exige sesión de cliente para reseñar", async () => {
    const caller = appRouter.createCaller(publicContext());
    await expect(
      caller.customer.createReview({ rating: 5, comment: "Muy bueno todo el servicio" }),
    ).rejects.toThrow(/Iniciá sesión/i);
  });

  it("valida la puntuación y el largo del comentario", async () => {
    const caller = appRouter.createCaller(customerContext());

    await expect(
      caller.customer.createReview({ rating: 6, comment: "Comentario suficientemente largo" }),
    ).rejects.toThrow();

    await expect(caller.customer.createReview({ rating: 5, comment: "corto" })).rejects.toThrow();
  });

  it("guarda la reseña como pendiente y la asocia al cliente", async () => {
    const createReview = (await import("./db")).createReview as unknown as ReturnType<
      typeof vi.fn
    >;
    createReview.mockClear();

    const caller = appRouter.createCaller(customerContext());
    const result = await caller.customer.createReview({
      rating: 5,
      comment: "El bot quedó andando perfecto y me ayudaron con todo.",
    });

    expect(result.id).toBeGreaterThan(0);
    expect(result.message).toMatch(/revisión/i);
    expect(createReview).toHaveBeenCalledTimes(1);

    const payload = createReview.mock.calls[0]?.[0] as Record<string, unknown>;
    expect(payload.customerId).toBe(7);
    expect(payload.rating).toBe(5);
    expect(payload.authorName).toBe("Cliente Prueba");
  });

  it("deja la moderación solo al equipo del panel", async () => {
    const anonymous = appRouter.createCaller(publicContext());
    await expect(anonymous.admin.reviews.list()).rejects.toThrow(/sesión del panel/i);
  });
});

describe("perfiles separados del equipo", () => {
  it("el dueño recibe permisos totales", async () => {
    const token = issueStaffToken({ codeId: 1, label: "Dueño", role: "owner" });
    const ctx = publicContext();
    (ctx.req as unknown as { headers: Record<string, string> }).headers = {
      cookie: `imperio_staff=${token}`,
    };

    const caller = appRouter.createCaller(ctx);
    const me = await caller.admin.session.me();
    expect(me.authenticated).toBe(true);
    if (me.authenticated) {
      expect(me.permissions.isOwner).toBe(true);
      expect(me.permissions.canManageSettings).toBe(true);
      expect(me.permissions.canManageAccess).toBe(true);
      expect(me.permissions.canViewLogins).toBe(true);
    }
  });

  it("el socio no puede entrar a configuración ni administrar accesos", async () => {
    const token = issueStaffToken({ codeId: 2, label: "Socio", role: "staff" });
    const ctx = publicContext();
    (ctx.req as unknown as { headers: Record<string, string> }).headers = {
      cookie: `imperio_staff=${token}`,
    };

    const caller = appRouter.createCaller(ctx);
    const me = await caller.admin.session.me();
    expect(me.authenticated).toBe(true);
    if (me.authenticated) {
      expect(me.permissions.isOwner).toBe(false);
      expect(me.permissions.canManageSettings).toBe(false);
      expect(me.permissions.canManageAccess).toBe(false);
      // Pero sí trabaja con pedidos, catálogo y clientes.
      expect(me.permissions.canManageOrders).toBe(true);
      expect(me.permissions.canManageCatalog).toBe(true);
      expect(me.permissions.canViewCustomers).toBe(true);
    }

    await expect(caller.admin.settings.get()).rejects.toThrow(/solo para el dueño/i);
    await expect(caller.admin.staff.list()).rejects.toThrow(/solo para el dueño/i);
  });

  it("el dueño sí accede a configuración y accesos", async () => {
    const token = issueStaffToken({ codeId: 1, label: "Dueño", role: "owner" });
    const ctx = publicContext();
    (ctx.req as unknown as { headers: Record<string, string> }).headers = {
      cookie: `imperio_staff=${token}`,
    };

    const caller = appRouter.createCaller(ctx);
    await expect(caller.admin.settings.get()).resolves.toEqual({ "brand.name": "Imperio Shop" });
    await expect(caller.admin.staff.list()).resolves.toEqual([]);
  });
});

describe("códigos de acceso tolerantes al formato", () => {
  it("acepta el mismo código con o sin guiones y en minúsculas", () => {
    const code = "IMP-8T9F-3X4F";
    const hash = hashStaffCode(code);
    expect(verifyStaffCodeHash("IMP-8T9F-3X4F", hash)).toBe(true);
    expect(verifyStaffCodeHash("imp8t9f3x4f", hash)).toBe(true);
    expect(verifyStaffCodeHash(" IMP 8T9F 3X4F ", hash)).toBe(true);
    expect(verifyStaffCodeHash("IMP-0000-0000", hash)).toBe(false);
  });
});


describe("integración con Tebex", () => {
  it("genera la URL de la API con el token público de la tienda", async () => {
    process.env.TEBEX_PUBLIC_TOKEN = "spk3-prueba123";
    // ENV se lee al importar el módulo, así que hay que recargarlo.
    vi.resetModules();
    const { tebexConfigured } = await import("./tebex");
    expect(tebexConfigured()).toBe(true);
  });

  it("no considera configurada la integración sin token", async () => {
    const previous = process.env.TEBEX_PUBLIC_TOKEN;
    delete process.env.TEBEX_PUBLIC_TOKEN;
    vi.resetModules();
    const { tebexConfigured } = await import("./tebex");
    expect(tebexConfigured()).toBe(false);
    process.env.TEBEX_PUBLIC_TOKEN = previous;
    vi.resetModules();
  });

  it("valida la firma del webhook con el secreto configurado", async () => {
    process.env.TEBEX_WEBHOOK_SECRET = "secreto-de-prueba";
    vi.resetModules();
    const { verifyTebexSignature } = await import("./tebex");
    const crypto = await import("node:crypto");

    const body = JSON.stringify({ id: "abc", type: "payment.completed", subject: {} });
    // La firma es HMAC-SHA256 del SHA256 del cuerpo crudo.
    const bodyHash = crypto.createHash("sha256").update(body, "utf-8").digest("hex");
    const signature = crypto
      .createHmac("sha256", "secreto-de-prueba")
      .update(bodyHash)
      .digest("hex");

    expect(verifyTebexSignature(body, signature)).toBe(true);
    expect(verifyTebexSignature(body, "firma-falsa")).toBe(false);
    expect(verifyTebexSignature(`${body} `, signature)).toBe(false);
  });

  it("confirma el pedido cuando Tebex avisa que el pago se completó", async () => {
    process.env.TEBEX_WEBHOOK_SECRET = "secreto-de-prueba";
    vi.resetModules();
    const { handleTebexWebhook } = await import("./tebexWebhook");
    const { getOrderByCode, updateOrderPayment } = await import("./db");
    const crypto = await import("node:crypto");

    const body = JSON.stringify({
      id: "hook-1",
      type: "payment.completed",
      date: "2026-09-27T12:00:00+00:00",
      subject: {
        transaction_id: "tbx-123456",
        status: { id: 1, description: "Complete" },
        payment_method: { name: "PayPal" },
        price_paid: { amount: 20, currency: "USD" },
        products: [{ id: 55, name: "Bot Intermedio", custom: { orderCode: "IMP-ABC123" } }],
      },
    });
    const bodyHash = crypto.createHash("sha256").update(body, "utf-8").digest("hex");
    const signature = crypto
      .createHmac("sha256", "secreto-de-prueba")
      .update(bodyHash)
      .digest("hex");

    const req = {
      rawBody: Buffer.from(body, "utf-8"),
      body: JSON.parse(body),
      headers: { "x-signature": signature },
      ip: "18.209.80.3",
    };
    const res = {
      statusCode: 200,
      status(code: number) {
        this.statusCode = code;
        return this;
      },
      json: vi.fn(),
    };

    await handleTebexWebhook(req as never, res as never);

    expect(res.statusCode).toBe(200);
    const order = await getOrderByCode("IMP-ABC123");
    expect(order).toBeTruthy();
    const updateMock = updateOrderPayment as unknown as { mock: { calls: unknown[][] } };
    const lastCall = updateMock.mock.calls.at(-1);
    expect(lastCall?.[1]).toMatchObject({
      status: "paid",
      paymentReference: "tbx-123456",
      payerAccount: "PayPal",
    });
  });

  it("responde la validación inicial del webhook con su id", async () => {
    vi.resetModules();
    const { handleTebexWebhook } = await import("./tebexWebhook");
    const body = JSON.stringify({ id: "val-999", type: "validation.webhook", subject: {} });
    const req = {
      rawBody: Buffer.from(body, "utf-8"),
      body: JSON.parse(body),
      headers: {},
      ip: "18.209.80.3",
    };
    const json = vi.fn();
    const res = {
      statusCode: 200,
      status(code: number) {
        this.statusCode = code;
        return this;
      },
      json,
    };

    await handleTebexWebhook(req as never, res as never);
    expect(res.statusCode).toBe(200);
    expect(json).toHaveBeenCalledWith({ id: "val-999" });
  });
});
