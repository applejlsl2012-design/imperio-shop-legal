/**
 * Cuentas de clientes.
 *
 * Cada cliente se registra con correo y contraseña (y queda preparado para
 * sumar Google/Apple). La contraseña se guarda hasheada con scrypt y la sesión
 * viaja en una cookie propia firmada con HMAC-SHA256, separada de la sesión
 * del equipo del panel.
 */
import crypto from "node:crypto";
import { parse as parseCookieHeader } from "cookie";
import type { Request, Response } from "express";
import { ENV } from "./_core/env";

export const CUSTOMER_COOKIE = "imperio_customer";
const SESSION_DAYS = 30;
const SESSION_MS = SESSION_DAYS * 24 * 60 * 60 * 1000;
const PASSWORD_PREFIX = "scrypt";

/**
 * Los navegadores rechazan `SameSite=None` sin `Secure`, así que en desarrollo
 * local (http) usamos `Lax` y en producción (https) `None`, que es lo que
 * necesita el preview embebido en un iframe.
 */
function cookieOptions(req: Request) {
  const forwarded = req.headers["x-forwarded-proto"];
  const proto = (Array.isArray(forwarded) ? forwarded[0] : forwarded)
    ?.split(",")[0]
    ?.trim();
  const secure = req.protocol === "https" || proto === "https";
  return {
    httpOnly: true,
    path: "/",
    sameSite: secure ? ("none" as const) : ("lax" as const),
    secure,
  };
}

export type CustomerSession = {
  customerId: number;
  email: string;
  name: string;
  exp: number;
};

/* ------------------------------- contraseñas ------------------------------- */

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString("hex");
  const derived = crypto.scryptSync(password, salt, 32).toString("hex");
  return `${PASSWORD_PREFIX}:${salt}:${derived}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  try {
    const [scheme, salt, digest] = stored.split(":");
    if (scheme !== PASSWORD_PREFIX || !salt || !digest) return false;
    const derived = crypto.scryptSync(password, salt, 32).toString("hex");
    const a = Buffer.from(derived, "hex");
    const b = Buffer.from(digest, "hex");
    if (a.length !== b.length) return false;
    return crypto.timingSafeEqual(a, b);
  } catch {
    return false;
  }
}

/* --------------------------------- sesión ---------------------------------- */

function secret(): string {
  return ENV.cookieSecret || "imperio-shop-dev-secret";
}

function sign(payload: string): string {
  return crypto.createHmac("sha256", secret()).update(payload).digest("base64url");
}

export function issueCustomerToken(session: Omit<CustomerSession, "exp">): string {
  const payload = Buffer.from(
    JSON.stringify({ ...session, exp: Date.now() + SESSION_MS }),
  ).toString("base64url");
  return `${payload}.${sign(payload)}`;
}

export function readCustomerSession(req: Request): CustomerSession | null {
  // El servidor no usa middleware de cookies: se lee el encabezado a mano.
  const header = req.headers?.cookie;
  const raw = header ? parseCookieHeader(header)[CUSTOMER_COOKIE] : undefined;
  if (!raw || typeof raw !== "string") return null;

  const [payload, signature] = raw.split(".");
  if (!payload || !signature) return null;

  const expected = sign(payload);
  const a = Buffer.from(signature);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;

  try {
    const session = JSON.parse(
      Buffer.from(payload, "base64url").toString(),
    ) as CustomerSession;
    if (!session?.exp || session.exp < Date.now()) return null;
    return session;
  } catch {
    return null;
  }
}

export function setCustomerCookie(req: Request, res: Response, token: string) {
  res.cookie(CUSTOMER_COOKIE, token, { ...cookieOptions(req), maxAge: SESSION_MS });
}

export function clearCustomerCookie(req: Request, res: Response) {
  res.clearCookie(CUSTOMER_COOKIE, { ...cookieOptions(req), maxAge: -1 });
}

/* ------------------------------ protección --------------------------------- */

/**
 * Límite de intentos de ingreso.
 *
 * Es generoso a propósito: si alguien se equivoca escribiendo su contraseña,
 * debe poder reintentar en seguida en vez de quedar fuera diez minutos. La
 * ventana corta ya frena los ataques por fuerza bruta.
 */
const MAX_ATTEMPTS = 12;
const WINDOW_MS = 3 * 60 * 1000;
const attempts = new Map<string, { count: number; first: number }>();

export function customerRateLimitKey(req: Request): string {
  const forwarded = req.headers["x-forwarded-for"];
  const ip =
    (Array.isArray(forwarded) ? forwarded[0] : forwarded)?.split(",")[0]?.trim() ||
    req.ip ||
    "desconocida";
  return ip;
}

export function checkCustomerRateLimit(key: string): {
  allowed: boolean;
  retryInSeconds: number;
} {
  const now = Date.now();
  const entry = attempts.get(key);
  if (!entry || now - entry.first > WINDOW_MS) {
    attempts.set(key, { count: 1, first: now });
    return { allowed: true, retryInSeconds: 0 };
  }
  if (entry.count >= MAX_ATTEMPTS) {
    return {
      allowed: false,
      retryInSeconds: Math.ceil((WINDOW_MS - (now - entry.first)) / 1000),
    };
  }
  entry.count += 1;
  return { allowed: true, retryInSeconds: 0 };
}

export function resetCustomerRateLimit(key: string) {
  attempts.delete(key);
}

export function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}
