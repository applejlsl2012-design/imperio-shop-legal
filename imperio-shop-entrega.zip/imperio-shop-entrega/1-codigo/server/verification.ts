/**
 * Códigos de verificación por correo.
 *
 * Cuando alguien crea su cuenta le mandamos un código de 6 dígitos. Guardamos
 * solo su hash, con vencimiento corto y límite de intentos, para que nadie
 * pueda adivinar el código ni reutilizarlo.
 */
import crypto from "node:crypto";

const CODE_LENGTH = 6;
/** Minutos que el código sigue siendo válido. */
export const CODE_TTL_MINUTES = 15;
/** Intentos fallidos permitidos antes de invalidar el código. */
export const MAX_CODE_ATTEMPTS = 5;

/** Genera un código numérico sin sesgo (crypto.randomInt es uniforme). */
export function generateCode(): string {
  let code = "";
  for (let index = 0; index < CODE_LENGTH; index += 1) {
    code += crypto.randomInt(0, 10).toString();
  }
  return code;
}

export function hashCode(code: string): string {
  return crypto.createHash("sha256").update(code.trim()).digest("hex");
}

/** Compara en tiempo constante para no filtrar información por tiempos. */
export function verifyCode(code: string, stored: string): boolean {
  const candidate = Buffer.from(hashCode(code));
  const expected = Buffer.from(stored);
  if (candidate.length !== expected.length) return false;
  return crypto.timingSafeEqual(candidate, expected);
}

export function codeExpiry(): Date {
  return new Date(Date.now() + CODE_TTL_MINUTES * 60 * 1000);
}

/**
 * Deja el código legible para mostrar: "482 913".
 * Ayuda a copiarlo sin equivocarse.
 */
export function formatCode(code: string): string {
  if (code.length !== CODE_LENGTH) return code;
  return `${code.slice(0, 3)} ${code.slice(3)}`;
}
