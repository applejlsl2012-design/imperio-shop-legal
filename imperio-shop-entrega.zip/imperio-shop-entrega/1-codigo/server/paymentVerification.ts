/**
 * Verificación del pago.
 *
 * Cuando el cliente vuelve del checkout de Tebex no alcanza con confiar en el
 * webhook: puede demorar, reintentarse o perderse. Así que además preguntamos
 * directamente a Tebex si la canasta quedó completa.
 *
 * Tres capas, en este orden:
 *   1. El pedido ya está marcado como pagado (por webhook o por una verificación previa).
 *   2. La canasta en Tebex figura como `complete` → el dinero entró de verdad.
 *   3. Todavía no hay confirmación → el cliente sigue esperando.
 */
import { logActivity } from "./activity";
import { getOrderByCode, getSettingsMap, updateOrderPayment } from "./db";
import { getTebexBasket } from "./tebex";

/** Estados que ya significan "el pago entró". */
const PAID_STATUSES = new Set(["paid", "in_progress", "delivered"]);

export type PaymentCheckStatus = "confirmed" | "pending" | "review" | "unavailable";

export type PaymentCheck = {
  status: PaymentCheckStatus;
  /** Texto listo para mostrarle al cliente. */
  message: string;
  /** Código del pedido, para mostrarlo en pantalla. */
  code: string;
  /** Importe abonado, ya formateado. */
  amount: string;
  /** Método de pago, cuando Tebex lo informó. */
  method: string;
  /** Instrucción siguiente (abrir ticket), tomada de la configuración del sitio. */
  nextStep: string;
  /** Enlace al Discord, para el botón de abrir ticket. */
  discord: string;
  /** Momento en que se confirmó el pago, si ya ocurrió. */
  confirmedAt: string;
};

/** Arma la respuesta a partir del pedido y de lo que sabemos del pago. */
function buildCheck(options: {
  status: PaymentCheckStatus;
  message: string;
  order: {
    code: string;
    amountCents: number;
    currency: string;
    tebexPaymentMethod: string;
    payerAccount: string;
    updatedAt: Date;
  };
  nextStep: string;
  discord: string;
}): PaymentCheck {
  const amount = `${options.order.currency} ${(options.order.amountCents / 100).toFixed(2)}`;
  return {
    status: options.status,
    message: options.message,
    code: options.order.code,
    amount,
    method: options.order.tebexPaymentMethod || options.order.payerAccount || "",
    nextStep: options.nextStep,
    discord: options.discord,
    confirmedAt: options.status === "confirmed" ? options.order.updatedAt.toISOString() : "",
  };
}

/**
 * Comprueba si el pago de un pedido llegó.
 *
 * Solo la cuenta dueña del pedido puede consultarlo: el `customerId` sale de la
 * sesión, nunca de lo que mande el navegador.
 */
export async function checkOrderPayment(
  code: string,
  customerId: number,
): Promise<PaymentCheck> {
  const settings = await getSettingsMap();
  const nextStep = settings["orders.ticketMessage"] ?? "";
  const discord = settings["contact.discord"] ?? "";

  const order = await getOrderByCode(code);

  // Pedido inexistente o de otra persona: mismo mensaje, sin filtrar datos.
  if (!order || order.customerId !== customerId) {
    return {
      status: "unavailable",
      message: "No encontramos ese pedido en tu cuenta.",
      code,
      amount: "",
      method: "",
      nextStep,
      discord,
      confirmedAt: "",
    };
  }

  // 1) Ya confirmado antes (webhook o verificación previa).
  if (PAID_STATUSES.has(order.status)) {
    return buildCheck({
      status: "confirmed",
      message: "¡Pago confirmado! Ya registramos tu compra.",
      order,
      nextStep,
      discord,
    });
  }

  // Si el pedido se canceló o se reembolsó, no hay nada que esperar.
  if (order.status === "cancelled") {
    return buildCheck({
      status: "unavailable",
      message: "Este pedido fue cancelado. Si pagaste, abrí un ticket y lo revisamos.",
      order,
      nextStep,
      discord,
    });
  }

  // 2) Sin canasta de Tebex no hay pago automático que verificar.
  if (!order.tebexBasketIdent) {
    return buildCheck({
      status: "unavailable",
      message:
        "Este pedido no tiene un pago en línea asociado. Abrí un ticket y te pasamos el enlace de pago.",
      order,
      nextStep,
      discord,
    });
  }

  // 3) Preguntamos a Tebex si la canasta quedó completa.
  const basket = await getTebexBasket(order.tebexBasketIdent);

  if (!basket.ok) {
    // Tebex no respondió: no afirmamos nada, el cliente puede reintentar.
    return buildCheck({
      status: "pending",
      message: "Estamos consultando con Tebex. Esperá unos segundos más…",
      order,
      nextStep,
      discord,
    });
  }

  if (basket.data.complete) {
    // El pago entró: lo dejamos registrado en el pedido y en la bitácora.
    await updateOrderPayment(
      order.id,
      {
        status: "paid",
        // Solo escribimos el método si el pedido aún no lo tenía.
        ...(order.tebexPaymentMethod
          ? {}
          : { tebexPaymentMethod: "Tebex" }),
        staffNote: `${order.staffNote ? `${order.staffNote} ` : ""}Pago verificado contra Tebex (canasta completa).`.trim(),
      },
      "verificacion",
    );
    logActivity({
      kind: "pago.confirmado",
      title: `Pago verificado ${order.code}`,
      detail: `Tebex confirmó la canasta ${order.tebexBasketIdent} como completa.`,
      actor: "verificacion",
      actorEmail: order.customerEmail,
      customerId: order.customerId ?? null,
      orderId: order.id,
      meta: { basketIdent: order.tebexBasketIdent },
    });

    const refreshed = await getOrderByCode(order.code);
    return buildCheck({
      status: "confirmed",
      message: "¡Pago confirmado! Ya registramos tu compra.",
      order: refreshed ?? order,
      nextStep,
      discord,
    });
  }

  // La canasta existe pero todavía no se completó.
  return buildCheck({
    status: "pending",
    message: "Todavía no vemos el pago acreditado. Esperá un momento más…",
    order,
    nextStep,
    discord,
  });
}
