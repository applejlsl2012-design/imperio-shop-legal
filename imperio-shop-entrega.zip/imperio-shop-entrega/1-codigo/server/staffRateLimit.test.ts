import { afterEach, describe, expect, it } from "vitest";
import { checkRateLimit, resetAllRateLimits, resetRateLimit } from "./staffAuth";

/**
 * El límite existe para frenar la fuerza bruta contra el código del panel, pero
 * no puede dejar afuera al dueño por escribir mal su código un par de veces.
 */
describe("límite de intentos del panel", () => {
  afterEach(() => resetAllRateLimits());

  it("permite varios intentos antes de bloquear", () => {
    for (let i = 0; i < 10; i += 1) {
      expect(checkRateLimit("1.1.1.1").allowed).toBe(true);
    }
  });

  it("bloquea recién después de muchos intentos seguidos", () => {
    let bloqueado = false;
    for (let i = 0; i < 20; i += 1) {
      if (!checkRateLimit("2.2.2.2").allowed) {
        bloqueado = true;
        break;
      }
    }
    expect(bloqueado).toBe(true);
  });

  it("avisa cuánto falta para volver a intentar, en un rango razonable", () => {
    for (let i = 0; i < 20; i += 1) checkRateLimit("3.3.3.3");
    const limit = checkRateLimit("3.3.3.3");
    expect(limit.allowed).toBe(false);
    // Nunca más de los 3 minutos de la ventana.
    expect(limit.retryInSeconds).toBeGreaterThan(0);
    expect(limit.retryInSeconds).toBeLessThanOrEqual(180);
  });

  it("un intento correcto limpia el bloqueo de esa persona", () => {
    for (let i = 0; i < 12; i += 1) checkRateLimit("4.4.4.4");
    resetRateLimit("4.4.4.4");
    expect(checkRateLimit("4.4.4.4").allowed).toBe(true);
  });

  it("no mezcla los intentos de una persona con los de otra", () => {
    for (let i = 0; i < 20; i += 1) checkRateLimit("5.5.5.5");
    expect(checkRateLimit("5.5.5.5").allowed).toBe(false);
    // Otra persona entra sin problemas.
    expect(checkRateLimit("6.6.6.6").allowed).toBe(true);
  });
});