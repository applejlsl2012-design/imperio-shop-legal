import { describe, expect, it } from "vitest";
import { ENV } from "./_core/env";
import { tebexConfigured, getTebexStatus, resetTebexStatusCache } from "./tebex";

/**
 * Validación de las credenciales de Tebex contra la API real.
 *
 * Se salta sola si las claves no están cargadas, así la suite sigue corriendo
 * en entornos sin credenciales. Con claves presentes comprueba que el Public
 * Token identifica la tienda y que la Private Key autoriza consultas.
 */
describe("credenciales de Tebex", () => {
  const configured = tebexConfigured();

  it("las claves quedaron cargadas en el entorno", () => {
    expect(configured).toBe(true);
    expect(ENV.tebexPublicToken.length).toBeGreaterThan(10);
    expect(ENV.tebexPublicToken).toContain("-");
    expect(ENV.tebexPrivateKey.length).toBeGreaterThan(10);
    expect(ENV.tebexWebhookSecret.length).toBeGreaterThan(10);
  });

  it("el Public Token identifica la tienda en la API de Tebex", async () => {
    const response = await fetch(
      `https://headless.tebex.io/api/accounts/${encodeURIComponent(ENV.tebexPublicToken)}`,
      { headers: { Accept: "application/json" } },
    );
    // Si el token fuera inválido, Tebex no devolvería los datos de la tienda.
    expect(response.status).toBe(200);
    const body = (await response.json()) as {
      data?: { id?: number; name?: string; platform_type?: string };
    };
    expect(body.data?.name).toBe("Imperio Shop");
    expect(typeof body.data?.id).toBe("number");

    // Dejamos constancia del tipo de plataforma: FiveM obliga a que el cliente
    // inicie sesión con Cfx.re, y esas tiendas no cobran en una web propia.
    console.log(
      `[Tebex] Tienda ${body.data?.name} (id ${body.data?.id}) · plataforma ${body.data?.platform_type}`,
    );
  }, 30_000);

  it("la Private Key autoriza consultas autenticadas", async () => {
    const auth = Buffer.from(
      `${ENV.tebexPublicToken}:${ENV.tebexPrivateKey}`,
    ).toString("base64");
    const response = await fetch(
      `https://headless.tebex.io/api/accounts/${encodeURIComponent(ENV.tebexPublicToken)}/packages`,
      { headers: { Authorization: `Basic ${auth}`, Accept: "application/json" } },
    );
    // 401 = credencial inválida. Si la clave es correcta, Tebex responde 200
    // con la lista de paquetes (puede estar vacía: el proyecto es nuevo).
    expect(response.status).toBe(200);
    const body = (await response.json()) as { data?: unknown[] };
    expect(Array.isArray(body.data)).toBe(true);
    console.log(`[Tebex] Paquetes cargados en la tienda: ${body.data?.length ?? 0}`);
  }, 30_000);

  it("el estado de la tienda informa si puede cobrar hoy", async () => {
    resetTebexStatusCache();
    const status = await getTebexStatus();
    // La tienda está configurada, pero puede no estar habilitada para cobrar.
    expect(status.configured).toBe(true);
    // Dejamos constancia del tipo de plataforma: debe ser una tienda de tipo
    // web (Universal), porque las de FiveM obligan a iniciar sesión con Cfx.re
    // y rechazan las compras hechas desde una web propia.
    expect(status.platform).not.toBe("FiveM");
    // Si no puede cobrar, el mensaje debe explicar por qué, sin inventar nada.
    if (!status.canCharge) {
      expect(status.message.length).toBeGreaterThan(10);
    }
    console.log(
      `[Tebex] Puede cobrar: ${status.canCharge} · plataforma ${status.platform} · deshabilitada: ${status.disabled}`,
    );
  }, 30_000);
});
