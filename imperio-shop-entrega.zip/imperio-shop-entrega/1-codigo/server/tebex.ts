/**
 * Integración con Tebex.
 *
 * Tebex es la plataforma que procesa los pagos (PayPal, tarjetas, Mercado Pago
 * y más de 120 métodos locales). El flujo es:
 *
 *   1. La web crea una canasta y le agrega el paquete del plan elegido.
 *   2. Mandamos al cliente al checkout seguro de Tebex (`links.checkout`).
 *   3. Tebex nos avisa por webhook cuando el pago se completa.
 *
 * La Private Key da acceso total a la cuenta, así que NUNCA sale del servidor.
 */
import crypto from "node:crypto";
import type { Request } from "express";
import { ENV } from "./_core/env";

/** Token público de la tienda. Va en la URL de la API, no es secreto. */
function publicToken(): string {
  return ENV.tebexPublicToken;
}

/** ¿Está configurada la integración de Tebex? */
export function tebexConfigured(): boolean {
  return Boolean(publicToken());
}

/** URL base de la API Headless, atada al token de la tienda. */
function apiBase(): string {
  return `https://headless.tebex.io/api/accounts/${encodeURIComponent(publicToken())}`;
}

/**
 * Base de los endpoints de canasta que NO llevan el token en la ruta.
 *
 * Ojo: agregar un paquete vive en `/api/baskets/{ident}/packages`, no bajo
 * `/api/accounts/{token}`. Con el prefijo de la cuenta Tebex responde 404.
 * Documentación: /developers/headless-api/guides/baskets/add-package-to-basket
 */
function basketsApiBase(): string {
  return "https://headless.tebex.io/api/baskets";
}

/** Cabeceras de autorización (HTTP Basic: token público + clave privada). */
function authHeaders(): Record<string, string> {
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    Accept: "application/json",
  };
  if (ENV.tebexPrivateKey) {
    const basic = Buffer.from(`${publicToken()}:${ENV.tebexPrivateKey}`).toString("base64");
    headers.Authorization = `Basic ${basic}`;
  }
  return headers;
}

export type TebexBasket = {
  id: string;
  ident: string;
  complete: boolean;
  email: string | null;
  username: string | null;
  base_price: number;
  total_price: number;
  currency: string;
  custom: Record<string, unknown> | null;
  links: { checkout?: string; payment?: string };
  packages: Array<{ id: number; name: string; quantity: number; price: number }>;
};

type TebexResult<T> =
  | { ok: true; data: T }
  | { ok: false; error: string; status?: number };

/** Paquete publicado en la tienda de Tebex. */
export type TebexPackage = {
  id: number;
  name: string;
  total_price: number;
  currency: string;
  type: string;
};

/** Datos de la tienda: plataforma, moneda y si está habilitada. */
export type TebexAccount = {
  id: number;
  name: string;
  webstore_url: string;
  currency: string;
  /** "FiveM", "Universal", "Minecraft", etc. Define cómo se paga. */
  platform_type: string;
  /** Si está en `true`, la tienda no acepta cobros. */
  disabled: boolean;
};

/** Lee los datos de la tienda, incluida su plataforma. */
export async function getTebexAccount(): Promise<TebexResult<TebexAccount>> {
  const result = await call<{ data: TebexAccount }>("", { method: "GET" });
  if (!result.ok) return result;
  if (!result.data.data) return { ok: false, error: "Tebex no devolvió la tienda" };
  return { ok: true, data: result.data.data };
}

/** Estado de cobro de la tienda, ya interpretado para la web. */
export type TebexStatus = {
  configured: boolean;
  /** ¿La tienda puede cobrar hoy a un cliente cualquiera? */
  canCharge: boolean;
  platform: string;
  disabled: boolean;
  /**
   * Tebex todavía no aprobó el proyecto, así que el pago se procesa con
   * métodos de prueba: el importe no se le cobra de verdad al cliente.
   */
  testMode: boolean;
  /** Texto listo para mostrar cuando no se puede cobrar. */
  message: string;
};

/**
 * Consulta el estado de la tienda, con una caché corta.
 *
 * Se usa en cada compra para no mandar al cliente a un checkout que no puede
 * completar, así que no conviene golpear a Tebex en cada pedido.
 */
let cacheEstado: { valor: TebexStatus; expira: number } | null = null;

/** Limpia el estado guardado. Se usa en las pruebas. */
export function resetTebexStatusCache() {
  cacheEstado = null;
}

export async function getTebexStatus(): Promise<TebexStatus> {
  if (!tebexConfigured()) {
    return {
      configured: false,
      canCharge: false,
      platform: "",
      disabled: false,
      testMode: false,
      message: "",
    };
  }
  if (cacheEstado && cacheEstado.expira > Date.now()) return cacheEstado.valor;

  const account = await getTebexAccount();
  if (!account.ok) {
    return {
      configured: true,
      canCharge: false,
      platform: "",
      disabled: false,
      testMode: false,
      message: "No pudimos consultar la tienda de pagos. Abrí un ticket y te ayudamos a pagar.",
    };
  }

  const disabled = account.data.disabled;
  // Las tiendas FiveM exigen una cuenta de Cfx.re: no sirven para vender
  // bots, hosting o páginas web a clientes comunes.
  const isFiveM = account.data.platform_type.toLowerCase() === "fivem";
  // Un proyecto recién creado figura como deshabilitado hasta que Tebex lo
  // aprueba, pero igual permite cobrar con métodos de prueba. Eso nos deja
  // probar el circuito completo hoy; el cobro real llega con la aprobación.
  const testMode = disabled && !isFiveM;
  const canCharge = !isFiveM;

  let message = "";
  if (isFiveM) {
    message =
      "La tienda de pagos exige una cuenta de FiveM, así que el cobro automático no está disponible para estos servicios. Abrí un ticket y te ayudamos a pagar.";
  } else if (testMode) {
    message =
      "El pago se procesa en modo de prueba: Tebex todavía no aprobó la tienda, así que el importe no se te cobra de verdad. Cuando la aprueben, el cobro pasa a ser real sin que tengas que hacer nada.";
  }

  const valor: TebexStatus = {
    configured: true,
    canCharge,
    platform: account.data.platform_type,
    disabled,
    testMode,
    message,
  };
  // Cinco minutos de caché: suficiente para no castigar a Tebex.
  cacheEstado = { valor, expira: Date.now() + 5 * 60 * 1000 };
  return valor;
}

/**
 * Lista los paquetes de la tienda.
 *
 * Se usa para vincular los planes de la web con su paquete de Tebex y para
 * verificar desde el panel que cada precio esté alineado.
 */
export async function listTebexPackages(): Promise<TebexResult<TebexPackage[]>> {
  const result = await call<{ data: TebexPackage[] }>("/packages", { method: "GET" });
  if (!result.ok) return result;
  return { ok: true, data: result.data?.data ?? [] };
}

/** Envuelve las llamadas para no romper el sitio si Tebex falla. */
async function call<T>(
  path: string,
  init: { method: string; body?: unknown },
): Promise<TebexResult<T>> {
  if (!tebexConfigured()) {
    return { ok: false, error: "sin-token" };
  }
  try {
    // Si la ruta ya es absoluta se usa tal cual (endpoints sin token).
    const url = path.startsWith("http") ? path : `${apiBase()}${path}`;
    const response = await fetch(url, {
      method: init.method,
      headers: authHeaders(),
      body: init.body ? JSON.stringify(init.body) : undefined,
    });
    const text = await response.text();
    let parsed: unknown = null;
    try {
      parsed = text ? JSON.parse(text) : null;
    } catch {
      parsed = null;
    }
    if (!response.ok) {
      const detail =
        (parsed as { detail?: string; message?: string; title?: string } | null)?.detail ??
        (parsed as { message?: string } | null)?.message ??
        (parsed as { title?: string } | null)?.title ??
        `Tebex respondió ${response.status}`;
      console.warn("[Tebex] Error en", path, response.status, detail);
      return { ok: false, error: detail, status: response.status };
    }
    return { ok: true, data: parsed as T };
  } catch (error) {
    console.warn("[Tebex] Falló la llamada a", path, error);
    return { ok: false, error: "No pudimos contactar a Tebex" };
  }
}

/**
 * Crea una canasta con el paquete del plan y devuelve el enlace de pago.
 *
 * `orderCode` viaja en `custom`, así el webhook puede atar el pago al pedido.
 */
export async function createTebexCheckout(input: {
  packageId: number;
  orderCode: string;
  completeUrl: string;
  cancelUrl: string;
  /**
   * A dónde vuelve el cliente tras identificarse en Tebex. Ahí la web retoma
   * la misma canasta. Si no se indica, se usa la URL de cancelación.
   */
  resumeUrl?: string;
  quantity?: number;
  ipAddress?: string;
}): Promise<
  TebexResult<{
    checkoutUrl: string;
    basketIdent: string;
    /**
     * Si viene, la tienda exige que el cliente se autentique antes de pagar.
     * Hay que llevarlo a esta URL y, al volver, retomar el checkout.
     */
    authUrl?: string;
    authProvider?: string;
  }>
> {
  const basket = await call<{ data: TebexBasket }>("/baskets", {
    method: "POST",
    body: {
      complete_url: input.completeUrl,
      cancel_url: input.cancelUrl,
      complete_auto_redirect: true,
      // Si la tienda está detrás de un servidor, hay que declarar la IP real
      // del cliente para no atribuir la canasta a nuestra máquina.
      ip_address: input.ipAddress,
      custom: { orderCode: input.orderCode },
    },
  });
  if (!basket.ok) return basket;

  const ident = basket.data.data?.ident;
  if (!ident) return { ok: false, error: "Tebex no devolvió la canasta" };

  // La canasta ya está creada: a partir de acá todo se retoma por su ident.
  const filled = await fillTebexBasket(
    ident,
    input.packageId,
    input.quantity ?? 1,
    input.resumeUrl ?? input.cancelUrl,
  );
  if (!filled.ok) return filled;

  if (filled.data.needsAuth) {
    // Tienda que exige login: devolvemos el enlace de acceso, sin cobrar todavía.
    return {
      ok: true,
      data: {
        checkoutUrl: "",
        basketIdent: ident,
        authUrl: filled.data.authUrl,
        authProvider: filled.data.authProvider,
      },
    };
  }

  return { ok: true, data: { checkoutUrl: filled.data.checkoutUrl, basketIdent: ident } };
}

/**
 * Agrega el paquete a una canasta y devuelve su enlace de pago.
 *
 * Si la tienda obliga a iniciar sesión, en lugar del checkout devuelve el
 * enlace de autorización (`needsAuth`): así el cliente se identifica una vez y
 * después retomamos la misma canasta, sin perder lo que ya eligió.
 */
export async function fillTebexBasket(
  ident: string,
  packageId: number,
  quantity: number,
  returnUrl: string,
): Promise<
  TebexResult<{
    checkoutUrl: string;
    needsAuth: boolean;
    authUrl?: string;
    authProvider?: string;
  }>
> {
  // `resumeTebex` puede llamarse más de una vez (por refrescar la página o
  // volver del flujo de autorización). Nunca agregamos el paquete otra vez:
  // sumaríamos el mismo producto y cobraríamos x2 al cliente.
  const existing = await getTebexBasket(ident);
  const yaEstaEnLaCanasta =
    existing.ok && (existing.data.packages ?? []).some((item) => item.id === packageId);
  if (yaEstaEnLaCanasta) {
    const checkout = await getTebexCheckoutUrl(ident);
    if (!checkout.ok) return checkout;
    return { ok: true, data: { checkoutUrl: checkout.data, needsAuth: false } };
  }

  const added = await addTebexPackage(ident, packageId, quantity);

  if (!added.ok) {
    // 422 "User must login before adding packages to basket": hay que autorizar.
    if (added.status === 422 && /must login/i.test(added.error)) {
      const auth = await getTebexBasketAuthUrl(ident, returnUrl);
      if (!auth.ok) return auth;
      return {
        ok: true,
        data: {
          checkoutUrl: "",
          needsAuth: true,
          authUrl: auth.data.url,
          authProvider: auth.data.name,
        },
      };
    }
    return added;
  }

  // Tras agregar el paquete hay que releer la canasta para obtener el enlace.
  const updated = await getTebexCheckoutUrl(ident);
  if (!updated.ok) return updated;
  return { ok: true, data: { checkoutUrl: updated.data, needsAuth: false } };
}

/**
 * Pide a Tebex el enlace de autorización de una canasta.
 *
 * Algunas tiendas (por ejemplo las de plataforma FiveM) exigen que el
 * comprador inicie sesión antes de poder agregar paquetes. Tebex devuelve el
 * enlace del proveedor de identidad; tras autenticarse, el cliente vuelve a
 * `returnUrl` y la canasta queda autorizada.
 */
export async function getTebexBasketAuthUrl(
  ident: string,
  returnUrl: string,
): Promise<TebexResult<{ name: string; url: string }>> {
  const result = await call<Array<{ name: string; url: string }>>(
    `/baskets/${encodeURIComponent(ident)}/auth?returnUrl=${encodeURIComponent(returnUrl)}`,
    { method: "GET" },
  );
  if (!result.ok) return result;
  const first = Array.isArray(result.data) ? result.data[0] : undefined;
  if (!first?.url) return { ok: false, error: "Tebex no devolvió un enlace de acceso" };
  return { ok: true, data: first };
}

/** Agrega un paquete a una canasta existente. */
export async function addTebexPackage(
  ident: string,
  packageId: number,
  quantity = 1,
): Promise<TebexResult<unknown>> {
  // Ruta sin token: `/api/baskets/{ident}/packages` (ver basketsApiBase).
  return call<unknown>(`${basketsApiBase()}/${encodeURIComponent(ident)}/packages`, {
    method: "POST",
    body: { package_id: String(packageId), quantity },
  });
}

/** Lee el enlace de checkout de una canasta ya armada. */
export async function getTebexCheckoutUrl(
  ident: string,
): Promise<TebexResult<string>> {
  const basket = await getTebexBasket(ident);
  if (!basket.ok) return basket;
  const url = basket.data.links?.checkout;
  if (!url) return { ok: false, error: "Tebex no devolvió el enlace de pago" };
  return { ok: true, data: url };
}

/** Consulta el estado de una canasta (por ejemplo al volver del checkout). */
export async function getTebexBasket(ident: string): Promise<TebexResult<TebexBasket>> {
  const result = await call<{ data: TebexBasket }>(`/baskets/${encodeURIComponent(ident)}`, {
    method: "GET",
  });
  if (!result.ok) return result;
  if (!result.data.data) return { ok: false, error: "Canasta no encontrada" };
  return { ok: true, data: result.data.data };
}

/**
 * Verifica que un webhook venga de Tebex.
 *
 * La firma es HMAC-SHA256( SHA256(cuerpo crudo), secreto ). Hay que usar el
 * cuerpo SIN parsear, porque reserializar cambia los bytes y rompe la firma.
 */
export function verifyTebexSignature(rawBody: Buffer | string, signature: string): boolean {
  if (!ENV.tebexWebhookSecret || !signature) return false;
  const body = typeof rawBody === "string" ? rawBody : rawBody.toString("utf-8");
  const bodyHash = crypto.createHash("sha256").update(body, "utf-8").digest("hex");
  const expected = crypto
    .createHmac("sha256", ENV.tebexWebhookSecret)
    .update(bodyHash)
    .digest("hex");

  const a = Buffer.from(expected, "utf-8");
  const b = Buffer.from(signature, "utf-8");
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

/** IPs desde las que Tebex envía sus webhooks. */
const TEBEX_WEBHOOK_IPS = new Set(["18.209.80.3", "54.87.231.232"]);

/** Dominio público real del sitio (detrás del proxy llega en los headers). */
export function publicOrigin(req: Request): string {
  // Si el sitio declara su dirección pública, esa manda: evita que un proxy
  // cambie el host y que Tebex devuelva al cliente a una dirección equivocada.
  if (ENV.publicBaseUrl) return ENV.publicBaseUrl.replace(/\/+$/, "");

  const forwardedProto = req.headers["x-forwarded-proto"];
  const proto =
    (Array.isArray(forwardedProto) ? forwardedProto[0] : forwardedProto)
      ?.split(",")[0]
      ?.trim() || (req.protocol === "https" ? "https" : "http");
  const forwardedHost = req.headers["x-forwarded-host"];
  const host =
    (Array.isArray(forwardedHost) ? forwardedHost[0] : forwardedHost)
      ?.split(",")[0]
      ?.trim() ||
    req.get("host") ||
    "localhost:3000";
  return `${proto}://${host}`;
}

/** IP real del visitante, para atribuir bien la canasta en Tebex. */
export function clientIp(req: Request): string | undefined {
  const forwarded = req.headers["x-forwarded-for"];
  const chain = (Array.isArray(forwarded) ? forwarded[0] : forwarded) ?? "";
  const first = chain.split(",")[0]?.trim();
  if (first) return first;
  return req.ip && req.ip !== "::1" && req.ip !== "::ffff:127.0.0.1" ? req.ip : undefined;
}

/** Comprueba el origen del webhook (IP de Tebex, tolerando proxies). */
export function isTebexSender(req: Request): boolean {
  const forwarded = req.headers["x-forwarded-for"];
  const chain = (Array.isArray(forwarded) ? forwarded[0] : forwarded) ?? req.ip ?? "";
  const candidates = chain.split(",").map((part) => part.trim()).filter(Boolean);
  if (candidates.length === 0) return false;
  // Debe venir de Tebex en cualquier punto de la cadena de reenvío.
  return candidates.some((ip) => TEBEX_WEBHOOK_IPS.has(ip));
}

export type TebexWebhook = {
  id: string;
  type: string;
  date: string;
  subject: Record<string, unknown>;
};
