import { and, asc, desc, eq, gte, like, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  activityLog,
  customers,
  faqs,
  InsertOrder,
  InsertUser,
  orderEvents,
  orders,
  plans,
  reviews,
  services,
  settings,
  staffCodes,
  staffLogins,
  testimonials,
  users,
  verificationCodes,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

/**
 * Drizzle+mysql2 puede devolver el encabezado del INSERT directamente o dentro
 * de un arreglo `[ResultSetHeader, fields]`. Esta función cubre ambos casos.
 */
export function extractInsertId(result: unknown): number {
  const candidate = Array.isArray(result) ? result[0] : result;
  const value = (candidate as { insertId?: number | string } | null)?.insertId;
  const id = Number(value);
  if (!Number.isFinite(id) || id <= 0) {
    throw new Error("No se pudo obtener el identificador del registro insertado");
  }
  return id;
}

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db
    .select()
    .from(users)
    .where(eq(users.openId, openId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/* -------------------------------------------------------------------------- */
/*  Catálogo                                                                   */
/* -------------------------------------------------------------------------- */

export type ServiceWithPlans = Awaited<ReturnType<typeof getCatalog>>[number];

export async function getCatalog(options?: { includeInactive?: boolean }) {
  const db = await getDb();
  if (!db) return [];

  const serviceRows = options?.includeInactive
    ? await db.select().from(services).orderBy(asc(services.sortOrder), asc(services.id))
    : await db
        .select()
        .from(services)
        .where(eq(services.active, true))
        .orderBy(asc(services.sortOrder), asc(services.id));

  const planRows = options?.includeInactive
    ? await db.select().from(plans).orderBy(asc(plans.sortOrder), asc(plans.id))
    : await db
        .select()
        .from(plans)
        .where(eq(plans.active, true))
        .orderBy(asc(plans.sortOrder), asc(plans.id));

  return serviceRows.map((service) => ({
    ...service,
    plans: planRows.filter((plan) => plan.serviceId === service.id),
  }));
}

export async function getServiceBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;

  const rows = await db.select().from(services).where(eq(services.slug, slug)).limit(1);
  const service = rows[0];
  if (!service) return undefined;

  const planRows = await db
    .select()
    .from(plans)
    .where(and(eq(plans.serviceId, service.id), eq(plans.active, true)))
    .orderBy(asc(plans.sortOrder), asc(plans.id));

  return { ...service, plans: planRows };
}

export async function getPlanById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(plans).where(eq(plans.id, id)).limit(1);
  return rows[0];
}

export async function getServiceById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(services).where(eq(services.id, id)).limit(1);
  return rows[0];
}

/* -------------------------------------------------------------------------- */
/*  Pedidos                                                                    */
/* -------------------------------------------------------------------------- */

export async function createOrder(order: InsertOrder) {
  const db = await getDb();
  if (!db) throw new Error("Base de datos no disponible");
  const result = await db.insert(orders).values(order);
  return extractInsertId(result);
}

export async function getOrderByCode(code: string) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(orders).where(eq(orders.code, code)).limit(1);
  return rows[0];
}

export async function getOrderById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
  return rows[0];
}

export async function listOrders(options: {
  status?: string;
  search?: string;
  limit?: number;
  offset?: number;
}) {
  const db = await getDb();
  if (!db) return { rows: [], total: 0 };

  const filters = [];
  if (options.status && options.status !== "all") {
    filters.push(eq(orders.status, options.status as never));
  }
  if (options.search && options.search.trim()) {
    const needle = `%${options.search.trim()}%`;
    filters.push(
      or(
        like(orders.code, needle),
        like(orders.customerName, needle),
        like(orders.customerEmail, needle),
        like(orders.customerDiscord, needle),
        like(orders.serviceName, needle),
      )!,
    );
  }
  const where = filters.length ? and(...filters) : undefined;

  const rows = await db
    .select()
    .from(orders)
    .where(where)
    .orderBy(desc(orders.createdAt))
    .limit(options.limit ?? 50)
    .offset(options.offset ?? 0);

  const totalRows = await db
    .select({ value: sql<number>`count(*)` })
    .from(orders)
    .where(where);

  return { rows, total: Number(totalRows[0]?.value ?? 0) };
}

export async function updateOrderStatus(
  id: number,
  status: string,
  note: string,
  actor: string,
) {
  const db = await getDb();
  if (!db) throw new Error("Base de datos no disponible");

  const current = await getOrderById(id);
  if (!current) throw new Error("Pedido no encontrado");

  await db
    .update(orders)
    .set({ status: status as never })
    .where(eq(orders.id, id));

  await db.insert(orderEvents).values({
    orderId: id,
    fromStatus: current.status,
    toStatus: status,
    note,
    actor,
  });
}

export async function updateOrderPayment(
  id: number,
  data: {
    status?: string;
    staffNote?: string;
    payerAccount?: string;
    paymentReference?: string;
    /** Método que informó Tebex (PayPal, tarjeta, etc.). */
    tebexPaymentMethod?: string;
    /** ID de la transacción de Tebex que confirma el cobro. */
    tebexTransactionId?: string;
  },
  actor: string,
) {
  const db = await getDb();
  if (!db) throw new Error("Base de datos no disponible");

  const current = await getOrderById(id);
  if (!current) throw new Error("Pedido no encontrado");

  const patch: Record<string, unknown> = {};
  if (data.staffNote !== undefined) patch.staffNote = data.staffNote;
  if (data.payerAccount !== undefined) patch.payerAccount = data.payerAccount;
  if (data.paymentReference !== undefined) patch.paymentReference = data.paymentReference;
  if (data.tebexPaymentMethod !== undefined) patch.tebexPaymentMethod = data.tebexPaymentMethod;
  if (data.tebexTransactionId !== undefined) patch.tebexTransactionId = data.tebexTransactionId;
  if (data.status !== undefined) patch.status = data.status;

  // Al confirmarse el pago guardamos el instante exacto del cobro. Es la fecha
  // que ven el cliente y el panel, así que no puede quedar vacía.
  const estadosPagados = ["paid", "in_progress", "delivered"];
  if (data.status && estadosPagados.includes(data.status) && !current.paidAt) {
    patch.paidAt = new Date();
  }

  if (Object.keys(patch).length > 0) {
    await db.update(orders).set(patch).where(eq(orders.id, id));
  }

  if (data.status && data.status !== current.status) {
    await db.insert(orderEvents).values({
      orderId: id,
      fromStatus: current.status,
      toStatus: data.status,
      note: data.staffNote ?? "",
      actor,
    });
  }
}

export async function getOrderEvents(orderId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(orderEvents)
    .where(eq(orderEvents.orderId, orderId))
    .orderBy(desc(orderEvents.createdAt));
}

export async function getOrderStats() {
  const db = await getDb();
  if (!db) {
    return { total: 0, pending: 0, review: 0, paid: 0, inProgress: 0, delivered: 0, revenueCents: 0, last30: 0 };
  }

  const rows = await db
    .select({ status: orders.status, value: sql<number>`count(*)` })
    .from(orders)
    .groupBy(orders.status);

  const byStatus = new Map<string, number>();
  rows.forEach((row) => byStatus.set(String(row.status), Number(row.value)));

  const revenueRows = await db
    .select({ value: sql<number>`coalesce(sum(amountCents), 0)` })
    .from(orders)
    .where(
      or(
        eq(orders.status, "paid"),
        eq(orders.status, "in_progress"),
        eq(orders.status, "delivered"),
      ),
    );

  const since = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
  const last30Rows = await db
    .select({ value: sql<number>`count(*)` })
    .from(orders)
    .where(gte(orders.createdAt, since));

  return {
    total: Array.from(byStatus.values()).reduce((a, b) => a + b, 0),
    pending: byStatus.get("pending_payment") ?? 0,
    review: byStatus.get("payment_review") ?? 0,
    paid: byStatus.get("paid") ?? 0,
    inProgress: byStatus.get("in_progress") ?? 0,
    delivered: byStatus.get("delivered") ?? 0,
    cancelled: byStatus.get("cancelled") ?? 0,
    revenueCents: Number(revenueRows[0]?.value ?? 0),
    last30: Number(last30Rows[0]?.value ?? 0),
  };
}

/* -------------------------------------------------------------------------- */
/*  Acceso privado del equipo                                                  */
/* -------------------------------------------------------------------------- */

export async function listStaffCodes() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(staffCodes).orderBy(asc(staffCodes.id));
}

export async function findActiveStaffCodes() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(staffCodes).where(eq(staffCodes.active, true));
}

export async function createStaffCode(data: {
  label: string;
  codeHash: string;
  codeHint: string;
  role: "owner" | "staff";
  createdBy: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Base de datos no disponible");
  const result = await db.insert(staffCodes).values(data);
  return extractInsertId(result);
}

export async function touchStaffCode(id: number) {
  const db = await getDb();
  if (!db) return;
  await db
    .update(staffCodes)
    .set({ lastUsedAt: new Date(), useCount: sql`${staffCodes.useCount} + 1` })
    .where(eq(staffCodes.id, id));
}

export async function setStaffCodeActive(id: number, active: boolean) {
  const db = await getDb();
  if (!db) return;
  await db.update(staffCodes).set({ active }).where(eq(staffCodes.id, id));
}

export async function deleteStaffCode(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(staffCodes).where(eq(staffCodes.id, id));
}

export async function logStaffLogin(data: {
  label: string;
  success: boolean;
  ip: string;
  userAgent: string;
}) {
  const db = await getDb();
  if (!db) return;
  await db.insert(staffLogins).values({
    label: data.label.slice(0, 120),
    success: data.success,
    ip: data.ip.slice(0, 64),
    userAgent: data.userAgent.slice(0, 255),
  });
}

export async function listStaffLogins(limit = 30) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(staffLogins).orderBy(desc(staffLogins.createdAt)).limit(limit);
}

/* -------------------------------------------------------------------------- */
/*  Cuentas de clientes                                                        */
/* -------------------------------------------------------------------------- */

export async function findCustomerByEmail(email: string) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db
    .select()
    .from(customers)
    .where(eq(customers.email, email))
    .limit(1);
  return rows[0];
}

export async function getCustomerById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(customers).where(eq(customers.id, id)).limit(1);
  return rows[0];
}

export async function createCustomer(data: {
  email: string;
  name: string;
  passwordHash: string;
  discord: string;
  provider: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Base de datos no disponible");
  const result = await db.insert(customers).values(data);
  return extractInsertId(result);
}

/** Busca la cuenta por el identificador de Manus (ingreso con Google o Apple). */
export async function findCustomerByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db
    .select()
    .from(customers)
    .where(eq(customers.manusOpenId, openId))
    .limit(1);
  return rows[0];
}

/**
 * Crea o actualiza la cuenta de un cliente que entró con Google o Apple.
 * Si ya existía una cuenta con ese correo, la reutiliza y la vincula, así la
 * persona conserva sus compras anteriores.
 */
export async function upsertCustomerFromOAuth(data: {
  openId: string;
  email: string;
  name: string;
  provider: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Base de datos no disponible");

  const byOpenId = await findCustomerByOpenId(data.openId);
  if (byOpenId) {
    await db
      .update(customers)
      .set({
        name: data.name || byOpenId.name,
        provider: data.provider,
        lastSignedIn: new Date(),
      })
      .where(eq(customers.id, byOpenId.id));
    return byOpenId.id;
  }

  const byEmail = await findCustomerByEmail(data.email);
  if (byEmail) {
    // Cuenta ya existente (por ejemplo creada con contraseña): la vinculamos.
    await db
      .update(customers)
      .set({
        manusOpenId: data.openId,
        provider: data.provider,
        name: data.name || byEmail.name,
        lastSignedIn: new Date(),
      })
      .where(eq(customers.id, byEmail.id));
    return byEmail.id;
  }

  const result = await db.insert(customers).values({
    email: data.email,
    name: data.name || data.email.split("@")[0],
    passwordHash: "",
    provider: data.provider,
    manusOpenId: data.openId,
    discord: "",
    lastSignedIn: new Date(),
  });
  return extractInsertId(result);
}

export async function touchCustomer(id: number) {
  const db = await getDb();
  if (!db) return;
  await db
    .update(customers)
    .set({ lastSignedIn: new Date() })
    .where(eq(customers.id, id));
}

export async function updateCustomerProfile(
  id: number,
  data: { name?: string; discord?: string },
) {
  const db = await getDb();
  if (!db) throw new Error("Base de datos no disponible");
  const patch: Record<string, unknown> = {};
  if (data.name !== undefined) patch.name = data.name;
  if (data.discord !== undefined) patch.discord = data.discord;
  if (Object.keys(patch).length > 0) {
    await db.update(customers).set(patch).where(eq(customers.id, id));
  }
}

/**
 * Cambia la contraseña de una cuenta de cliente.
 *
 * Se usa cuando la persona recupera su contraseña con el código que llega por
 * correo. Guardamos siempre el hash, nunca la contraseña en texto.
 */
export async function updateCustomerPassword(id: number, passwordHash: string) {
  const db = await getDb();
  if (!db) throw new Error("Base de datos no disponible");
  await db.update(customers).set({ passwordHash }).where(eq(customers.id, id));
}

/** Pedidos de una cuenta de cliente concreta. */
export async function listCustomerOrders(customerId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(orders)
    .where(eq(orders.customerId, customerId))
    .orderBy(desc(orders.createdAt))
    .limit(50);
}

/** Listado de clientes para el panel, con su cantidad de compras y gasto. */
export async function listCustomers(options: { search?: string; limit?: number }) {
  const db = await getDb();
  if (!db) return [];

  const needle = options.search?.trim();
  const rows = needle
    ? await db
        .select()
        .from(customers)
        .where(
          or(like(customers.email, `%${needle}%`), like(customers.name, `%${needle}%`))!,
        )
        .orderBy(desc(customers.createdAt))
        .limit(options.limit ?? 100)
    : await db
        .select()
        .from(customers)
        .orderBy(desc(customers.createdAt))
        .limit(options.limit ?? 100);

  const orderRows = await db
    .select({
      customerId: orders.customerId,
      total: sql<number>`count(*)`,
      spent: sql<number>`coalesce(sum(case when status in ('paid','in_progress','delivered') then amountCents else 0 end), 0)`,
      lastOrder: sql<string>`max(createdAt)`,
    })
    .from(orders)
    .groupBy(orders.customerId);

  const byCustomer = new Map(
    orderRows
      .filter((row) => row.customerId !== null)
      .map((row) => [
        Number(row.customerId),
        {
          orders: Number(row.total),
          spentCents: Number(row.spent),
          lastOrderAt: row.lastOrder ? new Date(row.lastOrder) : null,
        },
      ]),
  );

  return rows.map((row) => ({
    ...row,
    passwordHash: undefined,
    orderCount: byCustomer.get(row.id)?.orders ?? 0,
    spentCents: byCustomer.get(row.id)?.spentCents ?? 0,
    lastOrderAt: byCustomer.get(row.id)?.lastOrderAt ?? null,
  }));
}

/* -------------------------------------------------------------------------- */
/*  Configuración y contenido                                                  */
/* -------------------------------------------------------------------------- */

export async function getSettingsMap(): Promise<Record<string, string>> {
  const db = await getDb();
  if (!db) return {};
  const rows = await db.select().from(settings);
  return Object.fromEntries(rows.map((row) => [row.key, row.value]));
}

export async function setSetting(key: string, value: string) {
  const db = await getDb();
  if (!db) throw new Error("Base de datos no disponible");
  await db
    .insert(settings)
    .values({ key, value })
    .onDuplicateKeyUpdate({ set: { value } });
}

export async function listTestimonials(includeInactive = true) {
  const db = await getDb();
  if (!db) return [];
  const query = db.select().from(testimonials);
  const rows = includeInactive
    ? await query.orderBy(asc(testimonials.sortOrder), asc(testimonials.id))
    : await query
        .where(eq(testimonials.active, true))
        .orderBy(asc(testimonials.sortOrder), asc(testimonials.id));
  return rows;
}

/* --------------------------------- reseñas -------------------------------- */

/** Reseñas publicadas, para la vidriera pública del sitio. */
export async function listPublishedReviews(limit = 12) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(reviews)
    .where(eq(reviews.status, "approved"))
    .orderBy(desc(reviews.featured), desc(reviews.publishedAt), desc(reviews.id))
    .limit(limit);
}

/** Todas las reseñas para moderar en el panel. */
export async function listReviews(options: {
  status?: "pending" | "approved" | "rejected";
  limit?: number;
} = {}) {
  const db = await getDb();
  if (!db) return [];
  const limit = options.limit ?? 100;
  const query = db.select().from(reviews);
  const rows = options.status
    ? await query
        .where(eq(reviews.status, options.status))
        .orderBy(desc(reviews.createdAt))
        .limit(limit)
    : await query.orderBy(desc(reviews.createdAt)).limit(limit);
  return rows;
}

/** Reseñas de un cliente concreto (para su historial). */
export async function listCustomerReviews(customerId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(reviews)
    .where(eq(reviews.customerId, customerId))
    .orderBy(desc(reviews.createdAt));
}

export async function getReviewById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(reviews).where(eq(reviews.id, id)).limit(1);
  return rows[0];
}

export async function createReview(data: {
  customerId: number;
  authorName: string;
  authorEmail: string;
  serviceId: number | null;
  serviceName: string;
  orderId: number | null;
  rating: number;
  comment: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Base de datos no disponible");
  const result = await db.insert(reviews).values({
    ...data,
    status: "pending",
    staffNote: "",
    reply: "",
  });
  return extractInsertId(result);
}

/** Cambia el estado de una reseña (aprobar, rechazar o volver a revisar). */
export async function setReviewStatus(
  id: number,
  status: "pending" | "approved" | "rejected",
) {
  const db = await getDb();
  if (!db) throw new Error("Base de datos no disponible");
  await db
    .update(reviews)
    .set({
      status,
      publishedAt: status === "approved" ? new Date() : null,
    })
    .where(eq(reviews.id, id));
}

/** Marca o desmarca una reseña como destacada en el inicio. */
export async function setReviewFeatured(id: number, featured: boolean) {
  const db = await getDb();
  if (!db) throw new Error("Base de datos no disponible");
  await db.update(reviews).set({ featured }).where(eq(reviews.id, id));
}

/** Respuesta pública del equipo a una reseña. */
export async function setReviewReply(id: number, reply: string) {
  const db = await getDb();
  if (!db) throw new Error("Base de datos no disponible");
  await db.update(reviews).set({ reply }).where(eq(reviews.id, id));
}

export async function deleteReview(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Base de datos no disponible");
  await db.delete(reviews).where(eq(reviews.id, id));
}

/** Resumen de reseñas para el panel: cuántas hay en cada estado y el promedio. */
export async function getReviewStats() {
  const db = await getDb();
  if (!db) {
    return { pending: 0, approved: 0, rejected: 0, average: 0, total: 0 };
  }
  const rows = await db
    .select({ status: reviews.status, total: sql<number>`count(*)` })
    .from(reviews)
    .groupBy(reviews.status);

  const counts = { pending: 0, approved: 0, rejected: 0 };
  for (const row of rows) {
    counts[row.status as keyof typeof counts] = Number(row.total);
  }

  const avgRows = await db
    .select({ average: sql<number>`coalesce(avg(rating), 0)` })
    .from(reviews)
    .where(eq(reviews.status, "approved"));

  return {
    ...counts,
    total: counts.pending + counts.approved + counts.rejected,
    average: Number(avgRows[0]?.average ?? 0),
  };
}

/**
 * Reseñas publicadas de un servicio, para mostrarlas en su página de detalle.
 */
export async function listServiceReviews(serviceId: number, limit = 6) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(reviews)
    .where(and(eq(reviews.status, "approved"), eq(reviews.serviceId, serviceId)))
    .orderBy(desc(reviews.publishedAt), desc(reviews.id))
    .limit(limit);
}

/** ¿El cliente ya reseñó ese pedido? Evita reseñas duplicadas. */
export async function findReviewByOrder(customerId: number, orderId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db
    .select()
    .from(reviews)
    .where(and(eq(reviews.customerId, customerId), eq(reviews.orderId, orderId)))
    .limit(1);
  return rows[0];
}

export async function listFaqs(includeInactive = false) {
  const db = await getDb();
  if (!db) return [];
  const query = db.select().from(faqs);
  const rows = includeInactive
    ? await query.orderBy(asc(faqs.sortOrder), asc(faqs.id))
    : await query.where(eq(faqs.active, true)).orderBy(asc(faqs.sortOrder), asc(faqs.id));
  return rows;
}

export async function upsertService(data: {
  id?: number;
  slug: string;
  name: string;
  tagline: string;
  description: string;
  imageUrl: string;
  icon: string;
  badge: string;
  accent: string;
  features: string;
  deliveryTime: string;
  sortOrder: number;
  active: boolean;
}) {
  const db = await getDb();
  if (!db) throw new Error("Base de datos no disponible");
  if (data.id) {
    const { id, ...patch } = data;
    await db.update(services).set(patch).where(eq(services.id, id));
    return id;
  }
  const result = await db.insert(services).values(data);
  return extractInsertId(result);
}

export async function upsertPlan(data: {
  id?: number;
  serviceId: number;
  name: string;
  priceCents: number;
  currency: string;
  billing: "once" | "monthly";
  /** ID del paquete en Tebex. Sin valor, el plan se cobra de forma manual. */
  tebexPackageId?: number;
  summary: string;
  specs: string;
  features: string;
  popular: boolean;
  stockLabel: string;
  sortOrder: number;
  active: boolean;
}) {
  const db = await getDb();
  if (!db) throw new Error("Base de datos no disponible");
  if (data.id) {
    const { id, ...patch } = data;
    await db
      .update(plans)
      .set({
        ...patch,
        // Vaciar el campo borra la vinculación con Tebex (vuelve a cobro manual).
        tebexPackageId: patch.tebexPackageId ?? null,
      })
      .where(eq(plans.id, id));
    return id;
  }
  const result = await db.insert(plans).values({ ...data, tebexPackageId: data.tebexPackageId ?? null });
  return extractInsertId(result);
}

export async function deletePlan(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Base de datos no disponible");
  await db.delete(plans).where(eq(plans.id, id));
}

export async function deleteService(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Base de datos no disponible");
  await db.delete(plans).where(eq(plans.serviceId, id));
  await db.delete(services).where(eq(services.id, id));
}

/* -------------------------------------------------------------------------- */
/*  Códigos de verificación e invitaciones                                    */
/* -------------------------------------------------------------------------- */

export async function createVerificationCode(data: {
  email: string;
  codeHash: string;
  purpose: "signup" | "invite" | "reset";
  pendingName: string;
  pendingDiscord: string;
  pendingPasswordHash: string;
  invitedBy?: string;
  expiresAt: Date;
}) {
  const db = await getDb();
  if (!db) throw new Error("Base de datos no disponible");
  const result = await db.insert(verificationCodes).values({
    email: data.email,
    codeHash: data.codeHash,
    purpose: data.purpose,
    pendingName: data.pendingName,
    pendingDiscord: data.pendingDiscord,
    pendingPasswordHash: data.pendingPasswordHash,
    invitedBy: data.invitedBy ?? "",
    expiresAt: data.expiresAt,
  });
  return extractInsertId(result);
}

/** Devuelve el último código vigente (aunque esté vencido, para informar bien). */
export async function getLatestVerificationCode(
  email: string,
  purpose: "signup" | "invite" | "reset",
) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db
    .select()
    .from(verificationCodes)
    .where(and(eq(verificationCodes.email, email), eq(verificationCodes.purpose, purpose)))
    .orderBy(desc(verificationCodes.createdAt))
    .limit(1);
  return rows[0];
}

export async function recordVerificationAttempt(id: number) {
  const db = await getDb();
  if (!db) return;
  await db
    .update(verificationCodes)
    .set({ attempts: sql`${verificationCodes.attempts} + 1` })
    .where(eq(verificationCodes.id, id));
}

/**
 * Registros que quedaron a medio camino.
 *
 * Cuando alguien crea su cuenta sin el correo conectado, no puede recibir el
 * código y la cuenta nunca se crea. El panel muestra esos casos para
 * habilitarlos a mano y que la persona pueda entrar.
 */
export async function listPendingSignups(options: { limit?: number } = {}) {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .select()
    .from(verificationCodes)
    .where(eq(verificationCodes.purpose, "signup"))
    .orderBy(desc(verificationCodes.createdAt))
    .limit(options.limit ?? 50);
  return rows.filter((row) => !row.consumedAt);
}

export async function consumeVerificationCode(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Base de datos no disponible");
  await db
    .update(verificationCodes)
    .set({ consumedAt: new Date() })
    .where(eq(verificationCodes.id, id));
}

export async function listPendingInvitations(options: { search?: string; limit?: number } = {}) {
  const db = await getDb();
  if (!db) return [];
  const needle = options.search?.trim();
  const rows = needle
    ? await db
        .select()
        .from(verificationCodes)
        .where(
          and(
            eq(verificationCodes.purpose, "invite"),
            or(
              like(verificationCodes.email, `%${needle}%`),
              like(verificationCodes.pendingName, `%${needle}%`),
            )!,
          ),
        )
        .orderBy(desc(verificationCodes.createdAt))
        .limit(options.limit ?? 50)
    : await db
        .select()
        .from(verificationCodes)
        .where(eq(verificationCodes.purpose, "invite"))
        .orderBy(desc(verificationCodes.createdAt))
        .limit(options.limit ?? 50);
  return rows.filter((row) => !row.consumedAt);
}

/** Cancela una invitación pendiente: queda consumida y no se puede usar. */
export async function cancelInvitationById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Base de datos no disponible");
  await db
    .update(verificationCodes)
    .set({ consumedAt: new Date() })
    .where(eq(verificationCodes.id, id));
}

/** Activa o desactiva la cuenta de un cliente. */
export async function setCustomerActive(id: number, active: boolean) {
  const db = await getDb();
  if (!db) throw new Error("Base de datos no disponible");
  await db.update(customers).set({ active }).where(eq(customers.id, id));
}

/** Resumen de invitaciones para el panel: pendientes, activadas y vencidas. */
export async function getInvitationStats() {
  const db = await getDb();
  if (!db) return { pending: 0, expired: 0, activated: 0 };
  const rows = await db
    .select({
      consumedAt: verificationCodes.consumedAt,
      expiresAt: verificationCodes.expiresAt,
    })
    .from(verificationCodes)
    .where(eq(verificationCodes.purpose, "invite"));
  const now = Date.now();
  return {
    pending: rows.filter((row) => !row.consumedAt && row.expiresAt.getTime() > now).length,
    expired: rows.filter((row) => !row.consumedAt && row.expiresAt.getTime() <= now).length,
    activated: rows.filter((row) => Boolean(row.consumedAt)).length,
  };
}

/* -------------------------------------------------------------------------- */
/*  Bitácora de la web                                                        */
/* -------------------------------------------------------------------------- */

export async function insertActivity(data: {
  kind: string;
  title: string;
  detail: string;
  actor: string;
  actorEmail: string;
  customerId: number | null;
  orderId: number | null;
  meta: string;
  ip: string;
  userAgent: string;
}) {
  const db = await getDb();
  if (!db) return;
  await db.insert(activityLog).values(data);
}

export async function listActivity(options: { kind?: string; limit?: number } = {}) {
  const db = await getDb();
  if (!db) return [];
  const limit = options.limit ?? 60;
  if (options.kind && options.kind !== "all") {
    return db
      .select()
      .from(activityLog)
      .where(eq(activityLog.kind, options.kind))
      .orderBy(desc(activityLog.createdAt))
      .limit(limit);
  }
  return db
    .select()
    .from(activityLog)
    .orderBy(desc(activityLog.createdAt))
    .limit(limit);
}

/** Cuántos movimientos de cada tipo hubo en los últimos días. */
export async function getActivityStats(days = 7) {
  const db = await getDb();
  if (!db) return { total: 0, today: 0, visits: 0, signups: 0, orders: 0, reviews: 0 };
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);

  const rows = await db
    .select({ kind: activityLog.kind, createdAt: activityLog.createdAt })
    .from(activityLog)
    .where(gte(activityLog.createdAt, since))
    .limit(5000);

  return {
    total: rows.length,
    today: rows.filter((row) => row.createdAt.getTime() >= startOfDay.getTime()).length,
    visits: rows.filter((row) => row.kind === "visita").length,
    signups: rows.filter((row) => row.kind.startsWith("cuenta.")).length,
    orders: rows.filter((row) => row.kind.startsWith("pedido.")).length,
    reviews: rows.filter((row) => row.kind.startsWith("resena.")).length,
  };
}
