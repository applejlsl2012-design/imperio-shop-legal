/**
 * Catálogo base de Imperio Shop.
 * Se carga en la base de datos la primera vez que arranca el sitio y queda
 * 100% editable después desde el panel privado.
 */

export const CATALOG_SEED = [
  {
    slug: "bots-discord",
    name: "Bots de Discord",
    tagline: "Bots a medida, listos para tu comunidad",
    description:
      "¿Necesitás un bot de Discord para el funcionamiento de tu Mafia en algún servidor de FiveM, o por otra razón? Estás en el lugar correcto: Imperio Shop te trae todo lo necesario para el funcionamiento de tu Mafia, Facción o simplemente para tu comunidad de Discord.\n\nMás seguridad con Logs en el Discord: sistema avanzado de alertas del inventario de tu Mafia, ya que el bot puede integrar alertas solo por ver el canal donde llegan los logs del inventario de tu Mafia. Lo mismo para facciones.\n\nQUÉ PODEMOS CREAR\n• Tickets y soporte\n• Fichajes avanzados para facciones\n• Logs avanzados\n• Sistemas para mafias\n• Bienvenidas y despedidas\n• Moderación automática\n• Mensajes privados (DM)\n• Y mucho más…\n\nPRECIOS\n\nEl precio puede variar según lo que quiera el cliente: puede ser un bot muy avanzado o algo más básico y sencillo.\n\nDe US$ 8 a US$ 28.\n\nIncluye\n• 3 modificaciones de funciones (después son US$ 5 por cada cambio)\n• Soporte prioritario ante errores\n\nIMPORTANTE\n• El pago se procesa con Tebex: PayPal, tarjeta y más métodos.\n• El pago es único, no es mensual.",
    imageUrl: "/manus-storage/service-bots_1b905fd9.jpg",
    icon: "bot",
    badge: "Más vendido",
    accent: "#FF1F3D",
    deliveryTime: "24 a 72 horas",
    features: [
      "Tickets, fichajes y logs avanzados",
      "Sistemas para mafias y facciones de FiveM",
      "Alertas de inventario por canal de logs",
      "Moderación automática, bienvenidas y DM",
    ],
    sortOrder: 1,
    plans: [
      {
        name: "Bot Básico",
        priceCents: 800,
        billing: "once" as const,
        summary: "Lo más simple y rápido: funciones esenciales para arrancar.",
        specs: [
          "Sistema de tickets y soporte",
          "Bienvenidas y despedidas",
          "Moderación automática básica",
          "Logs en canal",
          "Pago único, no es mensual",
          "3 modificaciones de funciones incluidas",
          "Soporte prioritario ante errores",
        ],
        features: [
          "3 modificaciones incluidas",
          "Soporte prioritario ante errores",
          "Pago único, no mensual",
        ],
        popular: false,
        stockLabel: "Disponible",
        sortOrder: 1,
      },
      {
        name: "Bot Avanzado",
        priceCents: 1600,
        billing: "once" as const,
        summary: "Varias funciones combinadas para tu comunidad o facción.",
        specs: [
          "Todo lo del plan básico",
          "Fichajes avanzados para facciones",
          "Logs avanzados y alertas de inventario",
          "Sistemas para mafias",
          "Mensajes privados (DM) automáticos",
          "Pago único, no es mensual",
          "3 modificaciones de funciones incluidas",
          "Soporte prioritario ante errores",
        ],
        features: [
          "3 modificaciones incluidas",
          "Soporte prioritario ante errores",
          "Pago único, no mensual",
        ],
        popular: false,
        stockLabel: "Disponible",
        sortOrder: 2,
      },
      {
        name: "Bot Pro",
        priceCents: 2800,
        billing: "once" as const,
        summary: "Bot completo con todos los sistemas que tu servidor necesite.",
        specs: [
          "Todo lo de los planes anteriores, ampliado",
          "Integración total con tu Mafia o Facción de FiveM",
          "Sistema de alertas de inventario automático",
          "Módulos combinados sin límite práctico",
          "Pago único, no es mensual",
          "3 modificaciones de funciones incluidas",
          "Soporte prioritario ante errores",
        ],
        features: [
          "3 modificaciones incluidas",
          "Soporte prioritario ante errores",
          "Pago único, no mensual",
        ],
        popular: true,
        stockLabel: "Más pedido",
        sortOrder: 3,
      },
    ],
  },
  {
    slug: "hosting",
    name: "Hosting de Bots",
    tagline: "Tu bot encendido 24/7, sin interrupciones ni caídas",
    description:
      "¿Necesitás mantener tu bot de Discord encendido las 24 horas del día, los 7 días de la semana, sin interrupciones ni caídas? En Imperio Shop te ofrecemos nuestro servidor de alojamiento optimizado, seguro y con panel de control para la gestión de tu bot.\n\nMÁXIMA SEGURIDAD Y GARANTÍA\n• Protección de datos: tu código y configuraciones están 100% seguros. Garantizamos que no habrá pérdidas de datos, borrados ni robos de información.\n• Actualizaciones libres: si necesitás subir archivos nuevos o hacer cambios a tu bot, podés hacerlo en cualquier momento sin ningún costo adicional. Solo tenés que avisar en el chat privado de tu hosting y el staff sube el archivo por vos.\n• Soporte de instalación: el bot queda instalado en minutos y corriendo las 24 horas del día, todos los días de la semana.",
    imageUrl: "/manus-storage/service-hosting_ba0a7eb7.jpg",
    icon: "server",
    badge: "99.9% Uptime",
    accent: "#FF4D6D",
    deliveryTime: "Instalado en minutos",
    features: [
      "Encendido 24/7 con 99.9% de disponibilidad",
      "Panel de control para gestionar tu bot",
      "Tu código y configuraciones 100% seguros",
      "Actualizaciones de archivos sin costo extra",
    ],
    sortOrder: 2,
    plans: [
      {
        name: "Hosting Bot Dedicado",
        priceCents: 500,
        billing: "monthly" as const,
        summary: "Plan dedicado: tu bot corriendo 24/7 con soporte real.",
        specs: [
          "CPU: 50% de procesamiento dedicado",
          "RAM: 0.25 GiB de memoria",
          "Almacenamiento: 0.50 GiB de espacio en disco",
          "Uptime: 24/7 activo (99.9% de disponibilidad)",
          "Panel de control para gestionar tu bot",
          "Actualizaciones de archivos sin costo adicional",
          "Instalación incluida, en minutos",
        ],
        features: [
          "Datos 100% protegidos",
          "Actualizaciones libres",
          "Soporte de instalación",
        ],
        popular: true,
        stockLabel: "Disponible",
        sortOrder: 1,
      },
    ],
  },
  {
    slug: "paginas-web",
    name: "Desarrollo Web",
    tagline: "Páginas web y landings para tu FiveM, tienda o comunidad",
    description:
      "¿Buscás una página web profesional para tu servidor de FiveM, tienda, comunidad o proyecto personal? En Imperio Shop creamos plataformas web modernas, totalmente optimizadas para dispositivos móviles, con animaciones fluidas, alta velocidad de carga e integración directa con tu servidor de Discord y métodos de pago.\n\nTODOS LOS PLANES INCLUYEN\n• Código optimizado de rápida carga\n• Diseño 100% responsive (móvil y PC)\n• 3 modificaciones de diseño incluidas (después son US$ 5 por cada cambio)\n• Soporte prioritario y corrección de errores tras la entrega",
    imageUrl: "/manus-storage/service-web_261cb741.jpg",
    icon: "globe",
    badge: "Integración con Discord",
    accent: "#FF6B81",
    deliveryTime: "3 a 10 días",
    features: [
      "Código optimizado de rápida carga",
      "Diseño 100% responsive (móvil y PC)",
      "Animaciones fluidas e integración con Discord",
      "3 modificaciones de diseño incluidas",
    ],
    sortOrder: 3,
    plans: [
      {
        name: "Web Basic",
        priceCents: 3000,
        billing: "once" as const,
        summary: "Landing page de una sola sección para presentarte.",
        specs: [
          "Landing page de 1 sola sección (presentación / información)",
          "Botones a redes sociales y enlace para unirse a Discord",
          "Diseño adaptado a teléfonos y PC",
          "Código optimizado de rápida carga",
          "3 modificaciones de diseño incluidas",
          "Soporte prioritario y corrección de errores",
          "Pago único, no es mensual",
        ],
        features: [
          "3 modificaciones incluidas",
          "Diseño responsive",
          "Pago único, no mensual",
        ],
        popular: false,
        stockLabel: "Disponible",
        sortOrder: 1,
      },
      {
        name: "Web Advanced",
        priceCents: 6000,
        billing: "once" as const,
        summary: "Hasta 3 secciones con animaciones y diseño avanzado.",
        specs: [
          "Hasta 3 secciones interactivas (Inicio, Normativas, Nosotros)",
          "Animaciones modernas y diseño visual avanzado",
          "Formulario de contacto o postulaciones básico",
          "Diseño 100% responsive (móvil y PC)",
          "Código optimizado de rápida carga",
          "3 modificaciones de diseño incluidas",
          "Soporte prioritario y corrección de errores",
          "Pago único, no es mensual",
        ],
        features: [
          "3 modificaciones incluidas",
          "Animaciones modernas",
          "Pago único, no mensual",
        ],
        popular: true,
        stockLabel: "Más pedido",
        sortOrder: 2,
      },
      {
        name: "Web Pro",
        priceCents: 8000,
        billing: "once" as const,
        summary: "Multi-página o landing extendida con tienda integrada.",
        specs: [
          "Multi-página o landing extendida (tienda integrada / Tebex)",
          "Animaciones UI/UX complejas y efectos visuales de alta calidad",
          "Integración de widgets de Discord en vivo",
          "Música o video de fondo",
          "Diseño 100% responsive (móvil y PC)",
          "3 modificaciones de diseño incluidas",
          "Soporte prioritario y corrección de errores",
          "Pago único, no es mensual",
        ],
        features: [
          "3 modificaciones incluidas",
          "Tienda o Tebex integrado",
          "Pago único, no mensual",
        ],
        popular: false,
        stockLabel: "Disponible",
        sortOrder: 3,
      },
      {
        name: "Web Ultimate",
        priceCents: 15500,
        billing: "once" as const,
        summary: "Sistema web 100% a medida, sin límites.",
        specs: [
          "Sistema web 100% a medida y personalizado, sin límites",
          "Animaciones 3D y CSS avanzadas",
          "Efectos interactivos premium",
          "Panel de administración o integraciones personalizadas con base de datos",
          "Diseño 100% responsive (móvil y PC)",
          "3 modificaciones de diseño incluidas",
          "Soporte prioritario y corrección de errores",
          "Pago único, no es mensual",
        ],
        features: [
          "3 modificaciones incluidas",
          "Panel de administración",
          "Pago único, no mensual",
        ],
        popular: false,
        stockLabel: "Cupos limitados",
        sortOrder: 4,
      },
    ],
  },
];

export const FAQ_SEED = [
  {
    question: "¿Cómo se realiza el pago?",
    answer:
      "Elegís tu plan y creás tu pedido en la web, que queda registrado con tu código. Al confirmar se abre la pantalla segura de Tebex, donde pagás con tarjeta de crédito o débito, PayPal o el método que prefieras. Los datos de tu tarjeta nunca pasan por esta web. Apenas Tebex confirma el pago, tu pedido pasa a producción y te avisamos para que abras tu ticket en Discord y arranquemos. Si tenés cualquier duda, la sección de Soporte te explica paso a paso cómo hacerlo.",
    sortOrder: 1,
  },
  {
    question: "¿Cuánto tardan en entregar el servicio?",
    answer:
      "Cada plan muestra su tiempo estimado de entrega. Los bots suelen tardar entre 24 y 72 horas, las páginas web de 3 a 10 días y el hosting se activa en minutos. Si necesitás algo urgente, avisanos y vemos la disponibilidad.",
    sortOrder: 2,
  },
  {
    question: "¿Puedo pedir cambios después de la entrega?",
    answer:
      "Sí. Todos los proyectos incluyen un período de soporte para ajustes. Después de ese período podés sumar un plan de mantenimiento mensual para seguir recibiendo mejoras, correcciones y monitoreo.",
    sortOrder: 3,
  },
  {
    question: "¿Trabajan con proyectos fuera de Discord?",
    answer:
      "Sí. Además de bots de Discord hacemos páginas web, tiendas online, paneles de administración, APIs y servidores para cualquier tipo de aplicación. Si no ves tu caso en el catálogo, escribinos y te armamos un presupuesto a medida.",
    sortOrder: 4,
  },
  {
    question: "¿Qué pasa si algo deja de funcionar?",
    answer:
      "Si contrataste hosting o mantenimiento con nosotros, revisamos el problema sin costo y lo resolvemos. Nuestro equipo monitorea los servicios activos y responde en minutos por Discord.",
    sortOrder: 5,
  },
  {
    question: "¿El hosting incluye el dominio?",
    answer:
      "El hosting incluye subdominio gratis en todos los planes. El dominio propio (por ejemplo tunombre.com) se paga aparte una vez al año, pero nosotros te lo configuramos sin costo adicional.",
    sortOrder: 6,
  },
];

export const TESTIMONIAL_SEED = [
  {
    author: "Lucas M.",
    role: "Dueño de servidor de 12k miembros",
    quote:
      "Nos armaron el bot de tickets y ventas completísimo. Lo pedimos un lunes y el jueves ya estaba funcionando con el hosting incluido. Súper recomendados.",
    rating: 5,
    sortOrder: 1,
  },
  {
    author: "Sofía R.",
    role: "Fundadora de una tienda online",
    quote:
      "Mi página web quedó increíble y ahora vendo sin depender de nadie. Me explicaron todo paso a paso y me dieron el panel para cargar los productos yo misma.",
    rating: 5,
    sortOrder: 2,
  },
  {
    author: "Nico T.",
    role: "Desarrollador independiente",
    quote:
      "Migramos mi bot a su hosting y nunca más se cayó. El panel es simple y el soporte contesta al toque, incluso un domingo a la noche.",
    rating: 5,
    sortOrder: 3,
  },
  {
    author: "Martín A.",
    role: "Admin de comunidad de gaming",
    quote:
      "Precio justo y entrega rápida. El bot de economía que hicieron le dio otra vida al servidor, la gente no para de jugar.",
    rating: 5,
    sortOrder: 4,
  },
];

export const SETTINGS_SEED: Record<string, string> = {
  "brand.name": "Imperio Shop",
  "brand.tagline": "Bots · Hosting · Web",
  "brand.description":
    "Creamos bots de Discord, hosting y páginas web para comunidades y emprendimientos. Entrega rápida, soporte real y precios claros.",
  "contact.discord": "https://discord.gg/cffbceYF2",
  "contact.email": "ventas@imperioshopp.com",
  "contact.whatsapp": "",
  "payment.provider": "Tebex",
  // Métodos que se muestran en el sitio. Deben coincidir con los que Tebex
  // tiene activados en su checkout: tarjetas, Google Pay y PayPal.
  // Solo van los ACTIVOS: los desactivados no se muestran.
  "payment.methods": "tarjetas,googlepay,paypal",
  "payment.steps":
    "1) Elegí el plan que querés y creá tu cuenta.\n2) Confirmá el pedido y guardá tu código.\n3) Pagá con tarjeta, PayPal o el método que prefieras en la pantalla segura de Tebex.\n4) Apenas se confirma el pago, arrancamos con la entrega.",
  "payment.instructions":
    "El cobro lo procesa Tebex, la plataforma de pagos de la comunidad: podés pagar con tarjeta de crédito o débito, PayPal y más métodos. Apenas se confirma el pago, tu pedido pasa a producción y abrís tu ticket en Discord con tu código para que arranquemos.",
  "payment.account": "",
  "payment.qrUrl": "",
  "orders.prefix": "IMP",
  // Mensaje que ve el cliente apenas termina su pedido. Usá {code} para que se
  // reemplace automáticamente por el código del pedido.
  "orders.ticketMessage":
    "Abrí un ticket en nuestro Discord con tu código de pedido {code} y te atendemos al toque para crear tu bot, activar tu hosting o arrancar con tu página web. Si tenés dudas sobre un pago o un problema con la web, entrá a la sección de Soporte y te guiamos.",
  // Números que se muestran en el inicio. El de entregas se cuenta solo desde
  // los pedidos marcados como entregados en el panel.
  "stats.uptime": "99.9%",
  "stats.uptimeLabel": "Uptime del hosting",
  "stats.support": "24/7",
  "stats.supportLabel": "Soporte por Discord",
  "stats.deliveredLabel": "Proyectos entregados",
};
