/**
 * Carga inicial del catálogo, preguntas frecuentes, reseñas, configuración y
 * accesos del panel. Se ejecuta una sola vez: si ya hay servicios cargados no
 * vuelve a tocar la base de datos, así que editar desde el panel es seguro.
 */
import { eq, sql } from "drizzle-orm";
import { faqs, plans, services, settings, staffCodes, testimonials } from "../drizzle/schema";
import { CATALOG_SEED, FAQ_SEED, SETTINGS_SEED, TESTIMONIAL_SEED } from "./catalogData";
import { extractInsertId, getDb } from "./db";
import { codeHint, generateStaffCode, hashStaffCode } from "./staffAuth";

let seedPromise: Promise<void> | null = null;

export function ensureSeeded(): Promise<void> {
  if (!seedPromise) {
    seedPromise = runSeed().catch((error) => {
      seedPromise = null;
      throw error;
    });
  }
  return seedPromise;
}

async function runSeed(): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Seed] Base de datos no disponible, se omite la carga inicial");
    return;
  }

  /* ------------------------------- catálogo ------------------------------- */
  const existing = await db.select().from(services);
  let createdServices = 0;
  let createdPlans = 0;

  for (const entry of CATALOG_SEED) {
    const { plans: planList, ...serviceData } = entry;
    let serviceId = existing.find((row) => row.slug === serviceData.slug)?.id;

    if (!serviceId) {
      const result = await db.insert(services).values({
        slug: serviceData.slug,
        name: serviceData.name,
        tagline: serviceData.tagline,
        description: serviceData.description,
        imageUrl: serviceData.imageUrl,
        icon: serviceData.icon,
        badge: serviceData.badge,
        accent: serviceData.accent,
        deliveryTime: serviceData.deliveryTime,
        features: JSON.stringify(serviceData.features),
        sortOrder: serviceData.sortOrder,
        active: true,
      });
      serviceId = extractInsertId(result);
      createdServices += 1;
    }

    const existingPlans = await db
      .select({ name: plans.name })
      .from(plans)
      .where(eq(plans.serviceId, serviceId));
    const knownPlans = new Set(existingPlans.map((row) => row.name));

    for (const plan of planList) {
      if (knownPlans.has(plan.name)) continue;
      await db.insert(plans).values({
        serviceId,
        name: plan.name,
        priceCents: plan.priceCents,
        currency: "USD",
        billing: plan.billing,
        summary: plan.summary,
        specs: JSON.stringify(plan.specs),
        features: JSON.stringify(plan.features),
        popular: plan.popular,
        stockLabel: plan.stockLabel,
        sortOrder: plan.sortOrder,
        active: true,
      });
      createdPlans += 1;
    }
  }

  if (createdServices || createdPlans) {
    console.log(
      `[Seed] Catálogo sincronizado: ${createdServices} servicios y ${createdPlans} planes nuevos`,
    );
  }

  /* --------------------------------- faqs --------------------------------- */
  const existingFaqs = await db.select({ value: sql<number>`count(*)` }).from(faqs);
  if (Number(existingFaqs[0]?.value ?? 0) === 0) {
    await db.insert(faqs).values(FAQ_SEED.map((faq) => ({ ...faq, active: true })));
    console.log(`[Seed] Preguntas frecuentes cargadas: ${FAQ_SEED.length}`);
  }

  /* ------------------------------ testimonios ----------------------------- */
  const existingTestimonials = await db
    .select({ value: sql<number>`count(*)` })
    .from(testimonials);
  if (Number(existingTestimonials[0]?.value ?? 0) === 0) {
    await db
      .insert(testimonials)
      .values(TESTIMONIAL_SEED.map((item) => ({ ...item, active: true })));
    console.log(`[Seed] Reseñas cargadas: ${TESTIMONIAL_SEED.length}`);
  }

  /* ----------------------------- configuración ---------------------------- */
  const existingSettings = await db.select().from(settings);
  const knownKeys = new Set(existingSettings.map((row) => row.key));
  const missing = Object.entries(SETTINGS_SEED).filter(([key]) => !knownKeys.has(key));
  if (missing.length > 0) {
    await db.insert(settings).values(missing.map(([key, value]) => ({ key, value })));
    console.log(`[Seed] Configuración inicial cargada: ${missing.length} claves`);
  }

  /* --------------------------- accesos del panel -------------------------- */
  const existingCodes = await db.select({ value: sql<number>`count(*)` }).from(staffCodes);
  if (Number(existingCodes[0]?.value ?? 0) === 0) {
    const people = [
      { label: "Dueño", role: "owner" as const },
      { label: "Socio", role: "staff" as const },
    ];
    const generated: string[] = [];
    for (const person of people) {
      const code = generateStaffCode();
      generated.push(`${person.label}: ${code}`);
      await db.insert(staffCodes).values({
        label: person.label,
        codeHash: hashStaffCode(code),
        codeHint: codeHint(code),
        role: person.role,
        active: true,
        createdBy: "sistema",
      });
    }
    console.log("=================================================");
    console.log("[Seed] Códigos de acceso al panel generados:");
    generated.forEach((line) => console.log(`        ${line}`));
    console.log("        Guardalos: no se vuelven a mostrar.");
    console.log("=================================================");
  }
}
