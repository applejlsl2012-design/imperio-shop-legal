export const ENV = {
  appId: process.env.VITE_APP_ID ?? "",
  cookieSecret: process.env.JWT_SECRET ?? "",
  databaseUrl: process.env.DATABASE_URL ?? "",
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
  isProduction: process.env.NODE_ENV === "production",
  /**
   * URL pública del sitio (por ejemplo https://imperioshop.com). Sirve para
   * armar los enlaces de vuelta de Tebex con el dominio real cuando el sitio
   * está detrás de un proxy. Si queda vacía, se detecta desde la petición.
   */
  publicBaseUrl: process.env.PUBLIC_BASE_URL ?? "",
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? "",
  /** Envío de correo (Resend). Si falta la clave, el sitio sigue funcionando. */
  resendApiKey: process.env.RESEND_API_KEY ?? "",
  /** Remitente de los correos, por ejemplo "Imperio Shop <no-reply@tudominio.com>". */
  mailFrom: process.env.MAIL_FROM ?? "",
  /** Envío de correo con una cuenta de Gmail (opción sin dominio propio). */
  gmailUser: process.env.GMAIL_USER ?? "",
  gmailAppPassword: process.env.GMAIL_APP_PASSWORD ?? "",
  /**
   * SMTP propio (Zoho, Outlook o el hosting del dominio). Sirve para enviar
   * desde el correo del dominio, por ejemplo ventas@imperioshopp.com.
   */
  smtpHost: process.env.SMTP_HOST ?? "",
  smtpPort: process.env.SMTP_PORT ?? "",
  smtpUser: process.env.SMTP_USER ?? "",
  smtpPassword: process.env.SMTP_PASSWORD ?? "",
  /** Tebex: procesa los pagos (PayPal, tarjetas, Mercado Pago y más). */
  tebexPublicToken: process.env.TEBEX_PUBLIC_TOKEN ?? "",
  /** Clave privada de Tebex: da acceso total, solo se usa en el servidor. */
  tebexPrivateKey: process.env.TEBEX_PRIVATE_KEY ?? "",
  /** Secreto para validar la firma de los webhooks de pago. */
  tebexWebhookSecret: process.env.TEBEX_WEBHOOK_SECRET ?? "",
};
