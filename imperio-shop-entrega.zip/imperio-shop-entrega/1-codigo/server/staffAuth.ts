/**
 * Acceso privado del panel.
 *
 * El sitio público es abierto, pero el panel de gestión solo debe poder abrirlo
 * el dueño y su socio. Cada persona tiene su propio código de acceso, que se
 * guarda hasheado (nunca en texto plano) y se canjea por una cookie de sesión
 * firmada con HMAC-SHA256.
 */
import crypto from "node:crypto";
import { parse as parseCookieHeader } from "cookie";
import type { Request, Response } from "express";
import { ENV } from "./_core/env";

/**
 * Los navegadores rechazan `SameSite=None` sin `Secure`, así que en desarrollo
 * local (http) usamos `Lax` y en producción (https) `None`, que es lo que
 * necesita el preview embebido en un iframe.
 */
function cookieOptions(req: Request) {
  const forwarded = req.headers["x-forwarded-proto"];
  const proto = (Array.isArray(forwarded) ? forwarded[0] : forwarded)?.split(",")[0]?.trim();
  const secure = req.protocol === "https" || proto === "https";
  return {
    httpOnly: true,
    path: "/",
    sameSite: secure ? ("none" as const) : ("lax" as const),
    secure,
  };
}

export const STAFF_COOKIE = "imperio_staff";
/**
 * Cuánto dura el acceso una vez ingresado el código.
 *
 * Es largo a propósito: el panel es del dueño y de su socio, y volver a pedir
 * el código cada dos semanas solo molesta. Se puede cerrar sesión a mano desde
 * el propio panel cuando se quiera.
 */
const STAFF_SESSION_DAYS = 180;
const STAFF_SESSION_MS = STAFF_SESSION_DAYS * 24 * 60 * 60 * 1000;
const HASH_PREFIX = "scrypt";

export type StaffSession = {
  codeId: number;
  label: string;
  role: "owner" | "staff";
  exp: number;
};

/* ----------------------------- códigos de acceso --------------------------- */

export function hashStaffCode(code: string): string {
  const salt = crypto.randomBytes(16).toString("hex");
  const derived = crypto.scryptSync(normalizeStaffCode(code), salt, 32).toString("hex");
  return `${HASH_PREFIX}:${salt}:${derived}`;
}

/**
 * Deja el código en su forma canónica: sin espacios, sin guiones y en
 * mayúsculas. Así el mismo código funciona si la persona lo escribe como
 * "IMP-8T9F-3X4F", "imp 8t9f 3x4f" o "IMP8T9F3X4F".
 */
export function normalizeStaffCode(code: string): string {
  return code.replace(/[\s-]/g, "").toUpperCase();
}

/**
 * Variantes con las que se puede comparar un código. La primera es la forma
 * canónica actual (sin guiones). Las otras dos corresponden a cómo se
 * escribían los códigos antes de aceptar formatos flexibles, para no
 * invalidar los que ya estaban guardados.
 */
function codeVariants(code: string): string[] {
  const compact = normalizeStaffCode(code);
  const legacy = code.trim().toUpperCase();
  const variants = new Set<string>([compact, legacy]);

  // "IMP8T9F3X4F" → "IMP-8T9F-3X4F", el formato que usaban los códigos viejos.
  const match = /^(IMP)([A-Z0-9]{4})([A-Z0-9]{4})$/.exec(compact);
  if (match) variants.add(`${match[1]}-${match[2]}-${match[3]}`);

  return Array.from(variants);
}

export function verifyStaffCodeHash(code: string, stored: string): boolean {
  try {
    const [scheme, salt, digest] = stored.split(":");
    if (scheme !== HASH_PREFIX || !salt || !digest) return false;
    const b = Buffer.from(digest, "hex");
    for (const variant of codeVariants(code)) {
      const derived = crypto.scryptSync(variant, salt, 32).toString("hex");
      const a = Buffer.from(derived, "hex");
      if (a.length === b.length && crypto.timingSafeEqual(a, b)) return true;
    }
    return false;
  } catch {
    return false;
  }
}

/** Código legible tipo IMP-4F2K-9ALP (sin caracteres ambiguos). */
export function generateStaffCode(): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const block = () =>
    Array.from(
      { length: 4 },
      () => alphabet[crypto.randomInt(0, alphabet.length)],
    ).join("");
  return `IMP-${block()}-${block()}`;
}

export function codeHint(code: string): string {
  return `••••${code.slice(-4)}`;
}

/* --------------------------------- sesión ---------------------------------- */

function secret(): string {
  return ENV.cookieSecret || "imperio-shop-dev-secret";
}

function sign(payload: string): string {
  return crypto.createHmac("sha256", secret()).update(payload).digest("base64url");
}

export function issueStaffToken(session: Omit<StaffSession, "exp">): string {
  const payload = Buffer.from(
    JSON.stringify({ ...session, exp: Date.now() + STAFF_SESSION_MS }),
  ).toString("base64url");
  return `${payload}.${sign(payload)}`;
}

export function readStaffSession(req: Request): StaffSession | null {
  // El servidor no usa middleware de cookies: se lee el encabezado a mano,
  // igual que hace el SDK para la sesión de Manus.
  const header = req.headers?.cookie;
  const raw = header ? parseCookieHeader(header)[STAFF_COOKIE] : undefined;
  if (!raw || typeof raw !== "string") return null;

  const [payload, signature] = raw.split(".");
  if (!payload || !signature) return null;

  const expected = sign(payload);
  const a = Buffer.from(signature);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;

  try {
    const session = JSON.parse(Buffer.from(payload, "base64url").toString()) as StaffSession;
    if (!session?.exp || session.exp < Date.now()) return null;
    return session;
  } catch {
    return null;
  }
}

export function setStaffCookie(req: Request, res: Response, token: string) {
  res.cookie(STAFF_COOKIE, token, {
    ...cookieOptions(req),
    maxAge: STAFF_SESSION_MS,
  });
}

export function clearStaffCookie(req: Request, res: Response) {
  res.clearCookie(STAFF_COOKIE, {
    ...cookieOptions(req),
    maxAge: -1,
  });
}

/* ------------------------------ protección --------------------------------- */

const MAX_ATTEMPTS = 12;
/**
 * Ventana corta a propósito: si alguien se equivoca escribiendo su código,
 * espera un momento y vuelve a intentar en seguida, en lugar de quedar fuera
 * del panel durante diez minutos.
 */
const WINDOW_MS = 3 * 60 * 1000;
const attempts = new Map<string, { count: number; first: number }>();

export function rateLimitKey(req: Request): string {
  const forwarded = req.headers["x-forwarded-for"];
  const ip =
    (Array.isArray(forwarded) ? forwarded[0] : forwarded)?.split(",")[0]?.trim() ||
    req.ip ||
    "desconocida";
  return ip;
}

export function checkRateLimit(key: string): { allowed: boolean; retryInSeconds: number } {
  const now = Date.now();
  const entry = attempts.get(key);
  if (!entry || now - entry.first > WINDOW_MS) {
    attempts.set(key, { count: 1, first: now });
    return { allowed: true, retryInSeconds: 0 };
  }
  if (entry.count >= MAX_ATTEMPTS) {
    return {
      allowed: false,
      retryInSeconds: Math.ceil((WINDOW_MS - (now - entry.first)) / 1000),
    };
  }
  entry.count += 1;
  return { allowed: true, retryInSeconds: 0 };
}

export function resetRateLimit(key: string) {
  attempts.delete(key);
}

/** Libera todos los bloqueos. Se usa al reiniciar o al destrabar una sesión. */
export function resetAllRateLimits() {
  attempts.clear();
}
