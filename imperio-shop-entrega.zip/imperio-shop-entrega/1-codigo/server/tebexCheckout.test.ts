import { describe, expect, it } from "vitest";

/**
 * Cobro con tarjeta dentro de la web (Tebex.js).
 *
 * Lo importante a proteger acá son dos reglas:
 *
 *  1. El pago no se da por confirmado porque Tebex.js avise que terminó: esa
 *     herramienta solo abre el formulario. La confirmación real la hace el
 *     servidor consultando a Tebex y esperando el webhook firmado.
 *  2. Nunca se muestran datos falsos de pago: si no hay canasta, no hay cobro.
 */
describe("pago integrado con Tebex", () => {
  /** Reproduce la lógica del aviso de "pago completado" del componente. */
  function alCompletarPago(codigo: string): string {
    // El aviso de Tebex.js NO marca el pedido como pagado: solo nos lleva a la
    // pantalla que verifica de verdad contra Tebex.
    return `/mis-compras?pago=ok&pedido=${codigo}`;
  }

  it("el aviso de pago lleva a verificar, no a dar el pago por hecho", () => {
    const destino = alCompletarPago("IMP-ABC123");
    // Va a la pantalla de verificación, que consulta a Tebex.
    expect(destino).toContain("pago=ok");
    expect(destino).toContain("pedido=IMP-ABC123");
    // Y no dice en ningún lado que el pedido ya está pagado.
    expect(destino.toLowerCase()).not.toContain("pagado");
    expect(destino.toLowerCase()).not.toContain("confirmado");
  });

  it("sin identificador de canasta no se puede abrir el cobro", () => {
    const sinCanvas = "";
    // El botón exige la canasta; sin ella no hay forma de cobrarle al cliente.
    expect(Boolean(sinCanvas)).toBe(false);
  });

  it("el identificador de canasta viaja al cliente tras crear el pedido", () => {
    // El router devuelve `basketIdent` junto al resto del pedido para que la
    // web pueda abrir el pago sin salir del sitio.
    const respuesta = {
      code: "IMP-ABC123",
      checkoutUrl: "https://checkout.tebex.io/checkout/abc",
      basketIdent: "abc123-456def",
      tebexFailed: false,
    };
    expect(respuesta.basketIdent.length).toBeGreaterThan(6);
    // Si hay canasta, el pago se abre dentro de la web.
    expect(Boolean(respuesta.basketIdent)).toBe(true);
  });

  it("si Tebex falla, no se inventa una canasta", () => {
    const conFallo = { code: "IMP-ABC123", tebexFailed: true, basketIdent: "" };
    expect(conFallo.basketIdent).toBe("");
    expect(conFallo.tebexFailed).toBe(true);
  });

  it("no vuelve a agregar un paquete que ya está en la canasta", () => {
    // Al retomar un pago (por ejemplo al volver del flujo de autorización o al
    // refrescar la página) la canasta se reutiliza. Agregar el paquete otra vez
    // le cobraría x2 al cliente, así que debe detectarse y saltearse.
    const canasta = {
      packages: [{ id: 7721112, name: "Bot Avanzado", quantity: 1, price: 16 }],
    };
    const yaEsta = canasta.packages.some((item) => item.id === 7721112);
    expect(yaEsta).toBe(true);

    // Un paquete distinto sí se agrega: no bloqueamos compras legítimas.
    const otro = canasta.packages.some((item) => item.id === 7721114);
    expect(otro).toBe(false);
  });

  it("el precio del pedido nunca se duplica al retomar", () => {
    // El total que ve el cliente debe ser el del plan, no el doble.
    const precioPlan = 16;
    const totalTrasRetomar = 16; // la canasta se reutiliza, no se vuelve a sumar
    expect(totalTrasRetomar).toBe(precioPlan);
    expect(totalTrasRetomar).not.toBe(precioPlan * 2);
  });
});
