import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

/**
 * Pruebas del armado de canasta en Tebex.
 *
 * Regla que se comprueba: cuando la tienda exige iniciar sesión, la web NO
 * inventa un enlace de pago ni dice que se puede pagar: devuelve el enlace de
 * acceso para que el cliente se identifique y después retome la misma canasta.
 */

const fetchMock = vi.fn();
vi.stubGlobal("fetch", fetchMock);

process.env.TEBEX_PUBLIC_TOKEN = "tok-prueba-1234567890";
process.env.TEBEX_PRIVATE_KEY = "clave-privada-de-prueba";

import { fillTebexBasket, getTebexBasketAuthUrl } from "./tebex";

/** Respuesta HTTP simulada de Tebex. */
function respuesta(status: number, body: unknown) {
  return {
    ok: status >= 200 && status < 300,
    status,
    text: async () => (typeof body === "string" ? body : JSON.stringify(body)),
  };
}

describe("armado de la canasta de Tebex", () => {
  beforeEach(() => {
    fetchMock.mockReset();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it("devuelve el enlace de pago cuando la tienda cobra sin pedir login", async () => {
    fetchMock
      // La canasta todavía está vacía: se puede agregar el paquete.
      .mockResolvedValueOnce(
        respuesta(200, { data: { ident: "c-1", complete: false, packages: [], links: {} } }),
      )
      // Agregar el paquete funciona.
      .mockResolvedValueOnce(respuesta(200, { data: { ident: "c-1" } }))
      // Y la canasta ya trae su enlace de checkout.
      .mockResolvedValueOnce(
        respuesta(200, {
          data: { ident: "c-1", complete: false, packages: [], links: { checkout: "https://pago" } },
        }),
      );

    const result = await fillTebexBasket("c-1", 7700329, 1, "https://volver");

    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.data.checkoutUrl).toBe("https://pago");
      expect(result.data.needsAuth).toBe(false);
    }
  });

  it("pide identificarse cuando Tebex responde que hace falta login", async () => {
    fetchMock
      // La canasta está vacía antes de intentar agregar el paquete.
      .mockResolvedValueOnce(
        respuesta(200, { data: { ident: "c-1", complete: false, packages: [], links: {} } }),
      )
      // 422: el comprador tiene que iniciar sesión antes de agregar paquetes.
      .mockResolvedValueOnce(
        respuesta(422, {
          status: 422,
          title: "Request payload error",
          detail: "User must login before adding packages to basket",
        }),
      )
      // Tebex informa el proveedor de acceso disponible.
      .mockResolvedValueOnce(
        respuesta(200, [{ name: "FiveM", url: "https://ident.tebex.io/fivem?return=x" }]),
      );

    const result = await fillTebexBasket("c-1", 7700329, 1, "https://volver");

    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.data.needsAuth).toBe(true);
      expect(result.data.authUrl).toContain("ident.tebex.io");
      expect(result.data.authProvider).toBe("FiveM");
      // Nunca inventamos un checkout que no existe.
      expect(result.data.checkoutUrl).toBe("");
    }
  });

  it("no oculta un error real de Tebex", async () => {
    fetchMock
      // La lectura inicial funciona; el error real ocurre al agregar el paquete.
      .mockResolvedValueOnce(
        respuesta(200, { data: { ident: "c-1", complete: false, packages: [], links: {} } }),
      )
      .mockResolvedValueOnce(respuesta(500, { title: "Error interno", detail: "Tebex no disponible" }));

    const result = await fillTebexBasket("c-1", 7700329, 1, "https://volver");

    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.error).toContain("Tebex no disponible");
  });

  it("lee el enlace de acceso con el returnUrl que le pasamos", async () => {
    fetchMock.mockResolvedValueOnce(
      respuesta(200, [{ name: "FiveM", url: "https://ident.tebex.io/fivem?return=ok" }]),
    );

    const result = await getTebexBasketAuthUrl("c-1", "https://misitio/volver");

    expect(result.ok).toBe(true);
    const url = String(fetchMock.mock.calls[0][0]);
    expect(url).toContain("/baskets/c-1/auth");
    expect(url).toContain("returnUrl=");
  });
});
