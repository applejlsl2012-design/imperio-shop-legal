/**
 * Pruebas del acceso del equipo a la compra.
 *
 * Lo importante: el dueño y su socio pueden probar la compra con su sesión del
 * panel, y el pedido de prueba nunca se marca pagado sin que Tebex lo confirme.
 */
import { beforeEach, describe, expect, it, vi } from "vitest";

const order = {
  id: 1,
  code: "IMP-TEST01",
  amountCents: 800,
  currency: "USD",
  status: "pending_payment",
  staffNote: "Pedido de prueba.",
  payerAccount: "",
  tebexBasketIdent: "basket-1",
  tebexPaymentMethod: "",
  tebexTransactionId: "",
  customerId: null,
};

const getOrderByCode = vi.fn(async () => ({ ...order }));
const updateOrderPayment = vi.fn(async () => undefined);
const getTebexBasket = vi.fn(async () => ({ ok: true, data: { complete: false } }));
const logActivity = vi.fn();

vi.mock("./db", () => ({
  getOrderByCode: (...args: unknown[]) => getOrderByCode(...(args as [])),
  updateOrderPayment: (...args: unknown[]) => updateOrderPayment(...(args as [])),
}));
vi.mock("./tebex", () => ({
  getTebexBasket: (...args: unknown[]) => getTebexBasket(...(args as [])),
}));
vi.mock("./activity", () => ({
  logActivity: (...args: unknown[]) => logActivity(...(args as [])),
}));

const { checkStaffTestPayment } = await import("./staffPurchase");

describe("verificación del pago desde el panel", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    getOrderByCode.mockResolvedValue({ ...order });
    getTebexBasket.mockResolvedValue({ ok: true, data: { complete: false } });
  });

  it("avisa cuando no encuentra el pedido", async () => {
    getOrderByCode.mockResolvedValue(undefined as never);
    const r = await checkStaffTestPayment("IMP-NOEXISTE");
    expect(r.status).toBe("unavailable");
  });

  it("no da por pagado un pedido todavía pendiente", async () => {
    const r = await checkStaffTestPayment("IMP-TEST01");
    expect(r.status).toBe("pending");
    expect(updateOrderPayment).not.toHaveBeenCalled();
  });

  it("confirma el pago solo cuando Tebex marca la canasta completa", async () => {
    getTebexBasket.mockResolvedValue({ ok: true, data: { complete: true } });
    getOrderByCode
      .mockResolvedValueOnce({ ...order })
      .mockResolvedValueOnce({ ...order, status: "paid", tebexPaymentMethod: "Tarjeta" });

    const r = await checkStaffTestPayment("IMP-TEST01");
    expect(r.status).toBe("confirmed");
    expect(r.method).toBe("Tarjeta");
    expect(updateOrderPayment).toHaveBeenCalledOnce();
    const [, patch, actor] = updateOrderPayment.mock.calls[0] as unknown as [
      number,
      { status: string },
      string,
    ];
    expect(patch.status).toBe("paid");
    expect(actor).toBe("verificacion");
  });

  it("ya confirmado antes, no vuelve a consultar a Tebex", async () => {
    getOrderByCode.mockResolvedValue({ ...order, status: "paid", tebexTransactionId: "tbx-1" });
    const r = await checkStaffTestPayment("IMP-TEST01");
    expect(r.status).toBe("confirmed");
    expect(r.transactionId).toBe("tbx-1");
    expect(getTebexBasket).not.toHaveBeenCalled();
  });

  it("sin canasta avisa que no hay pago que verificar", async () => {
    getOrderByCode.mockResolvedValue({ ...order, tebexBasketIdent: "" });
    const r = await checkStaffTestPayment("IMP-TEST01");
    expect(r.status).toBe("unavailable");
  });

  it("si Tebex no responde, deja el pedido en espera", async () => {
    getTebexBasket.mockResolvedValue({ ok: false, error: "sin respuesta" } as never);
    const r = await checkStaffTestPayment("IMP-TEST01");
    expect(r.status).toBe("pending");
    expect(updateOrderPayment).not.toHaveBeenCalled();
  });
});