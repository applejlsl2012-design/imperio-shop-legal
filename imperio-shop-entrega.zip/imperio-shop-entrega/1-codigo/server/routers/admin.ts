/**
 * Panel privado. Solo accesible con la sesión de equipo (código de acceso),
 * que es distinta del login de Manus: el dueño y su socio entran con su propio
 * código desde /panel.
 */
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { hashPassword } from "../customerAuth";
import {
  cancelInvitationById,
  deleteReview,
  findCustomerByEmail,
  getCustomerById,
  createOrder,
  createStaffCode,
  deletePlan,
  deleteService,
  deleteStaffCode,
  getCatalog,
  getActivityStats,
  getInvitationStats,
  createCustomer,
  listPendingSignups,
  consumeVerificationCode,
  getOrderById,
  getOrderEvents,
  getPlanById,
  getServiceById,
  getOrderStats,
  getReviewById,
  getReviewStats,
  getSettingsMap,
  listCustomerOrders,
  listCustomers,
  listPendingInvitations,
  listOrders,
  listReviews,
  listStaffCodes,
  listStaffLogins,
  setCustomerActive,
  updateCustomerPassword,
  setSetting,
  setReviewFeatured,
  setReviewReply,
  setReviewStatus,
  setStaffCodeActive,
  updateOrderPayment,
  updateOrderStatus,
  upsertPlan,
  upsertService,
} from "../db";
import { createCustomerInvitation } from "../accountVerification";
import { getActivityFeed, logActivity } from "../activity";
import { makeOrderCode } from "../orderCode";
import {
  activeProvider,
  emailConfigured,
  providerLabel,
  sendTestEmail,
} from "../email";
import { ENV } from "../_core/env";
import { checkStaffTestPayment } from "../staffPurchase";
import { normalizeEmail } from "../customerAuth";
import {
  checkRateLimit,
  clearStaffCookie,
  codeHint,
  generateStaffCode,
  hashStaffCode,
  issueStaffToken,
  rateLimitKey,
  readStaffSession,
  resetRateLimit,
  setStaffCookie,
  verifyStaffCodeHash,
  type StaffSession,
} from "../staffAuth";
import { publicProcedure, router } from "../_core/trpc";
import { ensureSeeded } from "../seed";
import { findActiveStaffCodes, logStaffLogin, touchStaffCode } from "../db";

/** Procedimiento que exige una sesión de equipo válida. */
const staffProcedure = publicProcedure.use(async ({ ctx, next }) => {
  const session = readStaffSession(ctx.req);
  if (!session) {
    throw new TRPCError({
      code: "UNAUTHORIZED",
      message: "Tu sesión del panel venció. Volvé a ingresar tu código.",
    });
  }
  return next({ ctx: { ...ctx, staff: session } as typeof ctx & { staff: StaffSession } });
});

/**
 * Solo el dueño. Se usa para lo más sensible: crear o eliminar accesos del
 * equipo, ver la bitácora de ingresos y cambiar la configuración del sitio.
 * El socio (rol `staff`) trabaja con pedidos y catálogo, pero no administra
 * personas ni credenciales.
 */
const ownerProcedure = staffProcedure.use(({ ctx, next }) => {
  if (ctx.staff.role !== "owner") {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "Esta sección es solo para el dueño de la cuenta",
    });
  }
  return next({ ctx });
});

/** Los permisos que viajan al cliente para adaptar la interfaz al rol. */
function permissionsFor(role: "owner" | "staff") {
  const owner = role === "owner";
  return {
    role,
    isOwner: owner,
    canManageOrders: true,
    canManageCatalog: true,
    canViewCustomers: true,
    canManageSettings: owner,
    canManageAccess: owner,
    canViewLogins: owner,
  };
}

export const adminRouter = router({
  /* -------------------------------- sesión -------------------------------- */
  session: router({
    me: publicProcedure.query(async ({ ctx }) => {
      const session = readStaffSession(ctx.req);
      if (!session) return { authenticated: false as const };
      return {
        authenticated: true as const,
        label: session.label,
        role: session.role,
        permissions: permissionsFor(session.role),
      };
    }),

    login: publicProcedure
      .input(z.object({ code: z.string().trim().min(6).max(40) }))
      .mutation(async ({ input, ctx }) => {
        await ensureSeeded();

        const ip = rateLimitKey(ctx.req);
        const limit = checkRateLimit(ip);
        if (!limit.allowed) {
          throw new TRPCError({
            code: "TOO_MANY_REQUESTS",
            message: `Demasiados intentos seguidos. Esperá ${Math.max(1, Math.ceil(limit.retryInSeconds / 60))} minuto(s) y volvé a probar. Si no te acordás del código, pedile al dueño que genere uno nuevo desde Accesos.`,
          });
        }

        const codes = await findActiveStaffCodes();
        const match = codes.find((entry) => verifyStaffCodeHash(input.code, entry.codeHash));

        await logStaffLogin({
          label: match?.label ?? "intento fallido",
          success: Boolean(match),
          ip,
          userAgent: String(ctx.req.headers["user-agent"] ?? ""),
        });

        if (!match) {
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "Código incorrecto. Verificá que esté bien escrito.",
          });
        }

        resetRateLimit(ip);
        await touchStaffCode(match.id);
        const token = issueStaffToken({
          codeId: match.id,
          label: match.label,
          role: match.role,
        });
        setStaffCookie(ctx.req, ctx.res, token);

        return {
          label: match.label,
          role: match.role,
          permissions: permissionsFor(match.role),
        };
      }),

    logout: publicProcedure.mutation(({ ctx }) => {
      clearStaffCookie(ctx.req, ctx.res);
      return { success: true };
    }),
  }),

  /* -------------------------------- tablero ------------------------------- */
  overview: staffProcedure.query(async () => {
    const [stats, recent, logins] = await Promise.all([
      getOrderStats(),
      listOrders({ limit: 8 }),
      listStaffLogins(8),
    ]);
    return {
      stats,
      recentOrders: recent.rows,
      logins: logins.map((row) => ({
        label: row.label,
        success: row.success,
        createdAt: row.createdAt,
      })),
    };
  }),

  /* -------------------------------- clientes ------------------------------ */
  customers: router({
    /** Bitácora de la web: todo lo que pasa en el sitio público. */
    activity: staffProcedure
      .input(
        z.object({
          kind: z.string().max(60).default("all"),
          limit: z.number().int().min(1).max(200).default(60),
        }),
      )
      .query(async ({ input }) => {
        const [feed, stats] = await Promise.all([
          getActivityFeed(input),
          getActivityStats(7),
        ]);
        return { stats, activity: feed };
      }),

    /**
     * Altas que quedaron sin confirmar (típicamente porque el correo todavía
     * no está conectado). El equipo puede habilitarlas a mano.
     */
    pendingSignups: staffProcedure.query(async () => {
      const rows = await listPendingSignups({ limit: 50 });
      return rows.map((row) => ({
        id: row.id,
        email: row.email,
        name: row.pendingName,
        discord: row.pendingDiscord,
        createdAt: row.createdAt,
        expired: row.expiresAt.getTime() < Date.now(),
      }));
    }),

    /**
     * Habilita a mano una cuenta que quedó pendiente.
     *
     * Solo el dueño la usa: crea la cuenta con la contraseña que la persona
     * eligió al registrarse, así puede entrar sin depender del correo.
     */
    approvePendingSignup: ownerProcedure
      .input(z.object({ email: z.string().trim().email().max(320) }))
      .mutation(async ({ input, ctx }) => {
        const email = normalizeEmail(input.email);
        const rows = await listPendingSignups({ limit: 200 });
        const pending = rows.find((row) => row.email === email);
        if (!pending) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "No encontramos un registro pendiente para ese correo",
          });
        }
        if (!pending.pendingPasswordHash) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "Ese registro no tiene contraseña guardada; pedile que se registre de nuevo",
          });
        }

        const existing = await findCustomerByEmail(email);
        if (existing) {
          await consumeVerificationCode(pending.id);
          throw new TRPCError({
            code: "CONFLICT",
            message: "Ese correo ya tiene una cuenta creada",
          });
        }

        const customerId = await createCustomer({
          email,
          name: pending.pendingName,
          passwordHash: pending.pendingPasswordHash,
          discord: pending.pendingDiscord,
          provider: "email",
        });
        await consumeVerificationCode(pending.id);

        const actor = ctx.staff?.label ?? "El equipo";
        logActivity({
          kind: "cuenta.confirmada",
          title: `Cuenta habilitada a mano: ${pending.pendingName}`,
          detail: `${actor} habilitó la cuenta de ${email} sin esperar el código por correo.`,
          actor,
          actorEmail: email,
          customerId,
          req: ctx.req,
        });

        return { success: true, customerId, name: pending.pendingName } as const;
      }),


    list: staffProcedure
      .input(
        z.object({
          search: z.string().default(""),
          limit: z.number().int().min(1).max(200).default(100),
        }),
      )
      .query(async ({ input }) => listCustomers(input)),

    detail: staffProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .query(async ({ input }) => {
        const customer = await getCustomerById(input.id);
        if (!customer) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Cliente no encontrado" });
        }
        const orders = await listCustomerOrders(input.id);
        return {
          customer: {
            id: customer.id,
            name: customer.name,
            email: customer.email,
            discord: customer.discord,
            provider: customer.provider,
            active: customer.active,
            createdAt: customer.createdAt,
            lastSignedIn: customer.lastSignedIn,
          },
          orders,
        };
      }),

    /** Invitaciones enviadas que todavía no se activaron. */
    invitations: staffProcedure
      .input(
        z.object({
          search: z.string().default(""),
          limit: z.number().int().min(1).max(100).default(50),
        }),
      )
      .query(async ({ input }) => {
        const [rows, stats] = await Promise.all([
          listPendingInvitations(input),
          getInvitationStats(),
        ]);
        return {
          stats,
          invitations: rows.map((row) => ({
            id: row.id,
            email: row.email,
            name: row.pendingName,
            invitedBy: row.invitedBy,
            expired: row.expiresAt.getTime() < Date.now(),
            expiresAt: row.expiresAt,
            createdAt: row.createdAt,
          })),
        };
      }),

    /**
     * Crea la cuenta de un cliente desde el panel: le llega un código por
     * correo y la cuenta queda lista cuando él elige su contraseña.
     */
    invite: staffProcedure
      .input(
        z.object({
          email: z.string().trim().email("Ingresá un correo válido").max(320),
          name: z.string().trim().min(2, "Ingresá el nombre").max(160),
        }),
      )
      .mutation(async ({ input, ctx }) => {
        try {
          const invitedBy = ctx.staff?.label ?? "El equipo";
          const delivery = await createCustomerInvitation({
            email: normalizeEmail(input.email),
            name: input.name.trim(),
            invitedBy,
          });
          logActivity({
            kind: "cuenta.invitada",
            title: `Invitación enviada a ${input.name.trim()}`,
            detail: `${invitedBy} creó la cuenta de ${normalizeEmail(input.email)}${
              delivery.mode === "email" ? " y le envió el código por correo." : " (código entregado a mano)."
            }`,
            actor: invitedBy,
            actorEmail: normalizeEmail(input.email),
            meta: { deliveryMode: delivery.mode },
            req: ctx.req,
          });
          return delivery;
        } catch (error) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message:
              error instanceof Error ? error.message : "No pudimos enviar la invitación",
          });
        }
      }),

    /** Reenvía la invitación a quien todavía no activó su cuenta. */
    resendInvitation: staffProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(async ({ input, ctx }) => {
        const rows = await listPendingInvitations({ limit: 200 });
        const row = rows.find((item) => item.id === input.id);
        if (!row) {
          throw new TRPCError({ code: "NOT_FOUND", message: "No encontramos esa invitación" });
        }
        return createCustomerInvitation({
          email: row.email,
          name: row.pendingName,
          invitedBy: ctx.staff?.label ?? "El equipo",
        });
      }),

    /** Cancela una invitación pendiente. */
    cancelInvitation: staffProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(async ({ input }) => {
        await cancelInvitationById(input.id);
        return { success: true };
      }),

    /** Activa o desactiva una cuenta de cliente. */
    setActive: staffProcedure
      .input(z.object({ id: z.number().int().positive(), active: z.boolean() }))
      .mutation(async ({ input }) => {
        await setCustomerActive(input.id, input.active);
        return { success: true };
      }),

    /**
     * Restablece la contraseña de un cliente.
     *
     * Lo usa el dueño cuando alguien no puede entrar y el correo todavía no
     * está conectado. El equipo escribe la contraseña nueva y la persona la
     * cambia después desde su cuenta. Nunca se guarda en texto: solo el hash.
     */
    resetPassword: ownerProcedure
      .input(
        z.object({
          id: z.number().int().positive(),
          password: z.string().min(8, "Usá al menos 8 caracteres").max(128),
        }),
      )
      .mutation(async ({ input, ctx }) => {
        const customer = await getCustomerById(input.id);
        if (!customer) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Cliente no encontrado" });
        }

        await updateCustomerPassword(input.id, hashPassword(input.password));

        const actor = ctx.staff?.label ?? "El equipo";
        logActivity({
          kind: "cuenta.recuperacion",
          title: `Contraseña restablecida: ${customer.name}`,
          detail: `${actor} restableció la contraseña de ${customer.email}.`,
          actor,
          actorEmail: customer.email,
          customerId: customer.id,
          req: ctx.req,
        });

        return { success: true } as const;
      }),
  }),

  /* --------------------------------- pedidos ------------------------------ */
  orders: router({
    list: staffProcedure
      .input(
        z.object({
          status: z.string().default("all"),
          search: z.string().default(""),
          limit: z.number().int().min(1).max(100).default(50),
          offset: z.number().int().min(0).default(0),
        }),
      )
      .query(async ({ input }) => listOrders(input)),

    detail: staffProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .query(async ({ input }) => {
        const order = await getOrderById(input.id);
        if (!order) throw new TRPCError({ code: "NOT_FOUND", message: "Pedido no encontrado" });
        const events = await getOrderEvents(input.id);
        return { order, events };
      }),

    /**
     * Verifica si el pago de un pedido llegó de verdad a Tebex.
     *
     * Lo usa el equipo al probar una compra desde la web: solo se marca pagado
     * cuando Tebex confirma la canasta, nunca porque el pago se haya iniciado.
     */
    checkPayment: staffProcedure
      .input(z.object({ code: z.string().trim().min(4).max(24) }))
      .query(async ({ input }) => checkStaffTestPayment(input.code.trim().toUpperCase())),

    update: staffProcedure
      .input(
        z.object({
          id: z.number().int().positive(),
          status: z
            .enum([
              "pending_payment",
              "payment_review",
              "paid",
              "in_progress",
              "delivered",
              "cancelled",
            ])
            .optional(),
          staffNote: z.string().max(2000).optional(),
          payerAccount: z.string().max(160).optional(),
          paymentReference: z.string().max(200).optional(),
        }),
      )
      .mutation(async ({ input, ctx }) => {
        const staff = ctx.staff;
        const { id, ...patch } = input;
        await updateOrderPayment(id, patch, staff?.label ?? "panel");
        return { success: true };
      }),

    advance: staffProcedure
      .input(
        z.object({
          id: z.number().int().positive(),
          status: z.enum([
            "pending_payment",
            "payment_review",
            "paid",
            "in_progress",
            "delivered",
            "cancelled",
          ]),
          note: z.string().max(2000).default(""),
        }),
      )
      .mutation(async ({ input, ctx }) => {
        const staff = ctx.staff;
        await updateOrderStatus(input.id, input.status, input.note, staff?.label ?? "panel");
        return { success: true };
      }),

    /**
     * Crea un pedido de prueba.
     *
     * Sirve para revisar el panel y ensayar la entrega sin depender de una
     * compra real ni de que la tienda de pagos pueda cobrar. El pedido queda
     * marcado como prueba en la nota interna y el historial.
     */
    createTest: staffProcedure
      .input(
        z.object({
          planId: z.number().int().positive(),
          customerName: z.string().trim().min(2).max(120),
          customerEmail: z.string().trim().email().max(160),
          customerDiscord: z.string().trim().max(80).default(""),
          customerNote: z.string().trim().max(1000).default(""),
          status: z
            .enum([
              "pending_payment",
              "payment_review",
              "paid",
              "in_progress",
              "delivered",
              "cancelled",
            ])
            .default("pending_payment"),
        }),
      )
      .mutation(async ({ input, ctx }) => {
        const staff = ctx.staff;
        const plan = await getPlanById(input.planId);
        if (!plan) {
          throw new TRPCError({ code: "NOT_FOUND", message: "El plan elegido no existe" });
        }
        const service = await getServiceById(plan.serviceId);
        if (!service) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Servicio no encontrado" });
        }

        const settings = await getSettingsMap();
        const code = makeOrderCode(settings["orders.prefix"] ?? "IMP");

        // El pedido de prueba no pasa por la tienda de pagos: queda a nombre
        // del equipo y se distingue con una nota interna.
        const orderId = await createOrder({
          code,
          serviceId: service.id,
          serviceName: service.name,
          planId: plan.id,
          planName: plan.name,
          amountCents: plan.priceCents,
          currency: plan.currency,
          billing: plan.billing,
          customerName: input.customerName,
          customerEmail: input.customerEmail,
          customerDiscord: input.customerDiscord,
          customerNote: input.customerNote,
          paymentMethod: "manual",
          payerAccount: "",
          paymentReference: "",
          tebexBasketIdent: "",
          tebexTransactionId: "",
          tebexPaymentMethod: "",
          status: input.status,
          staffNote: `Pedido de prueba creado por ${staff?.label ?? "el equipo"}. No corresponde a un cobro real.`,
          userId: null,
          customerId: null,
        });

        logActivity({
          kind: "pedido.prueba",
          title: `Pedido de prueba ${code}`,
          detail: `${staff?.label ?? "El equipo"} creó un pedido de prueba de ${service.name} · ${plan.name}.`,
          actor: staff?.label ?? "Panel",
          actorEmail: "",
          customerId: null,
          orderId,
          meta: { service: service.name, plan: plan.name, prueba: true },
          req: ctx.req,
        });

        return { code, id: orderId };
      }),
  }),

  /* -------------------------------- catálogo ------------------------------ */
  catalog: router({
    list: staffProcedure.query(async () => {
      const catalog = await getCatalog({ includeInactive: true });
      return catalog.map((service) => ({
        ...service,
        features: safeJson<string[]>(service.features, []),
        plans: service.plans.map((plan) => ({
          ...plan,
          specs: safeJson<string[]>(plan.specs, []),
          features: safeJson<string[]>(plan.features, []),
        })),
      }));
    }),

    saveService: staffProcedure
      .input(
        z.object({
          id: z.number().int().positive().optional(),
          slug: z
            .string()
            .trim()
            .min(2)
            .max(80)
            .regex(/^[a-z0-9-]+$/, "Usá minúsculas, números y guiones"),
          name: z.string().trim().min(2).max(120),
          tagline: z.string().trim().max(220).default(""),
          description: z.string().trim().max(4000).default(""),
          imageUrl: z.string().trim().max(500).default(""),
          icon: z.string().trim().max(40).default("package"),
          badge: z.string().trim().max(40).default(""),
          accent: z.string().trim().max(20).default("#FF1F3D"),
          features: z.array(z.string().trim().max(200)).max(12).default([]),
          deliveryTime: z.string().trim().max(60).default(""),
          sortOrder: z.number().int().min(0).max(999).default(0),
          active: z.boolean().default(true),
        }),
      )
      .mutation(async ({ input }) => {
        const id = await upsertService({
          ...input,
          features: JSON.stringify(input.features),
        });
        return { id };
      }),

    savePlan: staffProcedure
      .input(
        z.object({
          id: z.number().int().positive().optional(),
          serviceId: z.number().int().positive(),
          name: z.string().trim().min(2).max(120),
          priceCents: z.number().int().min(0).max(100_000_000),
          currency: z.string().trim().max(8).default("USD"),
          billing: z.enum(["once", "monthly"]).default("once"),
          /** ID del paquete en Tebex. Sin valor, el plan se cobra a mano. */
          tebexPackageId: z.number().int().positive().optional(),
          summary: z.string().trim().max(240).default(""),
          specs: z.array(z.string().trim().max(200)).max(15).default([]),
          features: z.array(z.string().trim().max(200)).max(15).default([]),
          popular: z.boolean().default(false),
          stockLabel: z.string().trim().max(60).default(""),
          sortOrder: z.number().int().min(0).max(999).default(0),
          active: z.boolean().default(true),
        }),
      )
      .mutation(async ({ input }) => {
        const id = await upsertPlan({
          ...input,
          specs: JSON.stringify(input.specs),
          features: JSON.stringify(input.features),
        });
        return { id };
      }),

    deletePlan: staffProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(async ({ input }) => {
        await deletePlan(input.id);
        return { success: true };
      }),

    deleteService: staffProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(async ({ input }) => {
        await deleteService(input.id);
        return { success: true };
      }),
  }),

  /* -------------------------------- reseñas -------------------------------- */
  reviews: router({
    /** Lista de reseñas para moderar, con el resumen de estados. */
    list: staffProcedure
      .input(
        z
          .object({
            status: z.enum(["pending", "approved", "rejected"]).optional(),
          })
          .optional(),
      )
      .query(async ({ input }) => {
        const [rows, stats] = await Promise.all([
          listReviews({ status: input?.status, limit: 200 }),
          getReviewStats(),
        ]);
        return {
          stats,
          reviews: rows.map((row) => ({
            id: row.id,
            author: row.authorName,
            email: row.authorEmail,
            serviceName: row.serviceName,
            rating: row.rating,
            comment: row.comment,
            status: row.status,
            featured: row.featured,
            reply: row.reply,
            createdAt: row.createdAt,
            publishedAt: row.publishedAt,
          })),
        };
      }),

    /** Aprobar, rechazar o devolver a revisión. */
    setStatus: staffProcedure
      .input(
        z.object({
          id: z.number().int().positive(),
          status: z.enum(["pending", "approved", "rejected"]),
        }),
      )
      .mutation(async ({ input }) => {
        const row = await getReviewById(input.id);
        if (!row) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Reseña no encontrada" });
        }
        await setReviewStatus(input.id, input.status);
        return { success: true };
      }),

    /** Destacar o quitar de la vidriera del inicio. */
    setFeatured: staffProcedure
      .input(z.object({ id: z.number().int().positive(), featured: z.boolean() }))
      .mutation(async ({ input }) => {
        await setReviewFeatured(input.id, input.featured);
        return { success: true };
      }),

    /** Respuesta pública del equipo. */
    setReply: staffProcedure
      .input(z.object({ id: z.number().int().positive(), reply: z.string().trim().max(600) }))
      .mutation(async ({ input }) => {
        await setReviewReply(input.id, input.reply);
        return { success: true };
      }),

    remove: staffProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(async ({ input }) => {
        await deleteReview(input.id);
        return { success: true };
      }),
  }),

  /* ------------------------------ configuración --------------------------- */
  settings: router({
    get: ownerProcedure.query(async () => getSettingsMap()),
    /**
     * Estado del servicio de correo: por dónde salen los códigos de registro y
     * de recuperación de contraseña. Si no hay nada configurado, el panel lo
     * avisa para saber que los códigos quedan a mano en lugar de llegar.
     */
    emailStatus: ownerProcedure.query(async () => ({
      configured: emailConfigured(),
      provider: activeProvider(),
      label: providerLabel(),
      /** El remitente que va a ver el cliente en su bandeja de entrada. */
      from: ENV.mailFrom || ENV.smtpUser || ENV.gmailUser || "",
    })),
    /**
     * Envía un correo de prueba al correo que indique el dueño, para confirmar
     * que el envío funciona sin crear cuentas ni recuperar contraseñas.
     */
    emailTest: ownerProcedure
      .input(z.object({ to: z.string().trim().email().max(320) }))
      .mutation(async ({ input, ctx }) => {
        const destino = normalizeEmail(input.to);
        const resultado = await sendTestEmail(destino);
        logActivity({
          kind: "config.actualizada",
          title: `${ctx.staff?.label ?? "El equipo"} probó el envío de correo`,
          detail: resultado.sent
            ? `Prueba enviada a ${destino} por ${providerLabel()}.`
            : `La prueba falló (${resultado.reason}) hacia ${destino}.`,
          actor: ctx.staff?.label ?? "El equipo",
          actorEmail: destino,
          req: ctx.req,
        });
        if (!resultado.sent) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message:
              resultado.reason === "sin-clave"
                ? "Todavía no hay un correo configurado. Cargá las credenciales y volvé a probar."
                : `No se pudo enviar: ${resultado.detail ?? "error desconocido"}`,
          });
        }
        return { sent: true, via: resultado.via, label: providerLabel() };
      }),
    save: ownerProcedure
      .input(z.object({ entries: z.record(z.string().max(80), z.string().max(4000)) }))
      .mutation(async ({ input, ctx }) => {
        for (const [key, value] of Object.entries(input.entries)) {
          await setSetting(key, value);
        }
        logActivity({
          kind: "config.actualizada",
          title: `${ctx.staff?.label ?? "El equipo"} actualizó la configuración`,
          detail: `Cambió: ${Object.keys(input.entries).join(", ")}`,
          actor: ctx.staff?.label ?? "El equipo",
          meta: { keys: Object.keys(input.entries) },
          req: ctx.req,
        });
        return { success: true };
      }),
  }),

  /* -------------------------------- accesos ------------------------------- */
  staff: router({
    list: ownerProcedure.query(async () => {
      const rows = await listStaffCodes();
      return rows.map((row) => ({
        id: row.id,
        label: row.label,
        hint: row.codeHint,
        role: row.role,
        active: row.active,
        useCount: row.useCount,
        lastUsedAt: row.lastUsedAt,
        createdAt: row.createdAt,
      }));
    }),

    create: ownerProcedure
      .input(
        z.object({
          label: z.string().trim().min(2).max(120),
          role: z.enum(["owner", "staff"]).default("staff"),
        }),
      )
      .mutation(async ({ input, ctx }) => {
        const staff = ctx.staff;
        const code = generateStaffCode();
        await createStaffCode({
          label: input.label,
          codeHash: hashStaffCode(code),
          codeHint: codeHint(code),
          role: input.role,
          createdBy: staff?.label ?? "panel",
        });
        return { code };
      }),

    toggle: ownerProcedure
      .input(z.object({ id: z.number().int().positive(), active: z.boolean() }))
      .mutation(async ({ input }) => {
        await setStaffCodeActive(input.id, input.active);
        return { success: true };
      }),

    remove: ownerProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(async ({ input, ctx }) => {
        const staff = ctx.staff;
        if (staff?.codeId === input.id) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "No podés eliminar el código con el que estás dentro.",
          });
        }
        await deleteStaffCode(input.id);
        return { success: true };
      }),
  }),
});

function safeJson<T>(value: string, fallback: T): T {
  try {
    const parsed = JSON.parse(value);
    return (parsed ?? fallback) as T;
  } catch {
    return fallback;
  }
}
