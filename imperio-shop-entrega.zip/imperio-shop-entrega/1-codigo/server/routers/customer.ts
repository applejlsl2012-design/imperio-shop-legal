/**
 * Cuentas de clientes: registro, ingreso y perfil.
 *
 * Cada persona que compra crea su cuenta con correo y contraseña, y cada
 * compra queda vinculada a esa cuenta para que quede registrada en el panel
 * de administración.
 */
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { publicProcedure, router } from "../_core/trpc";
import {
  createReview,
  createCustomer,
  findReviewByOrder,
  findCustomerByEmail,
  getCustomerById,
  listCustomerReviews,
  listCustomerOrders,
  touchCustomer,
  updateCustomerProfile,
} from "../db";
import {
  checkCustomerRateLimit,
  clearCustomerCookie,
  customerRateLimitKey,
  hashPassword,
  issueCustomerToken,
  normalizeEmail,
  readCustomerSession,
  resetCustomerRateLimit,
  setCustomerCookie,
  verifyPassword,
} from "../customerAuth";
import {
  activateCustomerInvitation,
  confirmSignupVerification,
  startSignupVerification,
} from "../accountVerification";
import { checkOrderPayment } from "../paymentVerification";
import { confirmPasswordReset, startPasswordReset } from "../passwordReset";
import { logActivity } from "../activity";

/** Procedimiento que exige una cuenta de cliente con sesión activa. */
const customerProcedure = publicProcedure.use(({ ctx, next }) => {
  const session = readCustomerSession(ctx.req);
  if (!session) {
    throw new TRPCError({
      code: "UNAUTHORIZED",
      message: "Iniciá sesión para continuar",
    });
  }
  return next({
    ctx: { ...ctx, customer: session } as typeof ctx & {
      customer: NonNullable<ReturnType<typeof readCustomerSession>>;
    },
  });
});

const credentialsSchema = z.object({
  email: z.string().trim().email("Ingresá un correo válido").max(320),
  password: z.string().min(8, "Usá al menos 8 caracteres").max(128),
});

function publicCustomer(row: {
  id: number;
  email: string;
  name: string;
  discord: string;
  provider: string;
  createdAt: Date;
  lastSignedIn: Date | null;
}) {
  return {
    id: row.id,
    email: row.email,
    name: row.name,
    discord: row.discord,
    provider: row.provider,
    createdAt: row.createdAt,
    lastSignedIn: row.lastSignedIn,
  };
}

export const customerRouter = router({
  /** Estado de la sesión actual. */
  me: publicProcedure.query(async ({ ctx }) => {
    const session = readCustomerSession(ctx.req);
    if (!session) return { authenticated: false as const };
    const row = await getCustomerById(session.customerId);
    if (!row || !row.active) return { authenticated: false as const };
    return { authenticated: true as const, customer: publicCustomer(row) };
  }),

  register: publicProcedure
    .input(
      credentialsSchema.extend({
        name: z.string().trim().min(2, "Ingresá tu nombre").max(160),
        discord: z.string().trim().max(120).optional().default(""),
      }),
    )
    .mutation(async ({ input, ctx }) => {
      const ip = customerRateLimitKey(ctx.req);
      const limit = checkCustomerRateLimit(ip);
      if (!limit.allowed) {
        throw new TRPCError({
          code: "TOO_MANY_REQUESTS",
          message: `Demasiados intentos. Probá de nuevo en ${Math.ceil(limit.retryInSeconds / 60)} minuto(s).`,
        });
      }

      const email = normalizeEmail(input.email);
      try {
        const delivery = await startSignupVerification({
          email,
          name: input.name.trim(),
          discord: input.discord ?? "",
          passwordHash: hashPassword(input.password),
        });
        logActivity({
          kind: "cuenta.creada",
          title: `Solicitó crear su cuenta: ${input.name.trim()}`,
          detail: `Correo ${email}. Recibió un código de verificación.`,
          actor: input.name.trim(),
          actorEmail: email,
          meta: { discord: input.discord ?? "" },
          req: ctx.req,
        });
        // La cuenta todavía no existe: se crea cuando confirma el código.
        return { email, delivery };
      } catch (error) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: error instanceof Error ? error.message : "No pudimos crear la cuenta",
        });
      }
    }),

  /** Confirma el código recibido por correo y crea la cuenta. */
  verifySignup: publicProcedure
    .input(
      z.object({
        email: z.string().trim().email("Ingresá un correo válido").max(320),
        code: z.string().trim().min(4, "Ingresá el código").max(10),
      }),
    )
    .mutation(async ({ input, ctx }) => {
      const ip = customerRateLimitKey(ctx.req);
      const limit = checkCustomerRateLimit(ip);
      if (!limit.allowed) {
        throw new TRPCError({
          code: "TOO_MANY_REQUESTS",
          message: `Demasiados intentos. Probá de nuevo en ${Math.ceil(limit.retryInSeconds / 60)} minuto(s).`,
        });
      }

      const email = normalizeEmail(input.email);
      let customerId: number;
      try {
        customerId = await confirmSignupVerification({ email, code: input.code });
      } catch (error) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: error instanceof Error ? error.message : "No pudimos confirmar el código",
        });
      }

      const row = await getCustomerById(customerId);
      if (!row) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "No se pudo crear la cuenta" });

      logActivity({
        kind: "cuenta.confirmada",
        title: `Cuenta confirmada: ${row.name}`,
        detail: `Verificó el correo ${row.email} y quedó registrada.`,
        actor: row.name,
        actorEmail: row.email,
        customerId,
        req: ctx.req,
      });

      resetCustomerRateLimit(ip);
      await touchCustomer(customerId);
      setCustomerCookie(
        ctx.req,
        ctx.res,
        issueCustomerToken({ customerId, email: row.email, name: row.name }),
      );
      return { customer: publicCustomer(row) };
    }),

  /** Activa una cuenta invitada por el equipo: elige contraseña y Discord. */
  activateInvite: publicProcedure
    .input(
      z.object({
        email: z.string().trim().email("Ingresá un correo válido").max(320),
        code: z.string().trim().min(4, "Ingresá el código").max(10),
        password: z.string().min(8, "Usá al menos 8 caracteres").max(128),
        discord: z.string().trim().max(120).optional().default(""),
      }),
    )
    .mutation(async ({ input, ctx }) => {
      const ip = customerRateLimitKey(ctx.req);
      const limit = checkCustomerRateLimit(ip);
      if (!limit.allowed) {
        throw new TRPCError({
          code: "TOO_MANY_REQUESTS",
          message: `Demasiados intentos. Probá de nuevo en ${Math.ceil(limit.retryInSeconds / 60)} minuto(s).`,
        });
      }

      const email = normalizeEmail(input.email);
      let customerId: number;
      try {
        customerId = await activateCustomerInvitation({
          email,
          code: input.code,
          passwordHash: hashPassword(input.password),
          discord: input.discord ?? "",
        });
      } catch (error) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: error instanceof Error ? error.message : "No pudimos activar la cuenta",
        });
      }

      const row = await getCustomerById(customerId);
      if (!row) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "No se pudo activar la cuenta" });

      logActivity({
        kind: "cuenta.activada",
        title: `Cuenta activada: ${row.name}`,
        detail: `Activó la invitación del equipo con el correo ${row.email}.`,
        actor: row.name,
        actorEmail: row.email,
        customerId,
        req: ctx.req,
      });

      resetCustomerRateLimit(ip);
      await touchCustomer(customerId);
      setCustomerCookie(
        ctx.req,
        ctx.res,
        issueCustomerToken({ customerId, email: row.email, name: row.name }),
      );
      return { customer: publicCustomer(row) };
    }),

  login: publicProcedure
    .input(credentialsSchema)
    .mutation(async ({ input, ctx }) => {
      const ip = customerRateLimitKey(ctx.req);
      const limit = checkCustomerRateLimit(ip);
      if (!limit.allowed) {
        throw new TRPCError({
          code: "TOO_MANY_REQUESTS",
          message: `Demasiados intentos. Probá de nuevo en ${Math.ceil(limit.retryInSeconds / 60)} minuto(s).`,
        });
      }

      const email = normalizeEmail(input.email);
      const row = await findCustomerByEmail(email);
      const ok = row ? verifyPassword(input.password, row.passwordHash) : false;

      if (!row || !ok || !row.active) {
        // Si la cuenta existe pero nunca tuvo contraseña (por ejemplo cuando se
        // creó a mano desde el panel), lo decimos: es la diferencia entre que la
        // persona pueda resolverlo sola o quede trabada sin entender por qué.
        if (row && row.active && !row.passwordHash) {
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message:
              "Tu cuenta todavía no tiene contraseña. Usá «¿Olvidaste tu contraseña?» para crear una, o escribinos por Soporte y te la habilitamos.",
          });
        }
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "Correo o contraseña incorrectos",
        });
      }

      resetCustomerRateLimit(ip);
      await touchCustomer(row.id);
      setCustomerCookie(
        ctx.req,
        ctx.res,
        issueCustomerToken({ customerId: row.id, email: row.email, name: row.name }),
      );

      logActivity({
        kind: "cuenta.ingreso",
        title: `Ingresó a su cuenta: ${row.name}`,
        detail: `Inicio de sesión con ${row.email}.`,
        actor: row.name,
        actorEmail: row.email,
        customerId: row.id,
        req: ctx.req,
      });

      return { customer: publicCustomer(row) };
    }),

  logout: publicProcedure.mutation(({ ctx }) => {
    clearCustomerCookie(ctx.req, ctx.res);
    return { success: true } as const;
  }),

  /**
   * Pide un código para recuperar la contraseña.
   *
   * La respuesta es siempre la misma, exista o no la cuenta: así nadie puede
   * usar esta pantalla para averiguar qué correos están registrados.
   */
  requestPasswordReset: publicProcedure
    .input(z.object({ email: z.string().trim().email("Ingresá un correo válido").max(320) }))
    .mutation(async ({ input, ctx }) => {
      const ip = customerRateLimitKey(ctx.req);
      const limit = checkCustomerRateLimit(ip);
      if (!limit.allowed) {
        throw new TRPCError({
          code: "TOO_MANY_REQUESTS",
          message: `Demasiados intentos. Probá de nuevo en ${Math.ceil(limit.retryInSeconds / 60)} minuto(s).`,
        });
      }

      const email = normalizeEmail(input.email);
      const delivery = await startPasswordReset(email);

      logActivity({
        kind: "cuenta.recuperacion",
        title: "Pidió recuperar su contraseña",
        detail: `Correo ${email}. ${delivery.sent ? "Recibió el código por correo." : "El correo no está configurado."}`,
        actor: email,
        actorEmail: email,
        meta: { enviado: delivery.sent },
        req: ctx.req,
      });

      return {
        accepted: true as const,
        sent: delivery.sent,
        message: delivery.sent
          ? "Te enviamos un código al correo. Escribilo junto con tu contraseña nueva."
          : "El correo todavía no está activado en el sitio. Escribinos por Soporte y lo resolvemos al instante.",
      };
    }),

  /** Confirma el código y guarda la contraseña nueva. */
  resetPassword: publicProcedure
    .input(
      z.object({
        email: z.string().trim().email("Ingresá un correo válido").max(320),
        code: z.string().trim().min(4, "Ingresá el código").max(10),
        password: z.string().min(8, "Usá al menos 8 caracteres").max(128),
      }),
    )
    .mutation(async ({ input, ctx }) => {
      const ip = customerRateLimitKey(ctx.req);
      const limit = checkCustomerRateLimit(ip);
      if (!limit.allowed) {
        throw new TRPCError({
          code: "TOO_MANY_REQUESTS",
          message: `Demasiados intentos. Probá de nuevo en ${Math.ceil(limit.retryInSeconds / 60)} minuto(s).`,
        });
      }

      const email = normalizeEmail(input.email);
      let customerId: number;
      try {
        customerId = await confirmPasswordReset({
          email,
          code: input.code,
          passwordHash: hashPassword(input.password),
        });
      } catch (error) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: error instanceof Error ? error.message : "No pudimos cambiar la contraseña",
        });
      }

      const row = await getCustomerById(customerId);
      if (!row) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "No se pudo cambiar la contraseña" });

      logActivity({
        kind: "cuenta.recuperacion",
        title: `Recuperó su contraseña: ${row.name}`,
        detail: `Cambió la contraseña con el código enviado a ${row.email}.`,
        actor: row.name,
        actorEmail: row.email,
        customerId,
        req: ctx.req,
      });

      // La dejamos con la sesión iniciada: es lo que espera al recuperarla.
      resetCustomerRateLimit(ip);
      await touchCustomer(customerId);
      setCustomerCookie(
        ctx.req,
        ctx.res,
        issueCustomerToken({ customerId, email: row.email, name: row.name }),
      );
      return { customer: publicCustomer(row) };
    }),

  /** Mis compras: historial de pedidos de la cuenta con sesión. */
  orders: customerProcedure.query(async ({ ctx }) => {
    const rows = await listCustomerOrders(ctx.customer.customerId);
    return rows.map((row) => ({
      id: row.id,
      code: row.code,
      serviceName: row.serviceName,
      planName: row.planName,
      amountCents: row.amountCents,
      currency: row.currency,
      billing: row.billing,
      status: row.status,
      createdAt: row.createdAt,
      updatedAt: row.updatedAt,
    }));
  }),

  /**
   * Verifica si el pago de un pedido llegó de verdad.
   *
   * La web lo llama al volver del checkout de Tebex y cada pocos segundos
   * mientras el cliente ve la pantalla de espera. Pregunta a Tebex por el
   * estado de la canasta, así la confirmación no depende solo del webhook.
   */
  checkPayment: customerProcedure
    .input(z.object({ code: z.string().trim().min(4).max(24) }))
    .query(async ({ input, ctx }) => {
      return checkOrderPayment(input.code.trim().toUpperCase(), ctx.customer.customerId);
    }),

  /* -------------------------------- reseñas -------------------------------- */

  /** Mis reseñas: las que ya dejé y su estado. */
  reviews: customerProcedure.query(async ({ ctx }) => {
    const rows = await listCustomerReviews(ctx.customer.customerId);
    return rows.map((row) => ({
      id: row.id,
      rating: row.rating,
      comment: row.comment,
      serviceName: row.serviceName,
      status: row.status,
      reply: row.reply,
      createdAt: row.createdAt,
    }));
  }),

  /** Pedidos que todavía puedo reseñar (entregados y sin reseña). */
  reviewableOrders: customerProcedure.query(async ({ ctx }) => {
    const rows = await listCustomerOrders(ctx.customer.customerId);
    const result: {
      orderId: number;
      code: string;
      serviceName: string;
      serviceId: number | null;
      planName: string;
    }[] = [];

    for (const row of rows) {
      // Solo tiene sentido reseñar lo que ya se entregó.
      if (row.status !== "delivered" && row.status !== "in_progress") continue;
      const existing = await findReviewByOrder(ctx.customer.customerId, row.id);
      if (existing) continue;
      result.push({
        orderId: row.id,
        code: row.code,
        serviceName: row.serviceName,
        serviceId: row.serviceId,
        planName: row.planName,
      });
    }
    return result;
  }),

  /** Publicar una reseña. Queda pendiente hasta que el equipo la apruebe. */
  createReview: customerProcedure
    .input(
      z.object({
        rating: z.number().int().min(1, "Elegí una puntuación").max(5),
        comment: z
          .string()
          .trim()
          .min(10, "Contanos un poco más (mínimo 10 caracteres)")
          .max(1200),
        orderId: z.number().int().positive().optional(),
      }),
    )
    .mutation(async ({ input, ctx }) => {
      const customerId = ctx.customer.customerId;

      // Si la reseña viene de un pedido, lo validamos y sacamos el servicio.
      let serviceId: number | null = null;
      let serviceName = "";
      let orderId: number | null = null;

      if (input.orderId) {
        const rows = await listCustomerOrders(customerId);
        const order = rows.find((row) => row.id === input.orderId);
        if (!order) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "No encontramos ese pedido en tu cuenta",
          });
        }
        const existing = await findReviewByOrder(customerId, order.id);
        if (existing) {
          throw new TRPCError({
            code: "CONFLICT",
            message: "Ya dejaste una reseña para ese pedido",
          });
        }
        orderId = order.id;
        serviceName = order.serviceName;
        serviceId = order.serviceId;
      }

      const row = await getCustomerById(customerId);
      if (!row) throw new TRPCError({ code: "NOT_FOUND", message: "Cuenta no encontrada" });

      const reviewId = await createReview({
        customerId,
        authorName: row.name,
        authorEmail: row.email,
        serviceId,
        serviceName,
        orderId,
        rating: input.rating,
        comment: input.comment,
      });

      logActivity({
        kind: "resena.nueva",
        title: `Nueva reseña de ${row.name} (${input.rating}★)`,
        detail: input.comment.slice(0, 300),
        actor: row.name,
        actorEmail: row.email,
        customerId,
        orderId,
        meta: { rating: input.rating, serviceName },
        req: ctx.req,
      });

      return {
        id: reviewId,
        message: "¡Gracias! Tu reseña quedó en revisión y la publicamos enseguida.",
      };
    }),

  updateProfile: customerProcedure
    .input(
      z.object({
        name: z.string().trim().min(2).max(160).optional(),
        discord: z.string().trim().max(120).optional(),
      }),
    )
    .mutation(async ({ input, ctx }) => {
      await updateCustomerProfile(ctx.customer.customerId, input);
      const row = await getCustomerById(ctx.customer.customerId);
      if (!row) throw new TRPCError({ code: "NOT_FOUND", message: "Cuenta no encontrada" });

      logActivity({
        kind: "cuenta.creada",
        title: `Actualizó su perfil: ${row.name}`,
        detail: `Cambió sus datos de contacto${input.discord ? ` (Discord: ${input.discord})` : ""}.`,
        actor: row.name,
        actorEmail: row.email,
        customerId: row.id,
        req: ctx.req,
      });

      return { customer: publicCustomer(row) };
    }),
});
