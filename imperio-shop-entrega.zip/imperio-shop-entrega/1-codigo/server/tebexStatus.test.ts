import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

/**
 * Pruebas de la decisión de cobro.
 *
 * Regla que se comprueba: la web solo ofrece cobrar cuando la tienda de Tebex
 * realmente puede hacerlo. Una tienda recién creada cobra en modo de prueba
 * hasta que Tebex la aprueba, y eso se avisa con claridad. Si es de tipo FiveM
 * no se ofrece el cobro automático, porque exige cuenta de Cfx.re.
 */

const fetchMock = vi.fn();
vi.stubGlobal("fetch", fetchMock);

process.env.TEBEX_PUBLIC_TOKEN = "tok-prueba-1234567890";
process.env.TEBEX_PRIVATE_KEY = "clave-privada-de-prueba";

import { getTebexStatus, resetTebexStatusCache } from "./tebex";

function tienda(platform_type: string, disabled: boolean) {
  return {
    ok: true,
    status: 200,
    text: async () => JSON.stringify({ data: { platform_type, disabled, name: "Imperio Shop" } }),
  };
}

describe("estado de cobro de la tienda", () => {
  beforeEach(() => {
    fetchMock.mockReset();
    resetTebexStatusCache();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it("permite cobrar cuando la tienda es Universal y está activa", async () => {
    fetchMock.mockResolvedValueOnce(tienda("Universal", false));

    const estado = await getTebexStatus();

    expect(estado.canCharge).toBe(true);
    expect(estado.message).toBe("");
    expect(estado.platform).toBe("Universal");
  });

  it("no permite cobrar si la tienda está deshabilitada", async () => {
    fetchMock.mockResolvedValueOnce(tienda("Universal", true));

    const estado = await getTebexStatus();

    // Una tienda recién creada figura como deshabilitada, pero Tebex ya deja
    // procesar el pago con métodos de prueba: por eso el cobro se ofrece.
    expect(estado.canCharge).toBe(true);
    expect(estado.disabled).toBe(true);
    expect(estado.testMode).toBe(true);
    // Y se le dice al cliente, sin vueltas, que el importe no se cobra de verdad.
    expect(estado.message).toContain("modo de prueba");
  });

  it("no permite cobrar en una tienda FiveM, porque exige cuenta de FiveM", async () => {
    fetchMock.mockResolvedValueOnce(tienda("FiveM", false));

    const estado = await getTebexStatus();

    expect(estado.canCharge).toBe(false);
    expect(estado.message).toContain("FiveM");
  });

  it("reutiliza el estado guardado para no castigar a Tebex en cada pedido", async () => {
    fetchMock.mockResolvedValueOnce(tienda("FiveM", true));

    await getTebexStatus();
    await getTebexStatus();
    await getTebexStatus();

    // Tres consultas seguidas, una sola llamada real.
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it("no rompe si Tebex no responde: avisa y ofrece ticket", async () => {
    fetchMock.mockResolvedValueOnce({
      ok: false,
      status: 500,
      text: async () => JSON.stringify({ title: "Error" }),
    });

    const estado = await getTebexStatus();

    expect(estado.canCharge).toBe(false);
    expect(estado.message).toContain("ticket");
  });
});
