import { beforeEach, describe, expect, it, vi } from "vitest";

/**
 * Pruebas de la verificación del pago.
 *
 * Regla de oro que se comprueba acá: la web NUNCA afirma que el dinero llegó
 * si Tebex no lo confirmó. Solo la canasta completa (o un webhook firmado)
 * marca un pedido como pagado.
 */

const logActivity = vi.fn();
vi.mock("./activity", () => ({
  logActivity: (...args: unknown[]) => logActivity(...args),
}));

const getOrderByCode = vi.fn();
const updateOrderPayment = vi.fn(async () => undefined);
const getSettingsMap = vi.fn(async () => ({
  "orders.ticketMessage": "Abrí un ticket con tu código {code}.",
  "contact.discord": "https://discord.gg/cffbceYF2",
}));
vi.mock("./db", () => ({
  getOrderByCode: (...args: unknown[]) => getOrderByCode(...args),
  updateOrderPayment: (...args: unknown[]) => updateOrderPayment(...args),
  getSettingsMap: () => getSettingsMap(),
}));

const getTebexBasket = vi.fn();
vi.mock("./tebex", () => ({
  getTebexBasket: (...args: unknown[]) => getTebexBasket(...args),
}));

import { checkOrderPayment } from "./paymentVerification";

/** Pedido base: pendiente de pago y con canasta de Tebex asociada. */
function order(overrides: Record<string, unknown> = {}) {
  return {
    id: 7,
    code: "IMP-ABC123",
    serviceId: 1,
    serviceName: "Bots de Discord",
    planId: 10,
    planName: "Bot Avanzado",
    amountCents: 1600,
    currency: "USD",
    billing: "once",
    customerName: "Cliente",
    customerEmail: "cliente@ejemplo.com",
    customerDiscord: "",
    customerNote: "",
    paymentMethod: "tebex",
    payerAccount: "",
    paymentReference: "",
    tebexBasketIdent: "basket-1",
    tebexTransactionId: "",
    tebexPaymentMethod: "",
    status: "pending_payment",
    staffNote: "",
    userId: null,
    customerId: 5,
    createdAt: new Date("2026-10-01T10:00:00Z"),
    updatedAt: new Date("2026-10-01T10:00:00Z"),
    ...overrides,
  };
}

/** Canasta de Tebex según su estado de pago. */
function basket(complete: boolean) {
  return {
    ok: true as const,
    data: {
      id: "1",
      ident: "basket-1",
      complete,
      email: null,
      username: null,
      base_price: 16,
      total_price: 16,
      currency: "USD",
      custom: null,
      links: {},
      packages: [],
    },
  };
}

describe("verificación del pago", () => {
  beforeEach(() => {
    logActivity.mockClear();
    updateOrderPayment.mockClear();
    getTebexBasket.mockReset();
    getOrderByCode.mockReset();
  });

  it("confirma el pago solo cuando Tebex marca la canasta completa", async () => {
    getOrderByCode.mockResolvedValue(order());
    getTebexBasket.mockResolvedValue(basket(true));

    const result = await checkOrderPayment("IMP-ABC123", 5);

    expect(result.status).toBe("confirmed");
    expect(result.amount).toBe("USD 16.00");
    // El pedido queda marcado como pagado y queda registro en la bitácora.
    expect(updateOrderPayment).toHaveBeenCalledTimes(1);
    expect(updateOrderPayment.mock.calls[0][1]).toMatchObject({ status: "paid" });
    expect(logActivity).toHaveBeenCalledWith(
      expect.objectContaining({ kind: "pago.confirmado", orderId: 7 }),
    );
  });

  it("NO confirma nada mientras la canasta siga incompleta", async () => {
    getOrderByCode.mockResolvedValue(order());
    getTebexBasket.mockResolvedValue(basket(false));

    const result = await checkOrderPayment("IMP-ABC123", 5);

    expect(result.status).toBe("pending");
    // Nunca se marca pagado ni se inventa una confirmación.
    expect(updateOrderPayment).not.toHaveBeenCalled();
    expect(logActivity).not.toHaveBeenCalled();
  });

  it("sigue esperando si Tebex no responde, sin afirmar nada", async () => {
    getOrderByCode.mockResolvedValue(order());
    getTebexBasket.mockResolvedValue({ ok: false, error: "No pudimos contactar a Tebex" });

    const result = await checkOrderPayment("IMP-ABC123", 5);

    expect(result.status).toBe("pending");
    expect(updateOrderPayment).not.toHaveBeenCalled();
  });

  it("reconoce como pagado un pedido que ya lo estaba", async () => {
    getOrderByCode.mockResolvedValue(order({ status: "paid" }));

    const result = await checkOrderPayment("IMP-ABC123", 5);

    expect(result.status).toBe("confirmed");
    // No vuelve a consultar ni a escribir: ya estaba confirmado.
    expect(getTebexBasket).not.toHaveBeenCalled();
    expect(updateOrderPayment).not.toHaveBeenCalled();
  });

  it("no deja que un cliente vea el pedido de otra persona", async () => {
    getOrderByCode.mockResolvedValue(order({ customerId: 99 }));

    const result = await checkOrderPayment("IMP-ABC123", 5);

    expect(result.status).toBe("unavailable");
    expect(result.message).toContain("No encontramos ese pedido");
    expect(getTebexBasket).not.toHaveBeenCalled();
  });

  it("avisa cuando el pedido no tiene pago en línea asociado", async () => {
    getOrderByCode.mockResolvedValue(order({ tebexBasketIdent: "" }));

    const result = await checkOrderPayment("IMP-ABC123", 5);

    expect(result.status).toBe("unavailable");
    expect(result.message).toContain("no tiene un pago en línea asociado");
  });

  it("devuelve el código de Discord para abrir el ticket tras pagar", async () => {
    getOrderByCode.mockResolvedValue(order({ status: "paid" }));

    const result = await checkOrderPayment("IMP-ABC123", 5);

    expect(result.discord).toBe("https://discord.gg/cffbceYF2");
    expect(result.nextStep).toContain("ticket");
  });

  it("no marca pagado un pedido cancelado", async () => {
    getOrderByCode.mockResolvedValue(order({ status: "cancelled" }));

    const result = await checkOrderPayment("IMP-ABC123", 5);

    expect(result.status).toBe("unavailable");
    expect(updateOrderPayment).not.toHaveBeenCalled();
  });
});
