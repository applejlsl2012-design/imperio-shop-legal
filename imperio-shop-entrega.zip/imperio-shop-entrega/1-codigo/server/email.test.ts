/**
 * Pruebas del envío de correo.
 *
 * Cubren lo importante para el cliente: que el código salga con el diseño
 * correcto, que sepamos elegir la vía de envío disponible y que un fallo del
 * proveedor no rompa el registro ni la recuperación de contraseña.
 */
import { beforeEach, describe, expect, it, vi } from "vitest";

/** Credenciales simuladas: cada prueba decide qué hay configurado. */
const env = {
  resendApiKey: "",
  mailFrom: "",
  gmailUser: "",
  gmailAppPassword: "",
  smtpHost: "",
  smtpPort: "",
  smtpUser: "",
  smtpPassword: "",
};

vi.mock("./_core/env", () => ({ ENV: env }));

/** Transporte simulado de nodemailer. */
const sendMailMock = vi.fn();
const closeMock = vi.fn();
vi.mock("nodemailer", () => ({
  default: {
    createTransport: vi.fn(() => ({ sendMail: sendMailMock, close: closeMock })),
  },
}));

const {
  activeProvider,
  emailConfigured,
  passwordResetEmail,
  providerLabel,
  pruebaEmail,
  sendMail,
  sendTestEmail,
  signupEmail,
} = await import("./email");

/** Deja el entorno como si no hubiera nada configurado. */
function limpiar() {
  env.resendApiKey = "";
  env.mailFrom = "";
  env.gmailUser = "";
  env.gmailAppPassword = "";
  env.smtpHost = "";
  env.smtpPort = "";
  env.smtpUser = "";
  env.smtpPassword = "";
  sendMailMock.mockReset();
  closeMock.mockReset();
}

beforeEach(limpiar);

describe("elección de la vía de envío", () => {
  it("sin credenciales no hay envío configurado", () => {
    expect(activeProvider()).toBe("ninguno");
    expect(emailConfigured()).toBe(false);
    expect(providerLabel()).toBe("sin configurar");
  });

  it("prefiere el SMTP propio del dominio cuando está cargado", () => {
    env.smtpHost = "smtp.zoho.com";
    env.smtpPort = "465";
    env.smtpUser = "ventas@imperioshopp.com";
    env.smtpPassword = "clave-de-aplicacion";
    // Aunque haya Gmail y Resend, el correo del dominio manda.
    env.gmailUser = "cuenta@gmail.com";
    env.gmailAppPassword = "clave";
    env.resendApiKey = "re_123";

    expect(activeProvider()).toBe("smtp");
    expect(emailConfigured()).toBe(true);
    expect(providerLabel()).toContain("ventas@imperioshopp.com");
  });

  it("usa Gmail cuando no hay SMTP propio", () => {
    env.gmailUser = "imperioshop@gmail.com";
    env.gmailAppPassword = "clave-de-aplicacion";

    expect(activeProvider()).toBe("gmail");
    expect(providerLabel()).toContain("imperioshop@gmail.com");
  });

  it("usa Resend cuando es lo único disponible", () => {
    env.resendApiKey = "re_123";
    expect(activeProvider()).toBe("resend");
  });

  it("no considera configurado un SMTP al que le falta la contraseña", () => {
    env.smtpHost = "smtp.zoho.com";
    env.smtpUser = "ventas@imperioshopp.com";
    // Sin SMTP_PASSWORD no se puede autenticar.
    expect(emailConfigured()).toBe(false);
  });
});

describe("envío real", () => {
  it("sin credenciales avisa que no se envió y no llama al proveedor", async () => {
    const resultado = await sendMail({ to: "a@b.com", subject: "Hola", html: "", text: "" });

    expect(resultado).toEqual({ sent: false, reason: "sin-clave" });
    expect(sendMailMock).not.toHaveBeenCalled();
  });

  it("envía por SMTP y devuelve la vía usada", async () => {
    env.smtpHost = "smtp.zoho.com";
    env.smtpPort = "587";
    env.smtpUser = "ventas@imperioshopp.com";
    env.smtpPassword = "clave";
    sendMailMock.mockResolvedValue({ messageId: "1" });

    const resultado = await sendMail({
      to: "cliente@ejemplo.com",
      subject: "Código",
      html: "<p>1234</p>",
      text: "1234",
    });

    expect(resultado).toEqual({ sent: true, via: "smtp" });
    expect(sendMailMock).toHaveBeenCalledTimes(1);
    const enviado = sendMailMock.mock.calls[0][0];
    expect(enviado.to).toBe("cliente@ejemplo.com");
    // Sin MAIL_FROM, el remitente sale del usuario del SMTP.
    expect(enviado.from).toContain("ventas@imperioshopp.com");
    // Cerramos la conexión para no dejar sockets abiertos.
    expect(closeMock).toHaveBeenCalled();
  });

  it("respeta el remitente configurado en MAIL_FROM", async () => {
    env.smtpHost = "smtp.zoho.com";
    env.smtpUser = "ventas@imperioshopp.com";
    env.smtpPassword = "clave";
    env.mailFrom = "Imperio Shop <no-reply@imperioshopp.com>";
    sendMailMock.mockResolvedValue({ messageId: "1" });

    await sendMail({ to: "a@b.com", subject: "Hola", html: "", text: "" });

    expect(sendMailMock.mock.calls[0][0].from).toBe("Imperio Shop <no-reply@imperioshopp.com>");
  });

  it("reintenta cuando el proveedor falla y termina enviando", async () => {
    env.gmailUser = "imperioshop@gmail.com";
    env.gmailAppPassword = "clave";
    sendMailMock
      .mockRejectedValueOnce(new Error("corte temporal"))
      .mockResolvedValueOnce({ messageId: "2" });

    const resultado = await sendMail({ to: "a@b.com", subject: "Hola", html: "", text: "" });

    expect(resultado).toEqual({ sent: true, via: "gmail" });
    expect(sendMailMock).toHaveBeenCalledTimes(2);
  }, 15000);

  it("informa el error si el proveedor falla siempre", async () => {
    env.gmailUser = "imperioshop@gmail.com";
    env.gmailAppPassword = "clave";
    sendMailMock.mockRejectedValue(new Error("credenciales rechazadas"));

    const resultado = await sendMail({ to: "a@b.com", subject: "Hola", html: "", text: "" });

    expect(resultado.sent).toBe(false);
    if (resultado.sent === false) {
      expect(resultado.reason).toBe("error");
      expect(resultado.detail).toContain("credenciales rechazadas");
    }
  }, 20000);

  it("envía por Resend cuando es la vía configurada", async () => {
    env.resendApiKey = "re_123";
    env.mailFrom = "Imperio Shop <no-reply@imperioshopp.com>";
    const fetchMock = vi.fn().mockResolvedValue({ ok: true, text: async () => "" });
    vi.stubGlobal("fetch", fetchMock);

    const resultado = await sendMail({
      to: "cliente@ejemplo.com",
      subject: "Código",
      html: "<p>1234</p>",
      text: "1234",
    });

    expect(resultado).toEqual({ sent: true, via: "resend" });
    const [url, opciones] = fetchMock.mock.calls[0];
    expect(url).toBe("https://api.resend.com/emails");
    expect(JSON.parse(opciones.body).to).toEqual(["cliente@ejemplo.com"]);
    vi.unstubAllGlobals();
  });

  it("informa el detalle cuando Resend rechaza el envío", async () => {
    env.resendApiKey = "re_123";
    const fetchMock = vi.fn().mockResolvedValue({
      ok: false,
      status: 403,
      text: async () => "dominio no verificado",
    });
    vi.stubGlobal("fetch", fetchMock);

    const resultado = await sendMail({ to: "a@b.com", subject: "Hola", html: "", text: "" });

    expect(resultado.sent).toBe(false);
    if (resultado.sent === false) expect(resultado.detail).toContain("dominio no verificado");
    vi.unstubAllGlobals();
  }, 15000);
});

describe("correo de prueba del panel", () => {
  it("sale con el asunto y el destino correctos", async () => {
    env.smtpHost = "smtp.zoho.com";
    env.smtpUser = "ventas@imperioshopp.com";
    env.smtpPassword = "clave";
    sendMailMock.mockResolvedValue({ messageId: "1" });

    const resultado = await sendTestEmail("dueno@imperioshopp.com");

    expect(resultado.sent).toBe(true);
    const enviado = sendMailMock.mock.calls[0][0];
    expect(enviado.to).toBe("dueno@imperioshopp.com");
    expect(enviado.subject).toContain("Prueba de correo");
  });

  it("avisa cuando no hay correo configurado", async () => {
    const resultado = await sendTestEmail("dueno@imperioshopp.com");
    expect(resultado).toEqual({ sent: false, reason: "sin-clave" });
  });
});

describe("plantillas de los códigos", () => {
  it("el código de registro viaja en el asunto, el texto y el HTML", () => {
    const mensaje = signupEmail({ name: "Ana", code: "4821" });

    expect(mensaje.subject).toContain("4821");
    expect(mensaje.text).toContain("4821");
    // En el HTML el código va espaciado para que se lea fácil.
    expect(mensaje.html).toContain("4 8 2 1");
    expect(mensaje.html).toContain("Ana");
    // Nunca debe mencionar a Manus ni a otra plataforma.
    expect(mensaje.html.toLowerCase()).not.toContain("manus");
  });

  it("el código de recuperación explica que sin él la contraseña no cambia", () => {
    const mensaje = passwordResetEmail({ name: "Ana", code: "9012" });

    expect(mensaje.subject).toContain("9012");
    expect(mensaje.text).toContain("9012");
    expect(mensaje.text.toLowerCase()).toContain("contraseña");
    expect(mensaje.html).toContain("9 0 1 2");
  });

  it("el correo de prueba usa el destino que pide el dueño", () => {
    const mensaje = pruebaEmail({ to: "dueno@imperioshopp.com" });
    expect(mensaje.html).toContain("dueno@imperioshopp.com");
    expect(mensaje.text).toContain("dueno@imperioshopp.com");
  });

  it("las plantillas no exponen el correo de otra persona", () => {
    const mensaje = signupEmail({ name: "Ana", code: "4821" });
    expect(mensaje.html).not.toContain("@");
  });
});
