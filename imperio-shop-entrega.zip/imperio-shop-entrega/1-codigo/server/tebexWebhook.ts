/**
 * Webhook de Tebex.
 *
 * Tebex avisa acá cuando un pago se completa, se rechaza o se reembolsa.
 * Con `payment.completed` el pedido pasa a "pagado" en el panel, sin que nadie
 * tenga que revisarlo a mano.
 *
 * El cuerpo se lee CRUDO (sin parsear) porque la firma se calcula sobre esos
 * bytes exactos: reserializar el JSON rompería la validación.
 */
import type { Express, Request, Response } from "express";
import { logActivity } from "./activity";
import { getOrderByCode, updateOrderPayment } from "./db";
import { isTebexSender, verifyTebexSignature, type TebexWebhook } from "./tebex";

/** Extrae el `orderCode` que guardamos al crear la canasta. */
function orderCodeFromHook(hook: TebexWebhook): string {
  const subject = hook.subject ?? {};
  const products = Array.isArray(subject.products)
    ? (subject.products as Array<Record<string, unknown>>)
    : [];
  // El código viaja en el `custom` del paquete o en el de la canasta.
  for (const product of products) {
    const custom = product.custom;
    const code = readOrderCode(custom);
    if (code) return code;
  }
  return readOrderCode(subject.custom) ?? "";
}

/** Busca `orderCode` dentro de un objeto custom (puede venir como texto JSON). */
function readOrderCode(value: unknown): string | null {
  if (!value) return null;
  if (typeof value === "string") {
    try {
      return readOrderCode(JSON.parse(value));
    } catch {
      return null;
    }
  }
  if (typeof value === "object") {
    const direct = (value as Record<string, unknown>).orderCode;
    if (typeof direct === "string" && direct.trim()) return direct.trim();
    // Tebex puede anidar los datos personalizados en `data`.
    return readOrderCode((value as Record<string, unknown>).data);
  }
  return null;
}

/** Lee el id del pago y su estado desde el subject del webhook. */
function readPayment(subject: Record<string, unknown>) {
  const status = subject.status as { id?: number; description?: string } | undefined;
  const method = subject.payment_method as { name?: string } | undefined;
  const paid = subject.price_paid as { amount?: number; currency?: string } | undefined;
  const price = subject.price as { amount?: number; currency?: string } | undefined;
  return {
    transactionId: typeof subject.transaction_id === "string" ? subject.transaction_id : "",
    statusId: typeof status?.id === "number" ? status.id : 0,
    paymentMethodName: method?.name ?? "",
    amount: paid?.amount ?? price?.amount ?? 0,
    currency: paid?.currency ?? price?.currency ?? "USD",
  };
}

/** Handler del webhook: valida, interpreta y actualiza el pedido. */
export async function handleTebexWebhook(req: Request, res: Response) {
  const raw = (req as Request & { rawBody?: Buffer }).rawBody;
  const body = raw ? raw.toString("utf-8") : "";

  let hook: TebexWebhook;
  try {
    hook = JSON.parse(body) as TebexWebhook;
  } catch {
    res.status(400).json({ error: "invalid json" });
    return;
  }

  // 1) Validación inicial: Tebex exige devolver el mismo id para habilitar el endpoint.
  if (hook.type === "validation.webhook") {
    res.status(200).json({ id: hook.id });
    return;
  }

  // 2) La firma es la prueba de que el aviso viene de Tebex.
  const signature = String(req.headers["x-signature"] ?? "");
  if (!verifyTebexSignature(raw ?? body, signature)) {
    // Si todavía no hay secreto configurado, no bloqueamos: avisamos y seguimos.
    if (process.env.TEBEX_WEBHOOK_SECRET) {
      console.warn("[TebexWebhook] Firma inválida, se descarta el aviso.");
      res.status(401).json({ error: "invalid signature" });
      return;
    }
    console.warn("[TebexWebhook] Sin TEBEX_WEBHOOK_SECRET: no se pudo verificar la firma.");
  } else if (!isTebexSender(req)) {
    console.warn("[TebexWebhook] IP de origen inesperada:", req.ip);
  }

  const subject = (hook.subject ?? {}) as Record<string, unknown>;
  const payment = readPayment(subject);
  const code = orderCodeFromHook(hook);

  if (!code) {
    console.warn("[TebexWebhook] Aviso sin código de pedido:", hook.type);
    res.status(200).json({ received: true });
    return;
  }

  const order = await getOrderByCode(code);
  if (!order) {
    console.warn("[TebexWebhook] Pedido no encontrado:", code);
    res.status(200).json({ received: true });
    return;
  }

  // 3) Según el evento, movemos el pedido y dejamos registro.
  if (hook.type === "payment.completed") {
    await updateOrderPayment(
      order.id,
      {
        status: "paid",
        paymentReference: payment.transactionId || order.paymentReference,
        payerAccount: payment.paymentMethodName || order.payerAccount,
        // Guardamos la transacción y el método: es la prueba del cobro.
        tebexTransactionId: payment.transactionId || order.tebexTransactionId,
        tebexPaymentMethod: payment.paymentMethodName || order.tebexPaymentMethod,
        staffNote: `Pagado con ${payment.paymentMethodName || "Tebex"}: ${payment.currency} ${payment.amount}.`,
      },
      "tebex",
    );
    logActivity({
      kind: "pago.confirmado",
      title: `Pago confirmado ${code}`,
      detail: `Tebex confirmó ${payment.currency} ${payment.amount} con ${payment.paymentMethodName || "un método de pago"}.`,
      actor: "tebex",
      actorEmail: "",
      customerId: order.customerId ?? null,
      orderId: order.id,
      meta: { transactionId: payment.transactionId, method: payment.paymentMethodName },
      req,
    });
  } else if (hook.type === "payment.declined") {
    await updateOrderPayment(
      order.id,
      {
        status: "payment_review",
        staffNote: `El pago fue rechazado por Tebex. ${String(subject.decline_reason ?? "")}`.trim(),
      },
      "tebex",
    );
    logActivity({
      kind: "pago.rechazado",
      title: `Pago rechazado ${code}`,
      detail: "Tebex informó que el pago no se pudo completar.",
      actor: "tebex",
      actorEmail: "",
      customerId: order.customerId ?? null,
      orderId: order.id,
      meta: { transactionId: payment.transactionId },
      req,
    });
  } else if (hook.type === "payment.refunded") {
    await updateOrderPayment(
      order.id,
      { status: "cancelled", staffNote: "El pago fue reembolsado en Tebex." },
      "tebex",
    );
    logActivity({
      kind: "pago.reembolsado",
      title: `Pago reembolsado ${code}`,
      detail: "Tebex informó un reembolso.",
      actor: "tebex",
      actorEmail: "",
      customerId: order.customerId ?? null,
      orderId: order.id,
      meta: { transactionId: payment.transactionId },
      req,
    });
  }

  res.status(200).json({ received: true });
}

/**
 * Registra la ruta del webhook.
 *
 * Se guarda el cuerpo crudo en `rawBody` porque la firma se calcula sobre esos
 * bytes y el parser de JSON ya los habría consumido.
 */
export function registerTebexWebhook(app: Express) {
  app.post(
    "/api/tebex/webhook",
    (req: Request, _res: Response, next: () => void) => {
      const chunks: Buffer[] = [];
      req.on("data", (chunk: Buffer) => chunks.push(chunk));
      req.on("end", () => {
        const buffer = Buffer.concat(chunks);
        (req as Request & { rawBody?: Buffer }).rawBody = buffer;
        try {
          req.body = buffer.length ? JSON.parse(buffer.toString("utf-8")) : {};
        } catch {
          req.body = {};
        }
        next();
      });
    },
    (req: Request, res: Response) => {
      handleTebexWebhook(req, res).catch((error) => {
        console.error("[TebexWebhook] Error inesperado:", error);
        res.status(500).json({ error: "internal" });
      });
    },
  );
}
