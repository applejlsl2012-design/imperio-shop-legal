/**
 * Flujos de alta de clientes mediante código de verificación por correo.
 *
 * Dos casos, una misma regla de seguridad:
 * - Registro propio: la persona llena sus datos y confirma que controla el email.
 * - Invitación del equipo: el panel manda un código al cliente y él elige su
 *   contraseña al activarlo.
 */
import {
  consumeVerificationCode,
  createCustomer,
  createVerificationCode,
  findCustomerByEmail,
  getLatestVerificationCode,
  recordVerificationAttempt,
} from "./db";
import { inviteEmail, sendMail, signupEmail } from "./email";
import { codeExpiry, generateCode, hashCode, MAX_CODE_ATTEMPTS, verifyCode } from "./verification";

export type DeliveryResult = {
  sent: boolean;
  mode: "email" | "manual";
  /** Solo para el equipo cuando falta configurar correo. Nunca para el cliente. */
  manualCode?: string;
};

function assertUsableCode(code: {
  id: number;
  codeHash: string;
  attempts: number;
  consumedAt: Date | null;
  expiresAt: Date;
}, value: string) {
  if (code.consumedAt) return { valid: false as const, message: "Este código ya fue usado. Pedí uno nuevo." };
  if (code.expiresAt.getTime() < Date.now()) {
    return { valid: false as const, message: "El código venció. Pedí uno nuevo." };
  }
  if (code.attempts >= MAX_CODE_ATTEMPTS) {
    return { valid: false as const, message: "Superaste los intentos permitidos. Pedí un código nuevo." };
  }
  if (!verifyCode(value, code.codeHash)) {
    return { valid: false as const, message: "El código no coincide." };
  }
  return { valid: true as const };
}

/** Inicia un registro creado por la persona desde la web. */
export async function startSignupVerification(data: {
  email: string;
  name: string;
  discord: string;
  passwordHash: string;
}): Promise<DeliveryResult> {
  const existing = await findCustomerByEmail(data.email);
  if (existing) {
    throw new Error("Ya existe una cuenta con ese correo. Iniciá sesión.");
  }

  const code = generateCode();
  await createVerificationCode({
    email: data.email,
    codeHash: hashCode(code),
    purpose: "signup",
    pendingName: data.name,
    pendingDiscord: data.discord,
    pendingPasswordHash: data.passwordHash,
    expiresAt: codeExpiry(),
  });

  const message = signupEmail({ name: data.name, code });
  message.to = data.email;
  const delivery = await sendMail(message);
  return delivery.sent
    ? { sent: true, mode: "email" }
    : { sent: false, mode: "manual" };
}

/** Confirma el código de un registro propio y crea la cuenta. */
export async function confirmSignupVerification(data: { email: string; code: string }) {
  const pending = await getLatestVerificationCode(data.email, "signup");
  if (!pending) throw new Error("No encontramos un código activo para este correo.");
  const check = assertUsableCode(pending, data.code);
  if (!check.valid) {
    if (check.message === "El código no coincide.") await recordVerificationAttempt(pending.id);
    throw new Error(check.message);
  }

  const existing = await findCustomerByEmail(data.email);
  if (existing) throw new Error("Ya existe una cuenta con ese correo. Iniciá sesión.");

  const customerId = await createCustomer({
    email: data.email,
    name: pending.pendingName,
    passwordHash: pending.pendingPasswordHash,
    discord: pending.pendingDiscord,
    provider: "email",
  });
  await consumeVerificationCode(pending.id);
  return customerId;
}

/** Genera una invitación desde el panel; nunca crea la cuenta hasta confirmarla. */
export async function createCustomerInvitation(data: {
  email: string;
  name: string;
  invitedBy: string;
}): Promise<DeliveryResult> {
  const existing = await findCustomerByEmail(data.email);
  if (existing) throw new Error("Ese correo ya tiene una cuenta creada.");

  const code = generateCode();
  await createVerificationCode({
    email: data.email,
    codeHash: hashCode(code),
    purpose: "invite",
    pendingName: data.name,
    pendingDiscord: "",
    pendingPasswordHash: "",
    invitedBy: data.invitedBy,
    expiresAt: codeExpiry(),
  });

  const message = inviteEmail({ name: data.name, code, invitedBy: data.invitedBy });
  message.to = data.email;
  const delivery = await sendMail(message);
  return delivery.sent
    ? { sent: true, mode: "email" }
    : { sent: false, mode: "manual", manualCode: code };
}

/** Activa una cuenta que fue invitada por el equipo. */
export async function activateCustomerInvitation(data: {
  email: string;
  code: string;
  passwordHash: string;
  discord: string;
}) {
  const pending = await getLatestVerificationCode(data.email, "invite");
  if (!pending) throw new Error("No encontramos una invitación activa para este correo.");
  const check = assertUsableCode(pending, data.code);
  if (!check.valid) {
    if (check.message === "El código no coincide.") await recordVerificationAttempt(pending.id);
    throw new Error(check.message);
  }

  const existing = await findCustomerByEmail(data.email);
  if (existing) throw new Error("Ese correo ya tiene una cuenta creada. Iniciá sesión.");

  const customerId = await createCustomer({
    email: data.email,
    name: pending.pendingName,
    passwordHash: data.passwordHash,
    discord: data.discord,
    provider: "email",
  });
  await consumeVerificationCode(pending.id);
  return customerId;
}
