/**
 * Envío de correo del sitio.
 *
 * Tres caminos, en este orden de preferencia:
 * 1) SMTP propio: sirve para enviar desde el correo del dominio
 *    (por ejemplo ventas@imperioshopp.com) con Zoho, Outlook o el hosting.
 * 2) Gmail con contraseña de aplicación: funciona ya mismo, sin dominio propio.
 * 3) Resend (REST): cómodo cuando haya un dominio verificado.
 *
 * Si no hay ninguno configurado, el correo no se envía pero el código queda
 * disponible en el panel, así el flujo nunca se rompe para el cliente.
 *
 * Los envíos se reintentan un par de veces porque los proveedores de correo
 * tienen cortes momentáneos; un fallo de red no debe costarle la cuenta a nadie.
 */
import nodemailer, { type Transporter } from "nodemailer";
import { ENV } from "./_core/env";

const RESEND_ENDPOINT = "https://api.resend.com/emails";

/** Cuántas veces insistimos ante un error pasajero. */
const MAX_INTENTOS = 3;

export type MailInput = {
  to: string;
  subject: string;
  html: string;
  text: string;
};

export type MailReason = "sin-clave" | "error" | "config-invalida";

export type MailResult =
  | { sent: true; via: "smtp" | "gmail" | "resend" }
  | { sent: false; reason: MailReason; detail?: string };

/** Qué vía de envío está lista hoy. Lo usa el panel para mostrarlo. */
export type MailProvider = "smtp" | "gmail" | "resend" | "ninguno";

export function activeProvider(): MailProvider {
  if (ENV.smtpHost && ENV.smtpUser && ENV.smtpPassword) return "smtp";
  if (ENV.gmailUser && ENV.gmailAppPassword) return "gmail";
  if (ENV.resendApiKey) return "resend";
  return "ninguno";
}

/** Nombre legible de la vía activa, para el panel y los avisos. */
export function providerLabel(): string {
  switch (activeProvider()) {
    case "smtp":
      return `SMTP propio (${ENV.smtpUser})`;
    case "gmail":
      return `Gmail (${ENV.gmailUser})`;
    case "resend":
      return "Resend";
    default:
      return "sin configurar";
  }
}

/** ¿Está configurado el envío real de correo? */
export function emailConfigured(): boolean {
  return activeProvider() !== "ninguno";
}

/** Dirección desde la que sale el correo. */
function fromAddress(): string {
  if (ENV.mailFrom) return ENV.mailFrom;
  if (ENV.smtpUser) return `Imperio Shop <${ENV.smtpUser}>`;
  if (ENV.gmailUser) return `Imperio Shop <${ENV.gmailUser}>`;
  return "Imperio Shop <onboarding@resend.dev>";
}

/** Espera entre reintentos, creciente para no insistir de golpe. */
const esperar = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * Envía por SMTP o Gmail. Ambos usan el mismo transporte; solo cambia cómo se
 * describe la conexión.
 */
async function sendViaSmtp(
  input: MailInput,
  via: "smtp" | "gmail",
): Promise<MailResult> {
  const configuracion =
    via === "gmail"
      ? { service: "gmail", auth: { user: ENV.gmailUser, pass: ENV.gmailAppPassword } }
      : {
          host: ENV.smtpHost,
          port: Number(ENV.smtpPort || 587),
          // El puerto 465 habla SSL directo; el 587 empieza en claro y sube.
          secure: Number(ENV.smtpPort || 587) === 465,
          auth: { user: ENV.smtpUser, pass: ENV.smtpPassword },
          requireTLS: Number(ENV.smtpPort || 587) === 587,
        };

  let transporter: Transporter | null = null;
  try {
    transporter = nodemailer.createTransport(configuracion);
    await transporter.sendMail({
      from: fromAddress(),
      to: input.to,
      subject: input.subject,
      html: input.html,
      text: input.text,
    });
    return { sent: true, via };
  } catch (error) {
    console.warn(`[Email] Falló el envío por ${via}:`, error);
    return {
      sent: false,
      reason: "error",
      detail: String(error).slice(0, 400),
    };
  } finally {
    transporter?.close();
  }
}

/** Envía por Resend, la API REST. */
async function sendViaResend(input: MailInput): Promise<MailResult> {
  const response = await fetch(RESEND_ENDPOINT, {
    method: "POST",
    headers: {
      authorization: `Bearer ${ENV.resendApiKey}`,
      "content-type": "application/json",
    },
    body: JSON.stringify({
      from: fromAddress(),
      to: [input.to],
      subject: input.subject,
      html: input.html,
      text: input.text,
    }),
  });

  if (!response.ok) {
    const detail = await response.text().catch(() => "");
    console.warn(`[Email] Falló el envío por Resend (${response.status}): ${detail}`);
    return { sent: false, reason: "error", detail: detail.slice(0, 400) };
  }
  return { sent: true, via: "resend" };
}

/**
 * Envía un correo por la vía disponible, reintentando ante fallos pasajeros.
 *
 * Reintentamos solo los errores de envío: si falta la configuración no tiene
 * sentido insistir.
 */
export async function sendMail(input: MailInput): Promise<MailResult> {
  const via = activeProvider();

  if (via === "ninguno") {
    console.warn(
      "[Email] Sin SMTP, Gmail ni RESEND_API_KEY: el correo no se envió. " +
        "El código queda disponible en el panel.",
    );
    return { sent: false, reason: "sin-clave" };
  }

  let ultimo: MailResult = { sent: false, reason: "error", detail: "sin intentos" };

  for (let intento = 1; intento <= MAX_INTENTOS; intento += 1) {
    try {
      const resultado =
        via === "resend" ? await sendViaResend(input) : await sendViaSmtp(input, via);
      if (resultado.sent) return resultado;
      ultimo = resultado;
    } catch (error) {
      console.warn(`[Email] Error inesperado en el intento ${intento}:`, error);
      ultimo = { sent: false, reason: "error", detail: String(error).slice(0, 400) };
    }

    // Esperamos antes de volver a intentar: 1s, luego 2s.
    if (intento < MAX_INTENTOS) await esperar(intento * 1000);
  }

  console.warn(`[Email] Se agotaron los intentos: ${ultimo.sent === false ? ultimo.detail : ""}`);
  return ultimo;
}

/**
 * Envía un correo de prueba desde el panel.
 *
 * Devuelve el resultado real del envío para que el dueño sepa si el correo
 * está funcionando, sin tener que crear una cuenta ni recuperar una contraseña.
 */
export async function sendTestEmail(to: string): Promise<MailResult> {
  const mensaje = pruebaEmail({ to });
  mensaje.to = to;
  return sendMail(mensaje);
}

/* -------------------------------------------------------------------------- */
/*  Plantillas                                                                */
/* -------------------------------------------------------------------------- */

function layout(options: {
  title: string;
  intro: string;
  code: string;
  footer: string;
}): string {
  const spaced = options.code.split("").join(" ");
  return `<!doctype html>
<html lang="es">
  <body style="margin:0;padding:0;background:#120a0c;font-family:'Segoe UI',Roboto,Helvetica,Arial,sans-serif;">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#120a0c;padding:32px 16px;">
      <tr>
        <td align="center">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:520px;background:#1b1114;border:1px solid #33191f;border-radius:20px;overflow:hidden;">
            <tr>
              <td style="padding:28px 32px 8px;">
                <p style="margin:0;font-size:12px;letter-spacing:3px;text-transform:uppercase;color:#ff4d6d;font-weight:700;">Imperio Shop</p>
                <h1 style="margin:12px 0 0;font-size:22px;color:#ffffff;">${options.title}</h1>
              </td>
            </tr>
            <tr>
              <td style="padding:8px 32px 0;">
                <p style="margin:0;font-size:15px;line-height:1.6;color:#c9b8bc;">${options.intro}</p>
              </td>
            </tr>
            <tr>
              <td style="padding:24px 32px;">
                <div style="background:#22141a;border:1px solid #4a2029;border-radius:14px;padding:20px;text-align:center;">
                  <p style="margin:0 0 10px;font-size:11px;letter-spacing:2px;text-transform:uppercase;color:#9c8b90;">Tu código</p>
                  <p style="margin:0;font-size:34px;letter-spacing:6px;font-weight:800;color:#ff4d6d;">${spaced}</p>
                </div>
              </td>
            </tr>
            <tr>
              <td style="padding:0 32px 28px;">
                <p style="margin:0;font-size:13px;line-height:1.6;color:#8d7b80;">${options.footer}</p>
              </td>
            </tr>
          </table>
          <p style="margin:18px 0 0;font-size:11px;color:#6b5a5f;">Imperio Shop · Bots, hosting y páginas web</p>
        </td>
      </tr>
    </table>
  </body>
</html>`;
}

/** Correo para confirmar la cuenta recién creada. */
export function signupEmail(options: { name: string; code: string }): MailInput {
  const title = `Hola ${options.name}, confirmá tu cuenta`;
  return {
    subject: `${options.code} es tu código de Imperio Shop`,
    text: `${title}\n\nTu código de verificación es: ${options.code}\n\nVence en 15 minutos. Si no pediste esta cuenta, ignorá este mensaje.`,
    html: layout({
      title,
      intro:
        "Estamos por crear tu cuenta en Imperio Shop. Escribí este código en la página para confirmar que el correo es tuyo:",
      code: options.code,
      footer:
        "El código vence en 15 minutos y sirve una sola vez. Si no pediste esta cuenta, ignorá este mensaje.",
    }),
    to: "",
  };
}

/** Correo de invitación que envía el equipo desde el panel. */
export function inviteEmail(options: {
  name: string;
  code: string;
  invitedBy: string;
}): MailInput {
  const title = `${options.name}, te invitamos a Imperio Shop`;
  return {
    subject: `${options.code} es tu código de invitación`,
    text: `${title}\n\n${options.invitedBy} te creó una cuenta. Tu código de invitación es: ${options.code}\n\nVence en 15 minutos.`,
    html: layout({
      title,
      intro: `${options.invitedBy} te creó una cuenta en Imperio Shop. Escribí este código para activarla y elegir tu contraseña:`,
      code: options.code,
      footer:
        "El código vence en 15 minutos y sirve una sola vez. Si no esperabas esta invitación, ignorá este mensaje.",
    }),
    to: "",
  };
}

/** Correo para recuperar la contraseña de una cuenta existente. */
export function passwordResetEmail(options: { name: string; code: string }): MailInput {
  const title = `${options.name}, recuperá tu contraseña`;
  return {
    subject: `${options.code} es tu código para recuperar la contraseña`,
    text: `${title}\n\nTu código para elegir una contraseña nueva es: ${options.code}\n\nVence en 15 minutos y sirve una sola vez. Si no lo pediste, ignorá este mensaje y tu contraseña seguirá igual.`,
    html: layout({
      title,
      intro:
        "Pediste recuperar tu contraseña en Imperio Shop. Escribí este código en la página y después elegí tu contraseña nueva:",
      code: options.code,
      footer:
        "El código vence en 15 minutos y sirve una sola vez. Si no lo pediste, ignorá este mensaje: tu contraseña sigue igual y nadie puede cambiarla sin este código.",
    }),
    to: "",
  };
}

/** Correo de prueba que envía el panel para comprobar la configuración. */
export function pruebaEmail(options: { to: string }): MailInput {
  const code = "OK1234";
  return {
    subject: "Prueba de correo de Imperio Shop",
    text: `Esta es una prueba del sistema de correo de Imperio Shop.\n\nSi ves este mensaje, los códigos de registro y de recuperación de contraseña van a llegar sin problema a ${options.to}.`,
    html: layout({
      title: "El correo está funcionando",
      intro: `Esta es una prueba del sistema de correo de Imperio Shop. Si ves este mensaje, los códigos de registro y de recuperación de contraseña van a llegar sin problema a <strong style="color:#ff4d6d;">${options.to}</strong>.`,
      code,
      footer:
        "Este código es solo de ejemplo, no sirve para nada. Podés ignorar este mensaje con tranquilidad.",
    }),
    to: "",
  };
}