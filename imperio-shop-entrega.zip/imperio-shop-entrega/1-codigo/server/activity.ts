/**
 * Bitácora de la web pública.
 *
 * Cada acción importante del sitio queda registrada para que el panel privado
 * muestre qué pasó, quién lo hizo y cuándo. El registro nunca debe romper la
 * acción original: si falla, se avisa por consola y el flujo continúa.
 */
import type { Request } from "express";
import { insertActivity, listActivity } from "./db";

export type ActivityKind =
  | "visita"
  | "cuenta.creada"
  | "cuenta.confirmada"
  | "cuenta.invitada"
  | "cuenta.activada"
  | "cuenta.recuperacion"
  | "cuenta.ingreso"
  | "pedido.nuevo"
  | "pedido.prueba"
  | "pedido.actualizado"
  | "pago.confirmado"
  | "pago.rechazado"
  | "pago.reembolsado"
  | "resena.nueva"
  | "resena.moderada"
  | "catalogo.consultado"
  | "config.actualizada";

/** Datos técnicos acotados: sirven para soporte, no para seguimiento. */
export function requestMeta(req: Request) {
  const forwarded = String(req.headers["x-forwarded-for"] ?? "");
  const ip = (forwarded.split(",")[0] || req.ip || "").trim().slice(0, 64);
  const userAgent = String(req.headers["user-agent"] ?? "").slice(0, 300);
  return { ip, userAgent };
}

/**
 * Guarda un movimiento. Se llama sin `await` desde los flujos para no
 * retrasar la respuesta al cliente.
 */
export function logActivity(data: {
  kind: ActivityKind;
  title: string;
  detail?: string;
  actor?: string;
  actorEmail?: string;
  customerId?: number | null;
  orderId?: number | null;
  meta?: Record<string, unknown>;
  req?: Request;
}): void {
  const tech = data.req ? requestMeta(data.req) : { ip: "", userAgent: "" };

  void insertActivity({
    kind: data.kind,
    title: data.title.slice(0, 200),
    detail: (data.detail ?? "").slice(0, 2000),
    actor: (data.actor ?? "visitante").slice(0, 160),
    actorEmail: (data.actorEmail ?? "").slice(0, 320),
    customerId: data.customerId ?? null,
    orderId: data.orderId ?? null,
    meta: JSON.stringify(data.meta ?? {}),
    ip: tech.ip,
    userAgent: tech.userAgent,
  }).catch((error: unknown) => {
    console.warn("[Activity] No se pudo registrar el movimiento:", error);
  });
}

/** Resumen de la bitácora para el panel. */
export async function getActivityFeed(options: { kind?: string; limit?: number } = {}) {
  const rows = await listActivity(options);
  return rows.map((row: Awaited<ReturnType<typeof listActivity>>[number]) => ({
    id: row.id,
    kind: row.kind,
    title: row.title,
    detail: row.detail,
    actor: row.actor,
    actorEmail: row.actorEmail,
    customerId: row.customerId,
    orderId: row.orderId,
    ip: row.ip,
    createdAt: row.createdAt,
  }));
}
