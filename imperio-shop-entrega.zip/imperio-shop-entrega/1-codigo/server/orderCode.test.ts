import { describe, expect, it } from "vitest";
import { makeOrderCode } from "./orderCode";

/**
 * El código público de un pedido debe ser legible y difícil de adivinar.
 *
 * Se usa tanto en la compra real como en los pedidos de prueba del panel, así
 * que el formato tiene que ser siempre el mismo.
 */
describe("código de pedido", () => {
  it("usa el prefijo configurado y un bloque de seis caracteres", () => {
    const code = makeOrderCode("IMP");
    expect(code).toMatch(/^IMP-[A-Z0-9]{6}$/);
  });

  it("cae en IMP cuando no hay prefijo", () => {
    expect(makeOrderCode("")).toMatch(/^IMP-[A-Z0-9]{6}$/);
  });

  it("respeta un prefijo distinto", () => {
    expect(makeOrderCode("IS")).toMatch(/^IS-[A-Z0-9]{6}$/);
  });

  it("no repite el mismo código en muchos intentos", () => {
    const codigos = new Set(Array.from({ length: 500 }, () => makeOrderCode("IMP")));
    // Con 32^6 combinaciones, 500 intentos no deberían chocar casi nunca.
    expect(codigos.size).toBeGreaterThan(495);
  });

  it("evita caracteres que se confunden al leerlos", () => {
    // Sin O, 0, I ni 1 en el bloque aleatorio: el prefijo lo elige el equipo,
    // pero los caracteres que se dictan por Discord no deben prestarse a dudas.
    const bloques = Array.from({ length: 200 }, () => makeOrderCode("IMP").split("-")[1]).join("");
    expect(bloques).not.toMatch(/[O0I1]/);
  });
});
