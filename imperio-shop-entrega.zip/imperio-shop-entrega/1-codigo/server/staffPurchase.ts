/**
 * Verificación del pago de un pedido de prueba.
 *
 * Cuando el dueño o su socio prueban una compra desde la web y vuelven del
 * checkout de Tebex, comprobamos contra la canasta real que el pago entró antes
 * de dar nada por pagado. Es la misma regla que con los clientes: nunca se
 * marca pagado porque alguien haya empezado el pago, solo cuando Tebex confirma.
 */
import { logActivity } from "./activity";
import { getOrderByCode, updateOrderPayment } from "./db";
import { getTebexBasket } from "./tebex";

/** Estados que ya significan "el pago entró". */
const PAID_STATUSES = new Set(["paid", "in_progress", "delivered"]);

export type StaffPaymentCheck = {
  status: "confirmed" | "pending" | "unavailable";
  /** Texto listo para mostrar en el panel. */
  message: string;
  code: string;
  amount: string;
  method: string;
  /** ID de la transacción de Tebex que confirma el cobro. */
  transactionId: string;
};

/**
 * Comprueba si el pago de un pedido de prueba llegó.
 *
 * No se limita a los pedidos marcados como prueba: sirve para cualquier pedido
 * sin cuenta de cliente (por ejemplo, los creados desde el panel), así el dueño
 * puede seguir cualquier cobro desde su propio panel.
 */
export async function checkStaffTestPayment(code: string): Promise<StaffPaymentCheck> {
  const order = await getOrderByCode(code);
  if (!order) {
    return {
      status: "unavailable",
      message: "No encontramos ese pedido en el panel.",
      code,
      amount: "",
      method: "",
      transactionId: "",
    };
  }

  const amount = `${order.currency} ${(order.amountCents / 100).toFixed(2)}`;

  const armar = (
    status: StaffPaymentCheck["status"],
    message: string,
    datos?: { method?: string; transactionId?: string },
  ): StaffPaymentCheck => ({
    status,
    message,
    code: order.code,
    amount,
    method: datos?.method ?? order.tebexPaymentMethod ?? order.payerAccount ?? "",
    transactionId: datos?.transactionId ?? order.tebexTransactionId ?? "",
  });

  // 1) Ya confirmado antes (por el aviso de Tebex o por una verificación previa).
  if (PAID_STATUSES.has(order.status)) {
    return armar("confirmed", "Pago confirmado por Tebex.");
  }

  if (order.status === "cancelled") {
    return armar("unavailable", "Este pedido quedó cancelado.");
  }

  // 2) Sin canasta no hay pago en línea que verificar.
  if (!order.tebexBasketIdent) {
    return armar(
      "unavailable",
      "Este pedido no tiene un cobro en línea asociado, así que no hay pago que verificar.",
    );
  }

  // 3) Preguntamos a Tebex si la canasta quedó completa.
  const basket = await getTebexBasket(order.tebexBasketIdent);
  if (!basket.ok) {
    return armar("pending", "Estamos consultando con Tebex. Esperá unos segundos más…");
  }

  if (basket.data.complete) {
    // El pago entró: lo dejamos registrado en el pedido y en la bitácora.
    await updateOrderPayment(
      order.id,
      {
        status: "paid",
        ...(order.tebexPaymentMethod ? {} : { tebexPaymentMethod: "Tebex" }),
        staffNote: `${order.staffNote} Pago verificado contra Tebex (canasta completa).`.trim(),
      },
      "verificacion",
    );
    logActivity({
      kind: "pago.confirmado",
      title: `Pago verificado ${order.code}`,
      detail: `Tebex confirmó la canasta ${order.tebexBasketIdent} como completa.`,
      actor: "verificacion",
      actorEmail: "",
      customerId: order.customerId ?? null,
      orderId: order.id,
      meta: { basketIdent: order.tebexBasketIdent, desdePanel: true },
    });
    // Releemos para traer la transacción y el método que dejó el aviso de Tebex.
    const refrescado = await getOrderByCode(order.code);
    return armar("confirmed", "Pago confirmado por Tebex.", {
      method: refrescado?.tebexPaymentMethod || "Tebex",
      transactionId: refrescado?.tebexTransactionId ?? "",
    });
  }

  return armar("pending", "Todavía no vemos el pago acreditado. Esperá un momento más…");
}