/**
 * Recuperación de contraseña.
 *
 * Si el cliente olvidó su contraseña, pide un código desde la pantalla de
 * ingreso. Le mandamos un código por correo, él lo escribe junto con su nueva
 * contraseña, y recién ahí la cuenta se actualiza.
 *
 * Dos reglas de seguridad que no negociamos:
 * 1) Nunca decimos si el correo existe o no: la respuesta es siempre la misma,
 *    así nadie puede averiguar qué correos tienen cuenta.
 * 2) El código se guarda solo como hash, con vencimiento corto y límite de
 *    intentos, igual que el código de alta.
 */
import {
  consumeVerificationCode,
  createVerificationCode,
  findCustomerByEmail,
  getLatestVerificationCode,
  recordVerificationAttempt,
  updateCustomerPassword,
} from "./db";
import { passwordResetEmail, sendMail } from "./email";
import { codeExpiry, generateCode, hashCode, MAX_CODE_ATTEMPTS, verifyCode } from "./verification";

export type ResetDelivery = {
  /** Siempre `true`: no revelamos si el correo tiene cuenta o no. */
  accepted: true;
  /** Si el correo realmente salió. */
  sent: boolean;
  /** Solo para el equipo cuando falta configurar el correo. Nunca para el cliente. */
  manualCode?: string;
};

/** Comprueba un código pendiente y falla con un mensaje claro si no sirve. */
function assertUsableCode(
  code: {
    id: number;
    codeHash: string;
    attempts: number;
    consumedAt: Date | null;
    expiresAt: Date;
  },
  value: string,
) {
  if (code.consumedAt) {
    return { valid: false as const, message: "Este código ya fue usado. Pedí uno nuevo." };
  }
  if (code.expiresAt.getTime() < Date.now()) {
    return { valid: false as const, message: "El código venció. Pedí uno nuevo." };
  }
  if (code.attempts >= MAX_CODE_ATTEMPTS) {
    return {
      valid: false as const,
      message: "Superaste los intentos permitidos. Pedí un código nuevo.",
    };
  }
  if (!verifyCode(value, code.codeHash)) {
    return { valid: false as const, message: "El código no coincide." };
  }
  return { valid: true as const };
}

/**
 * Pide un código para recuperar la contraseña.
 *
 * Devuelve siempre una respuesta aceptada, exista o no la cuenta: así nadie
 * puede usar esta pantalla para averiguar qué correos están registrados.
 */
export async function startPasswordReset(email: string): Promise<ResetDelivery> {
  const row = await findCustomerByEmail(email);

  // Sin cuenta no hay nada que mandar, pero la respuesta es la misma.
  if (!row || !row.active) {
    return { accepted: true, sent: false };
  }

  const code = generateCode();
  await createVerificationCode({
    email,
    codeHash: hashCode(code),
    purpose: "reset",
    pendingName: row.name,
    pendingDiscord: "",
    pendingPasswordHash: "",
    expiresAt: codeExpiry(),
  });

  const message = passwordResetEmail({ name: row.name, code });
  message.to = email;
  const delivery = await sendMail(message);

  return delivery.sent
    ? { accepted: true, sent: true }
    : { accepted: true, sent: false, manualCode: code };
}

/**
 * Cambia la contraseña usando el código recibido por correo.
 *
 * Si el código es correcto, se guarda la contraseña nueva y se consume el
 * código: no se puede reutilizar.
 */
export async function confirmPasswordReset(data: {
  email: string;
  code: string;
  passwordHash: string;
}) {
  const pending = await getLatestVerificationCode(data.email, "reset");
  if (!pending) {
    throw new Error("No encontramos un código activo para este correo. Pedí uno nuevo.");
  }

  const check = assertUsableCode(pending, data.code);
  if (!check.valid) {
    if (check.message === "El código no coincide.") await recordVerificationAttempt(pending.id);
    throw new Error(check.message);
  }

  const row = await findCustomerByEmail(data.email);
  if (!row || !row.active) {
    throw new Error("No encontramos una cuenta activa con ese correo.");
  }

  await updateCustomerPassword(row.id, data.passwordHash);
  await consumeVerificationCode(pending.id);
  return row.id;
}