/**
 * Pruebas de la recuperación de contraseña.
 *
 * Cubren lo importante: que no se pueda averiguar qué correos tienen cuenta,
 * que el código sirva una sola vez, que venza y que la contraseña nueva quede
 * guardada como hash y sirva para ingresar.
 */
import { beforeEach, describe, expect, it, vi } from "vitest";
import { codeExpiry, generateCode, hashCode } from "./verification";

const estado = {
  cuenta: undefined as Record<string, unknown> | undefined,
  codigos: [] as Array<Record<string, unknown>>,
  contraseñaGuardada: undefined as string | undefined,
  correosEnviados: [] as Array<{ to: string; subject: string }>,
  correoConfigurado: true,
};

vi.mock("./db", () => ({
  findCustomerByEmail: vi.fn(async (email: string) => {
    const c = estado.cuenta;
    return c && c.email === email ? { ...c } : undefined;
  }),
  createVerificationCode: vi.fn(async (data: Record<string, unknown>) => {
    estado.codigos.push({
      id: estado.codigos.length + 1,
      attempts: 0,
      consumedAt: null,
      invitedBy: "",
      pendingName: "",
      pendingDiscord: "",
      pendingPasswordHash: "",
      ...data,
    });
    return estado.codigos.length;
  }),
  getLatestVerificationCode: vi.fn(async (email: string, purpose: string) => {
    const encontrados = estado.codigos.filter(
      (c) => c.email === email && c.purpose === purpose,
    );
    return encontrados[encontrados.length - 1];
  }),
  recordVerificationAttempt: vi.fn(async (id: number) => {
    const c = estado.codigos.find((x) => x.id === id);
    if (c) c.attempts = Number(c.attempts) + 1;
  }),
  consumeVerificationCode: vi.fn(async (id: number) => {
    const c = estado.codigos.find((x) => x.id === id);
    if (c) c.consumedAt = new Date();
  }),
  updateCustomerPassword: vi.fn(async (_id: number, hash: string) => {
    estado.contraseñaGuardada = hash;
  }),
}));

vi.mock("./email", () => ({
  sendMail: vi.fn(async (input: { to: string; subject: string }) => {
    estado.correosEnviados.push({ to: input.to, subject: input.subject });
    return estado.correoConfigurado ? { sent: true } : { sent: false, reason: "sin-clave" };
  }),
  passwordResetEmail: vi.fn((options: { name: string; code: string }) => ({
    to: "",
    subject: `${options.code} es tu código para recuperar la contraseña`,
    html: options.code,
    text: options.code,
  })),
}));

const { confirmPasswordReset, startPasswordReset } = await import("./passwordReset");

/** Cuenta de prueba con contraseña ya definida. */
function cuentaDePrueba(overrides: Record<string, unknown> = {}) {
  return {
    id: 7,
    email: "cliente@imperioshop.com",
    name: "Cliente Prueba",
    passwordHash: "hash-viejo",
    discord: "",
    provider: "email",
    active: true,
    ...overrides,
  };
}

beforeEach(() => {
  estado.cuenta = cuentaDePrueba();
  estado.codigos = [];
  estado.contraseñaGuardada = undefined;
  estado.correosEnviados = [];
  estado.correoConfigurado = true;
});

describe("pedir el código de recuperación", () => {
  it("manda el código al correo cuando la cuenta existe", async () => {
    const r = await startPasswordReset("cliente@imperioshop.com");
    expect(r.accepted).toBe(true);
    expect(r.sent).toBe(true);
    expect(estado.correosEnviados).toHaveLength(1);
    expect(estado.correosEnviados[0].to).toBe("cliente@imperioshop.com");
    expect(estado.codigos).toHaveLength(1);
    expect(estado.codigos[0].purpose).toBe("reset");
  });

  it("responde igual cuando la cuenta NO existe: no revela quién está registrado", async () => {
    const r = await startPasswordReset("desconocido@ejemplo.com");
    expect(r.accepted).toBe(true);
    expect(r.sent).toBe(false);
    // Lo importante: no se envió ningún correo y el código no se guardó.
    expect(estado.correosEnviados).toHaveLength(0);
    expect(estado.codigos).toHaveLength(0);
  });

  it("responde igual cuando la cuenta está desactivada", async () => {
    estado.cuenta = cuentaDePrueba({ active: false });
    const r = await startPasswordReset("cliente@imperioshop.com");
    expect(r.accepted).toBe(true);
    expect(r.sent).toBe(false);
    expect(estado.correosEnviados).toHaveLength(0);
  });

  it("avisa al equipo cuando el correo todavía no está configurado", async () => {
    estado.correoConfigurado = false;
    const r = await startPasswordReset("cliente@imperioshop.com");
    expect(r.accepted).toBe(true);
    expect(r.sent).toBe(false);
    // El código queda disponible para el equipo, nunca se pierde.
    expect(r.manualCode).toMatch(/^\d{6}$/);
  });
});

describe("cambiar la contraseña con el código", () => {
  /** Pide el código y devuelve el que quedó guardado (en hash). */
  async function pedirCodigo() {
    await startPasswordReset("cliente@imperioshop.com");
    const guardado = estado.codigos.at(-1)!;
    return guardado;
  }

  it("cambia la contraseña con el código correcto", async () => {
    const codigo = generateCode();
    await pedirCodigo();
    // Reemplazamos el hash por el de un código que conocemos.
    estado.codigos[estado.codigos.length - 1].codeHash = hashCode(codigo);

    const id = await confirmPasswordReset({
      email: "cliente@imperioshop.com",
      code: codigo,
      passwordHash: "hash-nuevo",
    });

    expect(id).toBe(7);
    expect(estado.contraseñaGuardada).toBe("hash-nuevo");
    // El código se consume: no se puede reutilizar.
    expect(estado.codigos[estado.codigos.length - 1].consumedAt).toBeInstanceOf(Date);
  });

  it("rechaza un código equivocado y cuenta el intento", async () => {
    await pedirCodigo();
    await expect(
      confirmPasswordReset({
        email: "cliente@imperioshop.com",
        code: "000001",
        passwordHash: "hash-nuevo",
      }),
    ).rejects.toThrow("El código no coincide.");
    expect(estado.contraseñaGuardada).toBeUndefined();
    expect(estado.codigos[estado.codigos.length - 1].attempts).toBe(1);
  });

  it("rechaza un código vencido", async () => {
    const codigo = generateCode();
    await pedirCodigo();
    const pendiente = estado.codigos[estado.codigos.length - 1];
    pendiente.codeHash = hashCode(codigo);
    pendiente.expiresAt = new Date(Date.now() - 1000);

    await expect(
      confirmPasswordReset({
        email: "cliente@imperioshop.com",
        code: codigo,
        passwordHash: "hash-nuevo",
      }),
    ).rejects.toThrow("El código venció");
    expect(estado.contraseñaGuardada).toBeUndefined();
  });

  it("no deja reutilizar un código ya usado", async () => {
    const codigo = generateCode();
    await pedirCodigo();
    const pendiente = estado.codigos[estado.codigos.length - 1];
    pendiente.codeHash = hashCode(codigo);

    await confirmPasswordReset({
      email: "cliente@imperioshop.com",
      code: codigo,
      passwordHash: "hash-nuevo",
    });
    estado.contraseñaGuardada = undefined;

    await expect(
      confirmPasswordReset({
        email: "cliente@imperioshop.com",
        code: codigo,
        passwordHash: "hash-otro",
      }),
    ).rejects.toThrow("ya fue usado");
    expect(estado.contraseñaGuardada).toBeUndefined();
  });

  it("corta cuando se superan los intentos permitidos", async () => {
    const codigo = generateCode();
    await pedirCodigo();
    const pendiente = estado.codigos[estado.codigos.length - 1];
    pendiente.codeHash = hashCode(codigo);
    pendiente.attempts = 5;

    await expect(
      confirmPasswordReset({
        email: "cliente@imperioshop.com",
        code: codigo,
        passwordHash: "hash-nuevo",
      }),
    ).rejects.toThrow("Superaste los intentos permitidos");
  });

  it("exige que el código siga vigente en el tiempo", () => {
    // El vencimiento del código es corto: 15 minutos.
    const vence = codeExpiry();
    expect(vence.getTime()).toBeGreaterThan(Date.now());
    expect(vence.getTime() - Date.now()).toBeLessThan(16 * 60 * 1000);
  });
});