/**
 * Sincroniza el catálogo de `catalogData.ts` con la base de datos.
 *
 * A diferencia de la carga inicial (que solo agrega lo que falta), este script
 * *actualiza* los servicios y planes que ya existen para que reflejen los
 * textos y precios del archivo. Los planes que ya no figuran en el archivo se
 * desactivan (no se borran) para no perder el historial de pedidos.
 *
 * Uso:
 *   pnpm tsx server/syncCatalog.ts
 */
import { and, eq } from "drizzle-orm";
import { faqs, plans, services } from "../drizzle/schema";
import { CATALOG_SEED, FAQ_SEED } from "./catalogData";
import { extractInsertId, getDb } from "./db";

async function main() {
  const db = await getDb();
  if (!db) {
    console.error("Base de datos no disponible");
    process.exit(1);
  }

  let servicesUpdated = 0;
  let servicesCreated = 0;
  let plansUpdated = 0;
  let plansCreated = 0;
  let plansDeactivated = 0;

  for (const entry of CATALOG_SEED) {
    const { plans: planList, ...serviceData } = entry;

    const servicePatch = {
      name: serviceData.name,
      tagline: serviceData.tagline,
      description: serviceData.description,
      imageUrl: serviceData.imageUrl,
      icon: serviceData.icon,
      badge: serviceData.badge,
      accent: serviceData.accent,
      features: JSON.stringify(serviceData.features),
      deliveryTime: serviceData.deliveryTime,
      sortOrder: serviceData.sortOrder,
      active: true,
    };

    const existing = await db
      .select()
      .from(services)
      .where(eq(services.slug, serviceData.slug))
      .limit(1);

    let serviceId: number;
    if (existing[0]) {
      serviceId = existing[0].id;
      await db.update(services).set(servicePatch).where(eq(services.id, serviceId));
      servicesUpdated += 1;
    } else {
      const result = await db
        .insert(services)
        .values({ slug: serviceData.slug, ...servicePatch });
      serviceId = extractInsertId(result);
      servicesCreated += 1;
    }

    const currentPlans = await db
      .select()
      .from(plans)
      .where(eq(plans.serviceId, serviceId));

    const wantedNames = new Set(planList.map((plan) => plan.name));

    for (const plan of planList) {
      const planPatch = {
        priceCents: plan.priceCents,
        currency: "USD",
        billing: plan.billing,
        summary: plan.summary,
        specs: JSON.stringify(plan.specs),
        features: JSON.stringify(plan.features),
        popular: plan.popular,
        stockLabel: plan.stockLabel,
        sortOrder: plan.sortOrder,
        active: true,
      };

      const match = currentPlans.find((row) => row.name === plan.name);
      if (match) {
        await db.update(plans).set(planPatch).where(eq(plans.id, match.id));
        plansUpdated += 1;
      } else {
        await db.insert(plans).values({ serviceId, name: plan.name, ...planPatch });
        plansCreated += 1;
      }
    }

    // Planes que ya no figuran en el archivo: se desactivan, no se borran.
    for (const row of currentPlans) {
      if (wantedNames.has(row.name)) continue;
      if (!row.active) continue;
      await db.update(plans).set({ active: false }).where(eq(plans.id, row.id));
      plansDeactivated += 1;
    }
  }

  // Servicios que ya no figuran en el archivo: se desactivan.
  const allServices = await db.select().from(services);
  const wantedSlugs = new Set(CATALOG_SEED.map((entry) => entry.slug));
  let servicesDeactivated = 0;
  for (const row of allServices) {
    if (wantedSlugs.has(row.slug)) continue;
    if (!row.active) continue;
    await db.update(services).set({ active: false }).where(eq(services.id, row.id));
    await db
      .update(plans)
      .set({ active: false })
      .where(and(eq(plans.serviceId, row.id), eq(plans.active, true)));
    servicesDeactivated += 1;
  }

  console.log("Catálogo sincronizado:");
  console.log(`  servicios: ${servicesCreated} nuevos, ${servicesUpdated} actualizados, ${servicesDeactivated} desactivados`);
  console.log(`  planes:    ${plansCreated} nuevos, ${plansUpdated} actualizados, ${plansDeactivated} desactivados`);

  /* --------------------------- preguntas frecuentes -------------------------- */
  // Se emparejan por pregunta: si cambia la respuesta, se actualiza; si la
  // pregunta es nueva, se agrega. Así el sitio nunca queda con textos viejos.
  const currentFaqs = await db.select().from(faqs);
  let faqsUpdated = 0;
  let faqsCreated = 0;
  for (const item of FAQ_SEED) {
    const match = currentFaqs.find((row) => row.question === item.question);
    if (match) {
      await db
        .update(faqs)
        .set({ answer: item.answer, sortOrder: item.sortOrder, active: true })
        .where(eq(faqs.id, match.id));
      faqsUpdated += 1;
    } else {
      await db.insert(faqs).values({ ...item, active: true });
      faqsCreated += 1;
    }
  }
  console.log(`  preguntas: ${faqsCreated} nuevas, ${faqsUpdated} actualizadas`);
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
