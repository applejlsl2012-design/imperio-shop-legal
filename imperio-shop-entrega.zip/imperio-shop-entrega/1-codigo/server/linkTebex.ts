/**
 * Vincula los planes de la web con sus paquetes de Tebex.
 *
 * Lee los paquetes reales de la tienda por la API Headless y los empareja con
 * los planes de la base por nombre. Es idempotente: se puede correr las veces
 * que haga falta y solo escribe cuando encuentra una correspondencia.
 *
 * Uso:
 *   pnpm tsx server/linkTebex.ts          (vincula)
 *   pnpm tsx server/linkTebex.ts --dry    (solo muestra qué haría)
 */
import { eq } from "drizzle-orm";
import { plans, services } from "../drizzle/schema";
import { ENV } from "./_core/env";
import { getDb } from "./db";
import { listTebexPackages } from "./tebex";

/**
 * Nombres que no coinciden literalmente entre la web y Tebex.
 * La clave es el nombre del plan en la web; el valor, el del paquete en Tebex.
 */
const ALIASES: Record<string, string> = {
  "Hosting Bot Dedicado": "Hosting",
};

/** Normaliza un nombre para comparar: sin acentos, minúsculas y sin espacios extra. */
function normalizar(valor: string): string {
  return valor
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/\s+/g, " ")
    .trim();
}

async function main() {
  const dry = process.argv.includes("--dry");

  if (!ENV.tebexPublicToken || !ENV.tebexPrivateKey) {
    console.error("Faltan las claves de Tebex (TEBEX_PUBLIC_TOKEN / TEBEX_PRIVATE_KEY).");
    process.exit(1);
  }

  const paquetes = await listTebexPackages();
  if (!paquetes.ok) {
    console.error("No se pudieron leer los paquetes de Tebex:", paquetes.error);
    process.exit(1);
  }
  console.log(`Paquetes encontrados en Tebex: ${paquetes.data.length}`);
  for (const p of paquetes.data) {
    console.log(`  · ${p.name} — ${p.total_price} ${p.currency} (${p.type}) id=${p.id}`);
  }

  const db = await getDb();
  if (!db) {
    console.error("Base de datos no disponible");
    process.exit(1);
  }

  const filas = await db
    .select({
      planId: plans.id,
      planName: plans.name,
      serviceName: services.name,
      actual: plans.tebexPackageId,
    })
    .from(plans)
    .innerJoin(services, eq(services.id, plans.serviceId))
    .where(eq(plans.active, true));

  const porNombre = new Map(paquetes.data.map((p) => [normalizar(p.name), p]));

  let vinculados = 0;
  const sinMatch: string[] = [];

  for (const fila of filas) {
    const objetivo = ALIASES[fila.planName] ?? fila.planName;
    const paquete = porNombre.get(normalizar(objetivo));

    if (!paquete) {
      sinMatch.push(`${fila.serviceName} → ${fila.planName}`);
      continue;
    }

    if (fila.actual === paquete.id) {
      console.log(`  = ${fila.planName} ya estaba vinculado (${paquete.id})`);
      continue;
    }

    if (!dry) {
      await db.update(plans).set({ tebexPackageId: paquete.id }).where(eq(plans.id, fila.planId));
    }
    console.log(`  ✓ ${fila.planName} → ${paquete.name} (${paquete.id})`);
    vinculados += 1;
  }

  console.log("");
  console.log(`${dry ? "[simulación] " : ""}Vinculados: ${vinculados}`);
  if (sinMatch.length > 0) {
    console.log("Sin paquete equivalente en Tebex:");
    for (const nombre of sinMatch) console.log(`  ! ${nombre}`);
  }
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
