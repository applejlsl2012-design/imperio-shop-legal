/**
 * Genera el código público de un pedido.
 *
 * Se usa tanto en la compra del cliente como en los pedidos de prueba del
 * panel, para que todos los códigos tengan el mismo formato.
 */
export function makeOrderCode(prefix: string): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const block = Array.from(
    { length: 6 },
    () => alphabet[Math.floor(Math.random() * alphabet.length)],
  ).join("");
  return `${prefix || "IMP"}-${block}`;
}
