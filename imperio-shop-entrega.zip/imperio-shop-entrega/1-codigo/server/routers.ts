import { TRPCError } from "@trpc/server";
import { desc, eq } from "drizzle-orm";
import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { orders } from "../drizzle/schema";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import {
  createCustomer,
  createOrder,
  getCatalog,
  getCustomerById,
  getDb,
  getOrderByCode,
  getOrderStats,
  getPlanById,
  getServiceById,
  getServiceBySlug,
  getSettingsMap,
  listFaqs,
  listPublishedReviews,
  listServiceReviews,
  listTestimonials,
} from "./db";
import { readCustomerSession } from "./customerAuth";
import { readStaffSession } from "./staffAuth";
import { makeOrderCode } from "./orderCode";
import {
  clientIp,
  createTebexCheckout,
  fillTebexBasket,
  getTebexStatus,
  publicOrigin,
  tebexConfigured,
} from "./tebex";
import { logActivity } from "./activity";
import { adminRouter } from "./routers/admin";
import { customerRouter } from "./routers/customer";
import { ensureSeeded } from "./seed";

const contactSchema = z.object({
  // Nombre y correo se toman de la cuenta con sesión; se aceptan vacíos para
  // que el servidor los complete con los datos verificados del cliente.
  customerName: z.string().trim().max(160).optional().default(""),
  customerEmail: z.string().trim().max(320).optional().default(""),
  customerDiscord: z.string().trim().max(120).optional().default(""),
  customerNote: z.string().trim().max(1500).optional().default(""),
  payerAccount: z.string().trim().max(160).optional().default(""),
  paymentReference: z.string().trim().max(200).optional().default(""),
});


function safeJson<T>(value: string, fallback: T): T {
  try {
    const parsed = JSON.parse(value);
    return (parsed ?? fallback) as T;
  } catch {
    return fallback;
  }
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  /** Cuentas de clientes: registro, ingreso y mis compras. */
  customer: customerRouter,

  /* ------------------------------- catálogo ------------------------------- */
  catalog: router({
    list: publicProcedure.query(async () => {
      await ensureSeeded();
      const catalog = await getCatalog();
      const settings = await getSettingsMap();
      return {
        services: catalog.map((service) => ({
          ...service,
          features: safeJson<string[]>(service.features, []),
          plans: service.plans.map((plan) => ({
            ...plan,
            specs: safeJson<string[]>(plan.specs, []),
            features: safeJson<string[]>(plan.features, []),
          })),
        })),
        settings,
      };
    }),

    service: publicProcedure
      .input(z.object({ slug: z.string().min(1) }))
      .query(async ({ input }) => {
        await ensureSeeded();
        const service = await getServiceBySlug(input.slug);
        if (!service) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Servicio no encontrado" });
        }
        const reviewRows = await listServiceReviews(service.id, 6);
        return {
          ...service,
          features: safeJson<string[]>(service.features, []),
          plans: service.plans.map((plan) => ({
            ...plan,
            specs: safeJson<string[]>(plan.specs, []),
            features: safeJson<string[]>(plan.features, []),
          })),
          reviews: reviewRows.map((row) => ({
            id: row.id,
            author: row.authorName,
            rating: row.rating,
            comment: row.comment,
            reply: row.reply,
            publishedAt: row.publishedAt,
          })),
        };
      }),

    extras: publicProcedure.query(async () => {
      await ensureSeeded();
      const [faqRows, testimonialRows, settings, reviewRows, stats] = await Promise.all([
        listFaqs(),
        listTestimonials(),
        getSettingsMap(),
        listPublishedReviews(8),
        getOrderStats(),
      ]);
      return {
        faqs: faqRows,
        testimonials: testimonialRows,
        settings,
        // Entregas reales: el inicio muestra este número en lugar de un valor fijo.
        deliveredCount: stats.delivered,
        reviews: reviewRows.map((row) => ({
          id: row.id,
          author: row.authorName,
          serviceName: row.serviceName,
          rating: row.rating,
          comment: row.comment,
          reply: row.reply,
          featured: row.featured,
          publishedAt: row.publishedAt,
        })),
      };
    }),
  }),

  /* -------------------------------- pedidos ------------------------------- */
  orders: router({
    /**
     * La web avisa cada vez que alguien abre una página pública. Así el panel
     * muestra el movimiento real del sitio (visitas, servicios más vistos).
     */
    visit: publicProcedure
      .input(
        z.object({
          path: z.string().trim().max(200).default("/"),
          referrer: z.string().trim().max(300).default(""),
        }),
      )
      .mutation(async ({ input, ctx }) => {
        const session = readCustomerSession(ctx.req);
        const account = session ? await getCustomerById(session.customerId) : undefined;

        logActivity({
          kind: "visita",
          title: account
            ? `${account.name} visitó ${input.path}`
            : `Visitante en ${input.path}`,
          detail: input.referrer ? `Llegó desde ${input.referrer}` : "Entró directo al sitio.",
          actor: account?.name ?? "visitante",
          actorEmail: account?.email ?? "",
          customerId: account?.id ?? null,
          meta: { path: input.path, referrer: input.referrer },
          req: ctx.req,
        });
        return { success: true } as const;
      }),

    create: publicProcedure
      .input(
        z.object({
          planId: z.number().int().positive(),
          details: contactSchema,
        }),
      )
      .mutation(async ({ input, ctx }) => {
        await ensureSeeded();

        // Toda compra queda registrada con la cuenta del cliente.
        const session = readCustomerSession(ctx.req);
        const account = session ? await getCustomerById(session.customerId) : undefined;
        // El equipo del panel también puede comprar sin crear cuenta de
        // cliente: su pedido queda marcado como prueba del equipo.
        const staff = account ? null : readStaffSession(ctx.req);
        if ((!account || !account.active) && !staff) {
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "Iniciá sesión o creá tu cuenta para completar la compra",
          });
        }

        const plan = await getPlanById(input.planId);
        if (!plan || !plan.active) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "El plan elegido ya no está disponible",
          });
        }
        const service = await getServiceById(plan.serviceId);
        if (!service) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Servicio no encontrado" });
        }

        const settings = await getSettingsMap();
        const code = makeOrderCode(settings["orders.prefix"] ?? "IMP");
        /**
         * Datos de quien compra.
         *
         * Si hay cuenta de cliente, mandan sus datos verificados. Si no, es el
         * equipo del panel probando: usamos su nombre y los datos que cargó.
         */
        const comprador = account
          ? {
              nombre: input.details.customerName || account.name,
              correo: account.email,
              discord: input.details.customerDiscord ?? account.discord ?? "",
              customerId: account.id,
              notaInterna: "",
            }
          : {
              nombre: input.details.customerName || `Prueba ${staff?.label ?? "del panel"}`,
              correo: input.details.customerEmail || "prueba@imperioshop.com",
              discord: input.details.customerDiscord ?? "",
              customerId: null,
              // Queda claro en el panel que no es una compra de un cliente real.
              notaInterna: `Pedido de prueba creado por ${staff?.label ?? "el equipo"} desde la web. No corresponde a un cobro real de un cliente.`,
            };
        // Solo intentamos cobrar si la tienda realmente puede hacerlo. Si no,
        // evitamos mandar al cliente a un checkout que no va a poder completar.
        const estadoTebex = tebexConfigured() ? await getTebexStatus() : null;
        const wantsTebex =
          Boolean(plan.tebexPackageId) && tebexConfigured() && Boolean(estadoTebex?.canCharge);
        let checkoutUrl = "";
        let basketIdent = "";
        // Si la tienda exige iniciar sesión, devolvemos ese enlace.
        let authUrl = "";
        let authProvider = "";
        // Si Tebex está configurado pero no se pudo cobrar, lo avisamos abajo
        // en lugar de mostrar un pago manual que no existe.
        let tebexFailed = false;
        if (wantsTebex) {
          const origin = publicOrigin(ctx.req);
          // Un cliente vuelve a Mis compras. El dueño o socio que está
          // probando con el código del panel vuelve al panel, donde se verifica
          // el pago sin pedirle crear una cuenta de cliente.
          const vuelta = account ? "/mis-compras" : "/panel/pedidos";
          const checkout = await createTebexCheckout({
            packageId: plan.tebexPackageId as number,
            orderCode: code,
            // Al volver, la web verifica el pago de ESTE pedido contra Tebex.
            completeUrl: `${origin}${vuelta}?pago=ok&pedido=${encodeURIComponent(code)}`,
            cancelUrl: `${origin}/servicio/${service.slug}`,
            // Tras identificarse en Tebex, el cliente vuelve acá a retomar el pago.
            resumeUrl: `${origin}${vuelta}?pedido=${encodeURIComponent(code)}&reanudar=1`,
            ipAddress: clientIp(ctx.req),
          });
          if (checkout.ok) {
            checkoutUrl = checkout.data.checkoutUrl;
            basketIdent = checkout.data.basketIdent;
            authUrl = checkout.data.authUrl ?? "";
            authProvider = checkout.data.authProvider ?? "";
          } else {
            tebexFailed = true;
            console.warn("[Tebex] No se pudo crear el checkout:", checkout.error);
          }
        }
        const orderId = await createOrder({
          code,
          serviceId: service.id,
          serviceName: service.name,
          planId: plan.id,
          planName: plan.name,
          amountCents: plan.priceCents,
          currency: plan.currency,
          billing: plan.billing,
          customerName: comprador.nombre,
          customerEmail: comprador.correo,
          customerDiscord: comprador.discord,
          customerNote: input.details.customerNote ?? "",
          paymentMethod: "tebex",
          payerAccount: input.details.payerAccount ?? "",
          paymentReference: input.details.paymentReference ?? "",
          tebexBasketIdent: basketIdent,
          tebexTransactionId: "",
          tebexPaymentMethod: "",
          status: "pending_payment",
          staffNote: comprador.notaInterna,
          userId: ctx.user?.id ?? null,
          customerId: comprador.customerId,
        });

        logActivity({
          kind: account ? "pedido.nuevo" : "pedido.prueba",
          title: account ? `Nuevo pedido ${code}` : `Prueba de compra ${code}`,
          detail: `${comprador.nombre} ${account ? "solicitó" : "probó"} ${service.name} · ${plan.name} por ${plan.currency} ${(plan.priceCents / 100).toFixed(2)}.`,
          actor: comprador.nombre,
          actorEmail: comprador.correo,
          customerId: comprador.customerId,
          orderId,
          meta: {
            service: service.name,
            plan: plan.name,
            amountCents: plan.priceCents,
            currency: plan.currency,
            ...(account ? {} : { prueba: true }),
          },
          req: ctx.req,
        });

        return {
          code,
          amountCents: plan.priceCents,
          currency: plan.currency,
          billing: plan.billing,
          planName: plan.name,
          serviceName: service.name,
          paymentSteps: settings["payment.steps"] ?? "",
          paymentInstructions: settings["payment.instructions"] ?? "",
          paymentAccount: settings["payment.account"] ?? "",
          paymentQrUrl: settings["payment.qrUrl"] ?? "",
          contactDiscord: settings["contact.discord"] ?? "",
          /** Enlace al checkout de Tebex: si viene, el pago se hace ahí. */
          checkoutUrl,
          /**
           * Identificador de la canasta. Con él, la web abre el pago de Tebex
           * dentro de la propia página (el cliente carga la tarjeta en el marco
           * seguro de Tebex, sin salir del sitio).
           */
          basketIdent,
          /**
           * Enlace de acceso que exige la tienda antes de pagar. Si viene,
           * hay que llevar al cliente ahí y después volver a `resume`.
           */
          authUrl,
          authProvider,
          paymentMethod: wantsTebex ? "tebex" : "manual",
          /** Tebex está activo pero no pudo generar el cobro. */
          tebexFailed,
        };
      }),

    /**
     * Retoma un checkout que quedó pendiente de autorización.
     *
     * Se usa cuando el cliente ya se identificó en Tebex y vuelve al sitio: con
     * el `ident` de la canasta reintentamos agregar el paquete y obtenemos el
     * enlace de pago definitivo.
     */
    resumeTebex: publicProcedure
      .input(z.object({ code: z.string().trim().min(4).max(24) }))
      .mutation(async ({ input, ctx }) => {
        const session = readCustomerSession(ctx.req);
        const account = session ? await getCustomerById(session.customerId) : undefined;
        if (!account || !account.active) {
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "Iniciá sesión para retomar tu pago",
          });
        }

        const order = await getOrderByCode(input.code.trim().toUpperCase());
        // Solo el dueño del pedido puede retomarlo.
        if (!order || order.customerId !== account.id) {
          throw new TRPCError({ code: "NOT_FOUND", message: "No encontramos ese pedido" });
        }

        // La canasta se recupera del propio pedido: nunca se confía en el cliente.
        const basketIdent = order.tebexBasketIdent;
        if (!basketIdent) {
          return {
            ok: false as const,
            message: "Este pedido no tiene un pago en línea asociado.",
            authUrl: "",
          };
        }

        // El paquete de Tebex vive en el plan, no en el pedido.
        const plan = order.planId ? await getPlanById(order.planId) : undefined;
        const packageId = plan?.tebexPackageId ?? null;
        if (!packageId) {
          return {
            ok: false as const,
            message: "Este plan no tiene un pago en línea asociado.",
            authUrl: "",
          };
        }

        const origin = publicOrigin(ctx.req);
        const filled = await fillTebexBasket(
          basketIdent,
          packageId,
          1,
          `${origin}/mis-compras?pago=ok&pedido=${encodeURIComponent(order.code)}`,
        );
        if (!filled.ok) {
          return { ok: false as const, message: filled.error, authUrl: "" };
        }
        if (filled.data.needsAuth) {
          // Sigue exigiendo login: devolvemos el enlace otra vez.
          return {
            ok: false as const,
            message: "Tebex todavía pide iniciar sesión.",
            authUrl: filled.data.authUrl ?? "",
          };
        }
        return { ok: true as const, message: "", checkoutUrl: filled.data.checkoutUrl, authUrl: "" };
      }),

    /**
     * Estado real de la tienda de Tebex.
     *
     * Sirve para avisar en el sitio cuando la tienda no puede cobrar todavía
     * (por ejemplo si está deshabilitada o si exige una cuenta que nuestros
     * clientes no tienen), en lugar de dejar que el cliente falle al pagar.
     */
    tebexStatus: publicProcedure.query(async () => {
      return getTebexStatus();
    }),


    /** Historial de los pedidos hechos con la cuenta que inició sesión. */
    mine: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return [];
      return db
        .select()
        .from(orders)
        .where(eq(orders.userId, ctx.user.id))
        .orderBy(desc(orders.createdAt))
        .limit(50);
    }),
  }),

  /* --------------------------- panel privado ------------------------------ */
  admin: adminRouter,
});

export type AppRouter = typeof appRouter;
