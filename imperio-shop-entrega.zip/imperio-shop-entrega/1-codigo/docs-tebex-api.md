# Tebex — estado de la integración (28/09)

## 1. La tienda

| Dato | Valor |
| --- | --- |
| Nombre | Imperio Shop |
| Project ID | 1901648 |
| Moneda | USD |
| **Plataforma** | **FiveM** |
| `supports_usernames` | **true** |
| Webstore pública | https://imperio-shop.tebex.store |
| Categoría | Servicios Imperio Shop (id 3457802) |

Paquetes reales (creados por el usuario):

| id | Nombre | Precio | Tipo |
| --- | --- | --- | --- |
| 7700329 | Bot Básico | 8 USD | single |
| 7700426 | Bot Avanzado | 16 USD | single |
| 7700432 | Bot Pro | 28 USD | single |
| 7700744 | Hosting | 5 USD | subscription |
| 7700788 | Web Basic | 30 USD | single |
| 7702701 | Web Advanced | 60 USD | single |
| 7702717 | Web Pro | 80 USD | single |
| 7702719 | Web Ultimate | 155 USD | single |

## 2. BUG CORREGIDO — ruta para agregar paquete (404)

El código usaba:

```
POST /api/accounts/{token}/baskets/{ident}/packages   -> 404 Not Found
```

La ruta correcta (sin el prefijo de la cuenta) es:

```
POST /api/baskets/{ident}/packages                    -> existe
```

Documentación: `developers/headless-api/guides/baskets/add-package-to-basket`
El esquema oficial declara ese endpoint con servidor `/api/accounts/{token}`
pero la ruta real es `/api/baskets/{basketIdent}/packages`.

**Corregido en `server/tebex.ts`** con el helper `basketsApiBase()` y `package_id`
enviado como string (tal como pide el esquema oficial).

## 3. BLOQUEO REAL — la tienda es FiveM y exige login

Con la ruta ya corregida, Tebex responde:

```json
{"status":422,"title":"Request payload error",
 "detail":"User must login before adding packages to basket"}
```

Motivo: el proyecto está configurado como **plataforma FiveM**, y en ese tipo de
tienda el comprador debe autenticarse con su cuenta de Cfx.re **antes** de poder
agregar productos a la canasta.

Pruebas hechas:

- Crear canasta **sin** `username` → 200 (correcto, con `username: null`).
- Crear canasta **con** `username` → **400** (no se puede inyectar el usuario así).
- Agregar paquete → **422 "User must login before adding packages to basket"**.
- Endpoint de autorización → 200, devuelve el proveedor:

```json
[{"name":"FiveM","type":"link",
  "url":"https://ident.tebex.io/fivem?return=...&signature=..."}]
```

Es decir: hay que mandar al cliente a `ident.tebex.io/fivem`, que lo devuelve a
la canasta ya autorizada. El `links.checkout` **no aparece** hasta que la canasta
tiene el paquete agregado.

### Opciones para destrabarlo

1. **Cambiar el tipo de proyecto a Universal** en el panel de Tebex
   (`Platform`), que no exige login. Es lo que mejor encaja con una tienda de
   bots/hosting/web para Discord, donde el cliente no tiene cuenta de FiveM.
2. **Dejar FiveM** y agregar el paso de autorización en el flujo de compra
   (redirigir a `ident.tebex.io/fivem` y volver), lo que suma un login extra al
   comprador y solo tiene sentido si los clientes son de FiveM.
3. La **Checkout API** (baskets con productos personalizados) resolvería esto,
   pero la documentación aclara que **requiere aprobación previa del equipo de
   cumplimiento** y **no está disponible para creadores de FiveM**.

## 4. El Webstore Builder NO acepta archivos

Cita textual de la documentación oficial de Apariencia
(`creators/tebex-control-panel/webstore/appearance`):

> "Full HTML & CSS Editing is currently unavailable on new stores using our new
> storefronts system - we're working on bringing this functionality back soon."

El editor nuevo (builder.tebex.io) es **por bloques**: Pages, Layout (Header,
Category List, Carousel, Category, Footer), Global (Theme, Images, Login, Basket,
Package pop-up). Solo permite:

- **Colores**: Primary, Secondary, Background, Surface, Text.
- **Tipografías**: Montserrat + Poppins.
- **Radios, paddings y espaciados.**
- **Imágenes**: logo y favicon (PNG/WEBP).
- Textos y estructura de las secciones.

**No hay forma de subir un sitio HTML/CSS propio ni un ZIP.** Las plantillas
Twig/CSS existían en el sistema viejo ("Legacy Webstore template users") y la
propia documentación aclara que esa edición completa de HTML y CSS no está
disponible en las tiendas nuevas.

Conclusión: la web hecha a medida **no se puede "subir" a Tebex**. Lo correcto
es lo que ya está implementado: la web propia se queda en su dominio y Tebex se
usa solo como pasarela de pago, que es justo el propósito de la **Headless API**.

## 5. Fuentes

- Índice: https://docs.tebex.io/developers/llms.txt
- Añadir paquete: `developers/headless-api/guides/baskets/add-package-to-basket`
- Crear canasta: `developers/headless-api/guides/baskets/create-a-basket`
- Autorizar canasta: `developers/headless-api/guides/baskets/authorize-a-basket`
- Checkout: `developers/headless-api/guides/checkout`
- Endpoints: `developers/headless-api/endpoints`
- Apariencia: `creators/tebex-control-panel/webstore/appearance`
- Plantillas: `developers/templates/overview`
- Checkout API: `developers/checkout-api/overview`
## 6. Cambiar el tipo de tienda NO se puede (confirmado)

La FAQ oficial de Tebex lo dice textual:

> "Use the FiveM store type only. Can I change store type later? Usually not.
> Double-check your setup before creation."

Es decir: **el tipo de tienda se elige al crearla y normalmente no se puede
cambiar después.** Con la tienda en FiveM, el checkout va a seguir pidiendo
login de Cfx.re. Para cobrar sin ese login hay que **crear un proyecto nuevo
con tipo Universal** y volver a cargar los paquetes ahí.

En `Settings → Project` sí existe la opción
"Enable Webstore Management Features" para apagar la tienda alojada por Tebex
cuando se usa la Headless API, pero eso no cambia el tipo de plataforma.

## 7. Fallo silencioso en el flujo de compra (a revisar)

En `server/routers.ts`, dentro de `orders.create`, si Tebex falla el código
**no avisa al cliente**: deja `checkoutUrl` vacío y cae al flujo manual
(`paymentMethod: "manual"`), mostrando "Importe a transferir por Tebex" con
`paymentAccount` vacío. El cliente ve un mensaje de pago roto.

Con Tebex en FiveM esto pasa **siempre**, porque agregar el paquete devuelve
422. Conviene que, cuando Tebex esté configurado y falle, el sitio lo diga
claramente y derive al ticket en Discord en lugar de fingir un pago manual.
## 8. Diagnóstico del 4/10 — por qué el sitio NO cobra por Tebex

### 8.1 Ningún plan del sitio está vinculado a Tebex

Consulta real a la base:

```
SELECT s.name, p.name, p.priceCents, p.tebexPackageId
FROM plans p JOIN services s ON s.id = p.serviceId WHERE p.active = 1;
```

**Los 8 planes tienen `tebexPackageId = NULL`.** Como `wantsTebex` exige ese
campo, el sitio **nunca** llama a Tebex: todos los pedidos caen al flujo manual
("Importe a transferir por Tebex", sin cuenta de destino). Esa es la razón
principal de que la plata no llegue a Tebex.

### 8.2 Precios: la web y Tebex NO coinciden

| Plan en la web | Precio web | Paquete Tebex | Precio Tebex |
| --- | --- | --- | --- |
| Bot Básico | 5,00 | Bot Básico (7700329) | 8,00 |
| Bot Intermedio | 20,00 | Bot Avanzado (7700426) | 16,00 |
| Bot Avanzado | 35,00 | Bot Pro (7700432) | 28,00 |
| Hosting Bot Dedicado | 4,99 / mes | Hosting (7700744) | 5,00 / mes |
| Web Basic | 29,99 | Web Basic (7700788) | 30,00 |
| Web Advanced | 59,99 | Web Advanced (7702701) | 60,00 |
| Web Pro | 79,99 | Web Pro (7702717) | 80,00 |
| Web Ultimate | 119,99 | Web Ultimate (7702719) | 155,00 |

Los nombres de bots no son 1:1 (la web tiene "Intermedio", Tebex tiene "Pro").
Al vincular, el cliente paga el precio de **Tebex**, no el de la web.

### 8.3 La cuenta tiene la tienda alojada desactivada

`GET /accounts/{token}` devuelve `disabled: true` y `logo: null`. La web pública
`https://imperio-shop.tebex.store` no renderiza contenido.

Esto es coherente con usar la Headless API (la documentación recomienda apagar
la tienda alojada cuando se maneja un frontend propio con
*Settings → Project → Enable Webstore Management Features*). Conviene
confirmarlo en el panel, porque si la tienda está deshabilitada por falta de
verificación, el cobro real también queda bloqueado.

### 8.4 Resumen de bloqueos para cobrar

1. Ningún plan vinculado a un paquete de Tebex → el sitio no intenta cobrar.
2. Tienda en FiveM → `422 User must login before adding packages to basket`.
3. Tipo de tienda no cambiable (ver sección 6) → requiere proyecto nuevo Universal.
4. Confirmar que la tienda no esté deshabilitada por verificación pendiente.

### 8.5 Correcciones hechas en esta ronda

- `orders.create` ahora devuelve `tebexFailed` cuando Tebex falla.
- El diálogo de compra ya no muestra un "pago manual" falso: avisa que hay que
  pedir el enlace por Discord y muestra el código del pedido.
- Aviso de ticket configurable (`orders.ticketMessage`, con `{code}`) visible al
  terminar la compra y en cada pedido de "Mis compras".
- Campo del aviso agregado al panel (Operación) y texto de "Cómo funciona el
  pago" actualizado a Tebex.
