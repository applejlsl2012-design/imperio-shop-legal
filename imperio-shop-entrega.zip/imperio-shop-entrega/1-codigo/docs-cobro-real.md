# Cobro con tarjeta en Imperio Shop: cómo funciona y qué falta

## Resumen

El cobro **no ocurre en la web, ocurre en Tebex**. La web nunca ve ni guarda el
número de tarjeta: solo crea el pedido y envía al cliente a la pantalla segura
de Tebex, que es la que tiene permiso para cobrar.

```
Cliente elige un plan
        ↓
La web crea el pedido (estado: "Pendiente de pago")
        ↓
Elige método (Tarjetas, Google Pay, PayPal, Afterpay…)
        ↓
Se abre la pantalla segura de Tebex (pay.tebex.io)
   → ahí escribe número de tarjeta, fecha y código de seguridad
        ↓
Tebex cobra y vuelve a la web
        ↓
La web le pregunta a Tebex si la canasta quedó completa
        ↓
   ¿Completa?  → "Pago exitoso" + instrucción de abrir ticket
   ¿Sin pagar? → sigue "Esperá un poco mientras verificamos tu pago"
```

## Dónde escribe el cliente los datos de su tarjeta

En `pay.tebex.io`, dentro del checkout. Los campos son:

| Campo | Qué pide |
| --- | --- |
| Email Address | Correo del comprador |
| VISA / Google Pay / PayPal / More Payment Methods | Método de pago |
| Full Name | Nombre completo del titular |
| Zip / Postal Code | Código postal |
| Número de tarjeta | Se carga en el formulario seguro de Tebex/Stripe |
| Fecha de vencimiento | MM / AA |
| CVC / código de seguridad | Los 3 o 4 dígitos del dorso |

Esa pantalla la sirve Tebex sobre Stripe, así que el número de tarjeta viaja
cifrado directamente a la pasarela. **Es la única forma correcta de manejarlo**:
si la web pidiera el número de tarjeta, quedaría dentro del alcance de PCI-DSS.

## Estado actual de la tienda

- Tipo de proyecto: **Universal (No Auth)** — el correcto para vender bots,
  hosting y webs.
- Los **8 planes** están vinculados a sus 8 paquetes de Tebex.
- El pago se procesa en **modo de prueba**: Tebex todavía no aprobó la tienda,
  así que muestra su pantalla de simulación y no descuenta dinero real.
- El circuito completo ya funciona: pedido → cobro → vuelta a la web →
  verificación → **Pago exitoso**.

### Cómo lo detecta el sistema

`getTebexStatus()` marca `testMode` cuando la cuenta figura como
`disabled` y no es una tienda FiveM. El sitio sigue funcionando y avisa la
realidad en cada lugar: en el catálogo, en la ficha de compra y en el panel.

**No hay que cambiar nada en el sitio cuando Tebex apruebe la tienda**: el
mismo código pasa a cobrar de verdad automáticamente.

## Qué falta para que descuente dinero real

1. **Que Tebex apruebe la tienda.** Se pide desde el panel de Tebex
   (Creator → el proyecto Universal → verificación/activación). Tebex pide
   datos del negocio y una cuenta de cobro. Es el paso que quita el aviso
   naranja "TEST PAYMENTS ACTIVE" y habilita el cobro real.
2. **Publicar la web con su dominio propio.** Al publicar, la web queda con su
   URL real; opcionalmente se define `PUBLIC_BASE_URL`
   (por ejemplo `https://imperioshop.com`) para que Tebex devuelva al cliente
   siempre al dominio correcto.
3. **Cargar el webhook en Tebex** apuntando a
   `<dominio>/api/tebex/webhook`, con los eventos `payment.completed`,
   `payment.declined` y `payment.refunded`, y el secreto ya guardado. El
   webhook es la vía más rápida de confirmación; la verificación contra la
   canasta funciona igual si el webhook se demora.

## Prueba hecha hoy

Se recorrió el circuito completo con un pedido real de **Bot Básico (US$ 8)**:

| Comprobación | Resultado |
| --- | --- |
| Se crea el pedido en la web | Sí, con su código IMP-XXXXXX |
| Se abre el checkout de Tebex | Sí, con los métodos activos |
| La pantalla pide los datos de tarjeta | Sí (nombre, código postal y tarjeta) |
| La web marca el pedido como pagado | Sí, solo con la canasta confirmada |
| Se guarda la transacción de Tebex | Sí (`tbx-…`) y el método usado |
| Se guarda la fecha del cobro | Sí, `paidAt` |
| Un pago incompleto NO se marca pagado | Correcto: queda "Pendiente de pago" |

Importe real: **US$ 8.00**, sin descuento de dinero porque la tienda está en
modo de prueba.