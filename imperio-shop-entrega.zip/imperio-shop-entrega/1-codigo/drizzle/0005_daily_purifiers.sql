CREATE TABLE `activity_log` (
	`id` int AUTO_INCREMENT NOT NULL,
	`kind` varchar(60) NOT NULL,
	`title` varchar(200) NOT NULL,
	`detail` text NOT NULL,
	`actor` varchar(160) NOT NULL DEFAULT 'visitante',
	`actorEmail` varchar(320) NOT NULL DEFAULT '',
	`customerId` int,
	`orderId` int,
	`meta` text NOT NULL,
	`ip` varchar(64) NOT NULL DEFAULT '',
	`userAgent` varchar(300) NOT NULL DEFAULT '',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `activity_log_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `activity_log_kind_idx` ON `activity_log` (`kind`);--> statement-breakpoint
CREATE INDEX `activity_log_created_idx` ON `activity_log` (`createdAt`);--> statement-breakpoint
CREATE INDEX `activity_log_customer_idx` ON `activity_log` (`customerId`);