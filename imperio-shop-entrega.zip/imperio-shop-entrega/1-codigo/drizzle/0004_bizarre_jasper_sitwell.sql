CREATE TABLE `verification_codes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`email` varchar(320) NOT NULL,
	`codeHash` varchar(128) NOT NULL,
	`purpose` enum('signup','invite') NOT NULL DEFAULT 'signup',
	`pendingName` varchar(160) NOT NULL DEFAULT '',
	`pendingDiscord` varchar(120) NOT NULL DEFAULT '',
	`pendingPasswordHash` varchar(255) NOT NULL DEFAULT '',
	`invitedBy` varchar(120) NOT NULL DEFAULT '',
	`attempts` int NOT NULL DEFAULT 0,
	`consumedAt` timestamp,
	`expiresAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `verification_codes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `verification_codes_email_idx` ON `verification_codes` (`email`);--> statement-breakpoint
CREATE INDEX `verification_codes_created_idx` ON `verification_codes` (`createdAt`);