import {
  boolean,
  index,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/* -------------------------------------------------------------------------- */
/*  Catálogo                                                                   */
/* -------------------------------------------------------------------------- */

/** Categorías de servicio (Bots de Discord, Hosting, Páginas Web, ...). */
export const services = mysqlTable(
  "services",
  {
    id: int("id").autoincrement().primaryKey(),
    slug: varchar("slug", { length: 80 }).notNull().unique(),
    name: varchar("name", { length: 120 }).notNull(),
    tagline: varchar("tagline", { length: 220 }).notNull().default(""),
    description: text("description").notNull(),
    imageUrl: text("imageUrl").notNull(),
    icon: varchar("icon", { length: 40 }).notNull().default("package"),
    badge: varchar("badge", { length: 40 }).notNull().default(""),
    accent: varchar("accent", { length: 20 }).notNull().default("#FF1F3D"),
    features: text("features").notNull(),
    deliveryTime: varchar("deliveryTime", { length: 60 }).notNull().default(""),
    sortOrder: int("sortOrder").notNull().default(0),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (t) => [index("services_active_idx").on(t.active)],
);

export type Service = typeof services.$inferSelect;
export type InsertService = typeof services.$inferInsert;

/** Planes con precio dentro de cada servicio. */
export const plans = mysqlTable(
  "plans",
  {
    id: int("id").autoincrement().primaryKey(),
    serviceId: int("serviceId").notNull(),
    name: varchar("name", { length: 120 }).notNull(),
    priceCents: int("priceCents").notNull(),
    currency: varchar("currency", { length: 8 }).notNull().default("USD"),
    /** "once" = pago único, "monthly" = suscripción mensual. */
    billing: mysqlEnum("billing", ["once", "monthly"]).notNull().default("once"),
    /**
     * ID del paquete en Tebex que corresponde a este plan.
     * Se carga desde el panel; si está vacío, el plan se cobra de forma manual.
     */
    tebexPackageId: int("tebexPackageId"),
    summary: varchar("summary", { length: 240 }).notNull().default(""),
    specs: text("specs").notNull(),
    features: text("features").notNull(),
    popular: boolean("popular").notNull().default(false),
    stockLabel: varchar("stockLabel", { length: 60 }).notNull().default(""),
    sortOrder: int("sortOrder").notNull().default(0),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (t) => [index("plans_service_idx").on(t.serviceId)],
);

export type Plan = typeof plans.$inferSelect;
export type InsertPlan = typeof plans.$inferInsert;

/* -------------------------------------------------------------------------- */
/*  Pedidos                                                                    */
/* -------------------------------------------------------------------------- */

export const orders = mysqlTable(
  "orders",
  {
    id: int("id").autoincrement().primaryKey(),
    /** Código público que el cliente usa para seguir su pedido, ej. IMP-4F2K9A. */
    code: varchar("code", { length: 24 }).notNull().unique(),
    serviceId: int("serviceId").notNull(),
    serviceName: varchar("serviceName", { length: 120 }).notNull(),
    planId: int("planId"),
    planName: varchar("planName", { length: 120 }).notNull(),
    amountCents: int("amountCents").notNull(),
    currency: varchar("currency", { length: 8 }).notNull().default("USD"),
    billing: mysqlEnum("billing", ["once", "monthly"]).notNull().default("once"),

    customerName: varchar("customerName", { length: 160 }).notNull(),
    customerEmail: varchar("customerEmail", { length: 320 }).notNull(),
    customerDiscord: varchar("customerDiscord", { length: 120 }).notNull().default(""),
    customerNote: text("customerNote").notNull(),

    paymentMethod: varchar("paymentMethod", { length: 40 }).notNull().default("tebex"),
    /** Cuenta desde la que pagó el cliente, cuando el cobro es manual. */
    payerAccount: varchar("payerAccount", { length: 160 }).notNull().default(""),
    paymentReference: varchar("paymentReference", { length: 200 }).notNull().default(""),
    /** Identificador de la canasta de Tebex asociada a este pedido. */
    tebexBasketIdent: varchar("tebexBasketIdent", { length: 80 }).notNull().default(""),
    /** ID de la transacción de Tebex (tbx-xxxx) que confirma el pago. */
    tebexTransactionId: varchar("tebexTransactionId", { length: 80 }).notNull().default(""),
    /** Método de pago que usó el cliente en Tebex (PayPal, tarjeta, etc.). */
    tebexPaymentMethod: varchar("tebexPaymentMethod", { length: 80 }).notNull().default(""),
    status: mysqlEnum("status", [
      "pending_payment",
      "payment_review",
      "paid",
      "in_progress",
      "delivered",
      "cancelled",
    ])
      .notNull()
      .default("pending_payment"),
    staffNote: text("staffNote").notNull(),
    /**
     * Instante exacto en que Tebex confirmó el cobro. Queda vacío mientras el
     * pedido no esté pagado: es la prueba de cuándo entró la plata.
     */
    paidAt: timestamp("paidAt"),
    userId: int("userId"),
    /** Cuenta de cliente del sitio que hizo la compra (registro con correo). */
    customerId: int("customerId"),

    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (t) => [
    index("orders_status_idx").on(t.status),
    index("orders_code_idx").on(t.code),
    index("orders_email_idx").on(t.customerEmail),
    index("orders_customer_idx").on(t.customerId),
  ],
);

export type Order = typeof orders.$inferSelect;
export type InsertOrder = typeof orders.$inferInsert;

/** Historial de cambios de estado, para auditoría en el panel. */
export const orderEvents = mysqlTable(
  "order_events",
  {
    id: int("id").autoincrement().primaryKey(),
    orderId: int("orderId").notNull(),
    fromStatus: varchar("fromStatus", { length: 40 }).notNull().default(""),
    toStatus: varchar("toStatus", { length: 40 }).notNull(),
    note: text("note").notNull(),
    actor: varchar("actor", { length: 120 }).notNull().default("sistema"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (t) => [index("order_events_order_idx").on(t.orderId)],
);

export type OrderEvent = typeof orderEvents.$inferSelect;

/* -------------------------------------------------------------------------- */
/*  Acceso privado del equipo                                                  */
/* -------------------------------------------------------------------------- */

/**
 * Códigos de acceso del panel privado. Solo el dueño y su socio deben poder
 * entrar: cada persona recibe su propio código, guardado hasheado.
 */
export const staffCodes = mysqlTable("staff_codes", {
  id: int("id").autoincrement().primaryKey(),
  label: varchar("label", { length: 120 }).notNull(),
  codeHash: varchar("codeHash", { length: 128 }).notNull(),
  codeHint: varchar("codeHint", { length: 24 }).notNull().default(""),
  role: mysqlEnum("role", ["owner", "staff"]).notNull().default("staff"),
  active: boolean("active").notNull().default(true),
  createdBy: varchar("createdBy", { length: 120 }).notNull().default("owner"),
  lastUsedAt: timestamp("lastUsedAt"),
  useCount: int("useCount").notNull().default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type StaffCode = typeof staffCodes.$inferSelect;

/** Bitácora de intentos de ingreso al panel. */
export const staffLogins = mysqlTable(
  "staff_logins",
  {
    id: int("id").autoincrement().primaryKey(),
    label: varchar("label", { length: 120 }).notNull().default(""),
    success: boolean("success").notNull().default(false),
    ip: varchar("ip", { length: 64 }).notNull().default(""),
    userAgent: varchar("userAgent", { length: 255 }).notNull().default(""),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (t) => [index("staff_logins_created_idx").on(t.createdAt)],
);

export type StaffLogin = typeof staffLogins.$inferSelect;

/* -------------------------------------------------------------------------- */
/*  Cuentas de clientes                                                        */
/* -------------------------------------------------------------------------- */

/**
 * Cuentas de clientes del sitio. Se crean al registrarse con correo y
 * contraseña, y cada compra queda vinculada a la cuenta que la hizo, así el
 * panel de administración sabe siempre quién compró qué.
 */
export const customers = mysqlTable(
  "customers",
  {
    id: int("id").autoincrement().primaryKey(),
    email: varchar("email", { length: 320 }).notNull().unique(),
    name: varchar("name", { length: 160 }).notNull(),
    /** Vacío cuando la cuenta se creó con Google o Apple. */
    passwordHash: varchar("passwordHash", { length: 255 }).notNull().default(""),
    /** "email", "google" o "apple", según cómo entró la última vez. */
    provider: varchar("provider", { length: 40 }).notNull().default("email"),
    /**
     * Identificador de Manus que devuelve el ingreso con Google o Apple.
     * Permite reconocer a la misma persona en su próxima sesión.
     */
    manusOpenId: varchar("manusOpenId", { length: 64 }),
    discord: varchar("discord", { length: 120 }).notNull().default(""),
    active: boolean("active").notNull().default(true),
    lastSignedIn: timestamp("lastSignedIn"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (t) => [
    index("customers_email_idx").on(t.email),
    index("customers_openid_idx").on(t.manusOpenId),
  ],
);

export type Customer = typeof customers.$inferSelect;

/* -------------------------------------------------------------------------- */
/*  Configuración del sitio                                                    */
/* -------------------------------------------------------------------------- */

/** Configuración editable desde el panel (contacto, pagos, textos). */
export const settings = mysqlTable("settings", {
  key: varchar("key", { length: 80 }).primaryKey(),
  value: text("value").notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Setting = typeof settings.$inferSelect;

/* -------------------------------------------------------------------------- */
/*  Contenido de confianza                                                     */
/* -------------------------------------------------------------------------- */

export const testimonials = mysqlTable("testimonials", {
  id: int("id").autoincrement().primaryKey(),
  author: varchar("author", { length: 120 }).notNull(),
  role: varchar("role", { length: 120 }).notNull().default(""),
  quote: text("quote").notNull(),
  rating: int("rating").notNull().default(5),
  sortOrder: int("sortOrder").notNull().default(0),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type Testimonial = typeof testimonials.$inferSelect;

/**
 * Reseñas que dejan los clientes registrados.
 *
 * Quedan visibles en el sitio público solo cuando el equipo las aprueba desde
 * el panel, así evitamos publicar spam o comentarios ofensivos.
 * Estados: `pending` (esperando revisión), `approved` (publicada) y
 * `rejected` (descartada).
 */
export const reviews = mysqlTable(
  "reviews",
  {
    id: int("id").autoincrement().primaryKey(),
    customerId: int("customerId").notNull(),
    /** Copia del nombre para no perderlo si el cliente cambia de cuenta. */
    authorName: varchar("authorName", { length: 160 }).notNull(),
    /** Correo de contacto del autor, para avisarle si su reseña se publicó. */
    authorEmail: varchar("authorEmail", { length: 320 }).notNull().default(""),
    /** Servicio reseñado, si la reseña es sobre una compra concreta. */
    serviceId: int("serviceId"),
    serviceName: varchar("serviceName", { length: 160 }).notNull().default(""),
    /** Pedido que respalda la reseña (opcional). */
    orderId: int("orderId"),
    rating: int("rating").notNull(),
    comment: text("comment").notNull(),
    status: mysqlEnum("status", ["pending", "approved", "rejected"])
      .notNull()
      .default("pending"),
    /** Nota interna del equipo, no se muestra en el sitio. */
    staffNote: text("staffNote").notNull(),
    /** Si la reseña aparece en la sección destacada del inicio. */
    featured: boolean("featured").notNull().default(false),
    /** Respuesta pública del equipo, opcional. */
    reply: text("reply").notNull(),
    publishedAt: timestamp("publishedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (t) => [
    index("reviews_status_idx").on(t.status),
    index("reviews_customer_idx").on(t.customerId),
    index("reviews_service_idx").on(t.serviceId),
  ],
);
export type Review = typeof reviews.$inferSelect;
export type InsertReview = typeof reviews.$inferInsert;

export const faqs = mysqlTable("faqs", {
  id: int("id").autoincrement().primaryKey(),
  question: varchar("question", { length: 240 }).notNull(),
  answer: text("answer").notNull(),
  sortOrder: int("sortOrder").notNull().default(0),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Faq = typeof faqs.$inferSelect;

/**
 * Códigos de verificación por correo.
 *
 * Antes de crear una cuenta confirmamos que la persona es dueña del correo:
 * le enviamos un código de 6 dígitos y guardamos su hash (nunca el código en
 * claro) junto con los datos del registro pendiente.
 */
export const verificationCodes = mysqlTable(
  "verification_codes",
  {
    id: int("id").autoincrement().primaryKey(),
    email: varchar("email", { length: 320 }).notNull(),
    codeHash: varchar("codeHash", { length: 128 }).notNull(),
    /** "signup" (se registra), "invite" (lo invita el equipo) o "reset" (recupera su contraseña). */
    purpose: mysqlEnum("purpose", ["signup", "invite", "reset"])
      .notNull()
      .default("signup"),
    /** Datos que se aplican cuando el código se confirma. */
    pendingName: varchar("pendingName", { length: 160 }).notNull().default(""),
    pendingDiscord: varchar("pendingDiscord", { length: 120 })
      .notNull()
      .default(""),
    pendingPasswordHash: varchar("pendingPasswordHash", { length: 255 })
      .notNull()
      .default(""),
    /** Quién generó la invitación (vacío cuando se registró la persona). */
    invitedBy: varchar("invitedBy", { length: 120 }).notNull().default(""),
    attempts: int("attempts").notNull().default(0),
    consumedAt: timestamp("consumedAt"),
    expiresAt: timestamp("expiresAt").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (t) => [
    index("verification_codes_email_idx").on(t.email),
    index("verification_codes_created_idx").on(t.createdAt),
  ],
);
export type VerificationCode = typeof verificationCodes.$inferSelect;

/**
 * Bitácora de todo lo que pasa en la web pública.
 *
 * El equipo ve en el panel cada movimiento: cuentas creadas, compras, reseñas,
 * consultas de precios y visitas. Guardamos datos técnicos (IP y navegador) de
 * forma acotada para poder dar soporte, no para seguimiento publicitario.
 */
export const activityLog = mysqlTable(
  "activity_log",
  {
    id: int("id").autoincrement().primaryKey(),
    /** Tipo de movimiento, por ejemplo "cuenta.creada" o "pedido.nuevo". */
    kind: varchar("kind", { length: 60 }).notNull(),
    /** Texto corto que ve el equipo en la lista. */
    title: varchar("title", { length: 200 }).notNull(),
    /** Detalle opcional (servicio comprado, plan, correo, etc.). */
    detail: text("detail").notNull(),
    /** Quién lo hizo: nombre de la cuenta, del equipo o "visitante". */
    actor: varchar("actor", { length: 160 }).notNull().default("visitante"),
    actorEmail: varchar("actorEmail", { length: 320 }).notNull().default(""),
    /** Enlace a la persona, el pedido o la reseña involucrada. */
    customerId: int("customerId"),
    orderId: int("orderId"),
    /** Ficha interna del movimiento (ruta visitada, importe, etc.). */
    meta: text("meta").notNull(),
    ip: varchar("ip", { length: 64 }).notNull().default(""),
    userAgent: varchar("userAgent", { length: 300 }).notNull().default(""),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (t) => [
    index("activity_log_kind_idx").on(t.kind),
    index("activity_log_created_idx").on(t.createdAt),
    index("activity_log_customer_idx").on(t.customerId),
  ],
);
export type ActivityLog = typeof activityLog.$inferSelect;
