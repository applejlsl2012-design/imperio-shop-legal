CREATE TABLE `faqs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`question` varchar(240) NOT NULL,
	`answer` text NOT NULL,
	`sortOrder` int NOT NULL DEFAULT 0,
	`active` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `faqs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `order_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orderId` int NOT NULL,
	`fromStatus` varchar(40) NOT NULL DEFAULT '',
	`toStatus` varchar(40) NOT NULL,
	`note` text NOT NULL,
	`actor` varchar(120) NOT NULL DEFAULT 'sistema',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `order_events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(24) NOT NULL,
	`serviceId` int NOT NULL,
	`serviceName` varchar(120) NOT NULL,
	`planId` int,
	`planName` varchar(120) NOT NULL,
	`amountCents` int NOT NULL,
	`currency` varchar(8) NOT NULL DEFAULT 'USD',
	`billing` enum('once','monthly') NOT NULL DEFAULT 'once',
	`customerName` varchar(160) NOT NULL,
	`customerEmail` varchar(320) NOT NULL,
	`customerDiscord` varchar(120) NOT NULL DEFAULT '',
	`customerNote` text NOT NULL,
	`paymentMethod` varchar(40) NOT NULL DEFAULT 'plex',
	`payerAccount` varchar(160) NOT NULL DEFAULT '',
	`paymentReference` varchar(200) NOT NULL DEFAULT '',
	`status` enum('pending_payment','payment_review','paid','in_progress','delivered','cancelled') NOT NULL DEFAULT 'pending_payment',
	`staffNote` text NOT NULL,
	`userId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `orders_id` PRIMARY KEY(`id`),
	CONSTRAINT `orders_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `plans` (
	`id` int AUTO_INCREMENT NOT NULL,
	`serviceId` int NOT NULL,
	`name` varchar(120) NOT NULL,
	`priceCents` int NOT NULL,
	`currency` varchar(8) NOT NULL DEFAULT 'USD',
	`billing` enum('once','monthly') NOT NULL DEFAULT 'once',
	`summary` varchar(240) NOT NULL DEFAULT '',
	`specs` text NOT NULL,
	`features` text NOT NULL,
	`popular` boolean NOT NULL DEFAULT false,
	`stockLabel` varchar(60) NOT NULL DEFAULT '',
	`sortOrder` int NOT NULL DEFAULT 0,
	`active` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `plans_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `services` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(80) NOT NULL,
	`name` varchar(120) NOT NULL,
	`tagline` varchar(220) NOT NULL DEFAULT '',
	`description` text NOT NULL,
	`imageUrl` text NOT NULL DEFAULT (''),
	`icon` varchar(40) NOT NULL DEFAULT 'package',
	`badge` varchar(40) NOT NULL DEFAULT '',
	`accent` varchar(20) NOT NULL DEFAULT '#FF1F3D',
	`features` text NOT NULL,
	`deliveryTime` varchar(60) NOT NULL DEFAULT '',
	`sortOrder` int NOT NULL DEFAULT 0,
	`active` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `services_id` PRIMARY KEY(`id`),
	CONSTRAINT `services_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `settings` (
	`key` varchar(80) NOT NULL,
	`value` text NOT NULL,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `settings_key` PRIMARY KEY(`key`)
);
--> statement-breakpoint
CREATE TABLE `staff_codes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`label` varchar(120) NOT NULL,
	`codeHash` varchar(128) NOT NULL,
	`codeHint` varchar(24) NOT NULL DEFAULT '',
	`role` enum('owner','staff') NOT NULL DEFAULT 'staff',
	`active` boolean NOT NULL DEFAULT true,
	`createdBy` varchar(120) NOT NULL DEFAULT 'owner',
	`lastUsedAt` timestamp,
	`useCount` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `staff_codes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `staff_logins` (
	`id` int AUTO_INCREMENT NOT NULL,
	`label` varchar(120) NOT NULL DEFAULT '',
	`success` boolean NOT NULL DEFAULT false,
	`ip` varchar(64) NOT NULL DEFAULT '',
	`userAgent` varchar(255) NOT NULL DEFAULT '',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `staff_logins_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `testimonials` (
	`id` int AUTO_INCREMENT NOT NULL,
	`author` varchar(120) NOT NULL,
	`role` varchar(120) NOT NULL DEFAULT '',
	`quote` text NOT NULL,
	`rating` int NOT NULL DEFAULT 5,
	`sortOrder` int NOT NULL DEFAULT 0,
	`active` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `testimonials_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);
--> statement-breakpoint
CREATE INDEX `order_events_order_idx` ON `order_events` (`orderId`);--> statement-breakpoint
CREATE INDEX `orders_status_idx` ON `orders` (`status`);--> statement-breakpoint
CREATE INDEX `orders_code_idx` ON `orders` (`code`);--> statement-breakpoint
CREATE INDEX `orders_email_idx` ON `orders` (`customerEmail`);--> statement-breakpoint
CREATE INDEX `plans_service_idx` ON `plans` (`serviceId`);--> statement-breakpoint
CREATE INDEX `services_active_idx` ON `services` (`active`);--> statement-breakpoint
CREATE INDEX `staff_logins_created_idx` ON `staff_logins` (`createdAt`);