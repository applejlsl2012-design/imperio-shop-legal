ALTER TABLE `orders` MODIFY COLUMN `paymentMethod` varchar(40) NOT NULL DEFAULT 'tebex';--> statement-breakpoint
ALTER TABLE `orders` ADD `tebexBasketIdent` varchar(80) DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `tebexTransactionId` varchar(80) DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `tebexPaymentMethod` varchar(80) DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `plans` ADD `tebexPackageId` int;