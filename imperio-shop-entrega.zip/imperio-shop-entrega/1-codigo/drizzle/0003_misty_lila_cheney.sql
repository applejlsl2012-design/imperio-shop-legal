CREATE TABLE `reviews` (
	`id` int AUTO_INCREMENT NOT NULL,
	`customerId` int NOT NULL,
	`authorName` varchar(160) NOT NULL,
	`authorEmail` varchar(320) NOT NULL DEFAULT '',
	`serviceId` int,
	`serviceName` varchar(160) NOT NULL DEFAULT '',
	`orderId` int,
	`rating` int NOT NULL,
	`comment` text NOT NULL,
	`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`staffNote` text NOT NULL,
	`featured` boolean NOT NULL DEFAULT false,
	`reply` text NOT NULL,
	`publishedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `reviews_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `reviews_status_idx` ON `reviews` (`status`);--> statement-breakpoint
CREATE INDEX `reviews_customer_idx` ON `reviews` (`customerId`);--> statement-breakpoint
CREATE INDEX `reviews_service_idx` ON `reviews` (`serviceId`);