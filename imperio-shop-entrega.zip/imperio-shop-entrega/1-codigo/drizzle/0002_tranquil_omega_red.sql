ALTER TABLE `customers` MODIFY COLUMN `passwordHash` varchar(255) NOT NULL DEFAULT '';--> statement-breakpoint
ALTER TABLE `customers` ADD `manusOpenId` varchar(64);--> statement-breakpoint
CREATE INDEX `customers_openid_idx` ON `customers` (`manusOpenId`);