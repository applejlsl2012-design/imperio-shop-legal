CREATE TABLE `customers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`email` varchar(320) NOT NULL,
	`name` varchar(160) NOT NULL,
	`passwordHash` varchar(255) NOT NULL,
	`provider` varchar(40) NOT NULL DEFAULT 'email',
	`discord` varchar(120) NOT NULL DEFAULT '',
	`active` boolean NOT NULL DEFAULT true,
	`lastSignedIn` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `customers_id` PRIMARY KEY(`id`),
	CONSTRAINT `customers_email_unique` UNIQUE(`email`)
);
--> statement-breakpoint
ALTER TABLE `services` MODIFY COLUMN `imageUrl` text NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `customerId` int;--> statement-breakpoint
CREATE INDEX `customers_email_idx` ON `customers` (`email`);--> statement-breakpoint
CREATE INDEX `orders_customer_idx` ON `orders` (`customerId`);