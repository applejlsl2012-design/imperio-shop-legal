import { ImperioMark } from "@/components/brand/ImperioLogo";
import { DiscordIcon } from "@/components/brand/DiscordIcon";
import { SectionHeading } from "@/components/site/SectionHeading";
import { PaymentMethods } from "@/components/site/PaymentMethods";
import { SiteLayout } from "@/components/site/SiteLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { iconFor, formatPlanPrice, formatPrice } from "@/lib/format";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import {
  ArrowRight,
  BadgeCheck,
  Check,
  Clock,
  CreditCard,
  Headphones,
  MessageCircle,
  Quote,
  Rocket,
  ShieldCheck,
  Sparkles,
  Star,
  Zap,
} from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  const { data, isLoading } = trpc.catalog.list.useQuery(undefined, {
    staleTime: 60_000,
  });
  const extras = trpc.catalog.extras.useQuery(undefined, { staleTime: 60_000 });

  const services = data?.services ?? [];
  const settings = data?.settings ?? {};
  // Estado real de la tienda de pagos: define qué métodos podemos mostrar.
  const tebex = trpc.orders.tebexStatus.useQuery(undefined, { staleTime: 120_000 });
  // Vista previa del diseño: se activa con ?pago=preview en la dirección.
  const faqs = extras.data?.faqs ?? [];
  const testimonials = extras.data?.testimonials ?? [];
  const reviews = extras.data?.reviews ?? [];
  const discord = settings["contact.discord"] ?? "";
  const provider = settings["payment.provider"] ?? "Tebex";

  return (
    <SiteLayout>
      {/* ------------------------------- HERO ------------------------------- */}
      <section className="relative overflow-hidden">
        <div
          className="absolute inset-0 -z-10 bg-cover bg-center"
          style={{ backgroundImage: "url(/manus-storage/hero-bg_55705e89.jpg)" }}
          aria-hidden
        />
        <div
          className="absolute inset-0 -z-10 bg-[linear-gradient(100deg,oklch(0.11_0.01_18/0.96)_0%,oklch(0.11_0.01_18/0.86)_38%,oklch(0.13_0.03_18/0.55)_70%,transparent_100%)]"
          aria-hidden
        />
        <div className="absolute inset-0 -z-10 grid-noise opacity-40" aria-hidden />

        <div className="container grid items-center gap-14 py-20 lg:grid-cols-[1.15fr_0.85fr] lg:py-28">
          <div className="rise-in">
            <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-2 text-xs font-semibold uppercase tracking-[0.2em] text-primary">
              <Sparkles className="h-3.5 w-3.5" />
              Imperio Shop · {settings["brand.tagline"] ?? "Bots · Hosting · Servidores"}
            </div>

            <h1 className="mt-6 font-display text-[2.6rem] font-black leading-[0.98] sm:text-6xl lg:text-[4.2rem]">
              Tu proyecto digital,
              <br />
              <span className="text-gradient-ember">con nivel imperial.</span>
            </h1>

            <p className="mt-6 max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg">
              Desarrollamos <strong className="text-foreground">bots de Discord</strong> a
              medida, <strong className="text-foreground">hosting 24/7</strong>,{" "}
              <strong className="text-foreground">servidores de Discord</strong> y{" "}
              <strong className="text-foreground">páginas web profesionales</strong>. Elegís
              tu plan, pagás con {provider} y en pocas horas lo tenés funcionando.
            </p>

            <div className="mt-9 flex flex-wrap items-center gap-3">
              <a href="#servicios">
                <Button size="lg" className="glow-ring gap-2 font-semibold">
                  Ver servicios y precios
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </a>
              {discord && (
                <a href={discord} target="_blank" rel="noreferrer">
                  <Button
                    size="lg"
                    variant="outline"
                    className="gap-2 border-[#5865F2]/45 bg-[#5865F2]/15 font-semibold text-foreground hover:border-[#5865F2]/70 hover:bg-[#5865F2]/25"
                  >
                    <DiscordIcon className="h-4 w-4 text-[#8b95f7]" />
                    Unirse al Discord
                  </Button>
                </a>
              )}
              <a href="#como-comprar">
                <Button
                  size="lg"
                  variant="outline"
                  className="gap-2 border-white/15 bg-white/4 font-semibold hover:bg-white/8"
                >
                  <CreditCard className="h-4 w-4" />
                  Cómo comprar con {provider}
                </Button>
              </a>
            </div>

            <dl className="mt-12 grid max-w-lg grid-cols-3 gap-6 border-t border-white/8 pt-8">
              {[
                {
                  value: settings["stats.uptime"] || "99.9%",
                  label: settings["stats.uptimeLabel"] || "Uptime del hosting",
                },
                {
                  value: settings["stats.support"] || "24/7",
                  label: settings["stats.supportLabel"] || "Soporte por Discord",
                },
                {
                  // Número real de pedidos entregados, tomado del panel.
                  value: String(extras.data?.deliveredCount ?? 0),
                  label: settings["stats.deliveredLabel"] || "Proyectos entregados",
                },
              ].map((item) => (
                <div key={item.label}>
                  <dt className="font-display text-2xl font-extrabold text-foreground sm:text-3xl">
                    {item.value}
                  </dt>
                  <dd className="mt-1 text-xs leading-snug text-muted-foreground sm:text-sm">
                    {item.label}
                  </dd>
                </div>
              ))}
            </dl>
          </div>

          {/* Tarjeta flotante de confianza */}
          <div className="relative hidden lg:block">
            <div className="absolute -inset-6 -z-10 rounded-[2rem] bg-primary/12 blur-3xl pulse-glow" />
            <div className="surface float-slow rounded-3xl p-7">
              <div className="flex items-center gap-3">
                <ImperioMark size={44} glow />
                <div>
                  <p className="font-display text-sm font-bold">Imperio Shop</p>
                  <p className="text-xs text-muted-foreground">Panel de cliente</p>
                </div>
              </div>

              <div className="mt-6 space-y-3">
                {[
                  { icon: Zap, title: "Entrega express", text: "Bots en 24-72 h" },
                  { icon: ShieldCheck, title: "Anti-DDoS", text: "Incluido en todo el hosting" },
                  { icon: Headphones, title: "Soporte humano", text: "Respondemos en minutos" },
                  { icon: BadgeCheck, title: "Código incluido", text: "Sin licencias ocultas" },
                ].map((item) => (
                  <div
                    key={item.title}
                    className="flex items-center gap-3 rounded-2xl border border-white/8 bg-white/3 p-3.5"
                  >
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/12 text-primary">
                      <item.icon className="h-5 w-5" />
                    </span>
                    <span className="min-w-0">
                      <span className="block text-sm font-semibold">{item.title}</span>
                      <span className="block truncate text-xs text-muted-foreground">
                        {item.text}
                      </span>
                    </span>
                  </div>
                ))}
              </div>

              <a href="#servicios" className="mt-6 block">
                <Button className="w-full font-semibold">Elegir mi plan</Button>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* ------------------------------ SERVICIOS --------------------------- */}
      <section id="servicios" className="scroll-mt-24 py-20 lg:py-24">
        <div className="container">
          <SectionHeading
            eyebrow="Nuestros servicios"
            title={
              <>
                Todo lo que tu comunidad necesita,{" "}
                <span className="text-gradient-ember">en un solo lugar</span>
              </>
            }
            description="Cada servicio incluye entrega, puesta en marcha y soporte. Elegí el plan que se adapte a tu proyecto y nosotros nos ocupamos del resto."
          />

          {isLoading ? (
            <div className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {Array.from({ length: 6 }).map((_, index) => (
                <Skeleton key={index} className="h-80 rounded-3xl" />
              ))}
            </div>
          ) : (
            <div className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {services.map((service, index) => {
                const Icon = iconFor(service.icon);
                const fromPrice = service.plans.length
                  ? Math.min(...service.plans.map((p) => p.priceCents))
                  : 0;
                const fromBilling = service.plans.find(
                  (p) => p.priceCents === fromPrice,
                )?.billing;

                return (
                  <Link key={service.slug} href={`/servicio/${service.slug}`}>
                    <Card
                      className="surface surface-hover group h-full overflow-hidden rounded-3xl border-0 p-0"
                      style={{ animationDelay: `${index * 60}ms` }}
                    >
                      <div className="relative h-44 overflow-hidden">
                        {service.imageUrl ? (
                          <img
                            src={service.imageUrl}
                            alt={service.name}
                            loading="lazy"
                            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                          />
                        ) : (
                          <div className="flex h-full w-full items-center justify-center bg-primary/10">
                            <Icon className="h-12 w-12 text-primary" />
                          </div>
                        )}
                        <div className="absolute inset-0 bg-gradient-to-t from-[oklch(0.17_0.014_18)] via-transparent to-transparent" />
                        {service.badge && (
                          <Badge className="absolute left-4 top-4 border-0 bg-primary/90 text-primary-foreground">
                            {service.badge}
                          </Badge>
                        )}
                      </div>

                      <div className="p-6">
                        <div className="flex items-center gap-3">
                          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/12 text-primary">
                            <Icon className="h-5 w-5" />
                          </span>
                          <h3 className="font-display text-lg font-bold">{service.name}</h3>
                        </div>

                        <p className="mt-3 line-clamp-2 text-sm leading-relaxed text-muted-foreground">
                          {service.tagline}
                        </p>

                        <ul className="mt-4 space-y-2">
                          {service.features.slice(0, 3).map((feature) => (
                            <li
                              key={feature}
                              className="flex items-start gap-2 text-xs text-muted-foreground"
                            >
                              <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
                              <span className="line-clamp-1">{feature}</span>
                            </li>
                          ))}
                        </ul>

                        <div className="mt-6 flex items-end justify-between border-t border-white/8 pt-5">
                          <div>
                            <p className="text-[0.7rem] uppercase tracking-wider text-muted-foreground">
                              Desde
                            </p>
                            <p className="font-display text-xl font-extrabold">
                              {fromPrice ? formatPrice(fromPrice) : "A medida"}
                              {fromBilling === "monthly" && (
                                <span className="text-xs font-medium text-muted-foreground">
                                  {" "}
                                  / mes
                                </span>
                              )}
                            </p>
                          </div>
                          <span className="inline-flex items-center gap-1.5 text-sm font-semibold text-primary transition-transform group-hover:translate-x-1">
                            Ver planes
                            <ArrowRight className="h-4 w-4" />
                          </span>
                        </div>
                      </div>
                    </Card>
                  </Link>
                );
              })}
            </div>
          )}
        </div>
      </section>

      {/* ------------------------------- PRECIOS ---------------------------- */}
      <section
        id="precios"
        className="scroll-mt-24 border-y border-white/8 bg-[oklch(0.125_0.012_18)] py-20 lg:py-24"
      >
        <div className="container">
          <SectionHeading
            eyebrow="Precios claros"
            align="center"
            title={
              <>
                Planes y precios <span className="text-gradient-ember">sin sorpresas</span>
              </>
            }
            description={`Los precios están en dólares y se pagan de forma segura con ${provider}. Los planes mensuales incluyen hosting y monitoreo mientras estén activos.`}
          />

          <div className="mt-14 space-y-14">
            {services.map((service) => {
              const Icon = iconFor(service.icon);
              return (
                <div key={service.slug}>
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-primary/12 text-primary">
                        <Icon className="h-5 w-5" />
                      </span>
                      <div>
                        <h3 className="font-display text-xl font-bold">{service.name}</h3>
                        <p className="text-xs text-muted-foreground">{service.tagline}</p>
                      </div>
                    </div>
                    <Link href={`/servicio/${service.slug}`}>
                      <Button
                        variant="outline"
                        size="sm"
                        className="gap-2 border-white/15 bg-white/4"
                      >
                        Ver detalle
                        <ArrowRight className="h-3.5 w-3.5" />
                      </Button>
                    </Link>
                  </div>

                  <div className="mt-6 grid gap-5 md:grid-cols-3">
                    {service.plans.map((plan) => (
                      <Card
                        key={plan.id}
                        className={cn(
                          "surface surface-hover relative flex flex-col rounded-3xl border-0 p-6",
                          plan.popular && "glow-ring",
                        )}
                      >
                        {plan.popular && (
                          <Badge className="absolute -top-3 left-6 border-0 bg-primary text-primary-foreground">
                            Más elegido
                          </Badge>
                        )}
                        <h4 className="font-display text-base font-bold">{plan.name}</h4>
                        <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">
                          {plan.summary}
                        </p>
                        <p className="mt-5 font-display text-3xl font-extrabold">
                          {formatPrice(plan.priceCents, plan.currency)}
                          <span className="ml-1 text-sm font-medium text-muted-foreground">
                            {plan.billing === "monthly" ? "/ mes" : "pago único"}
                          </span>
                        </p>

                        <ul className="mt-5 flex-1 space-y-2.5">
                          {plan.specs.slice(0, 5).map((spec) => (
                            <li key={spec} className="flex items-start gap-2 text-sm">
                              <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                              <span className="text-muted-foreground">{spec}</span>
                            </li>
                          ))}
                        </ul>

                        <Link href={`/servicio/${service.slug}?plan=${plan.id}`} className="mt-6 block">
                          <Button
                            className={cn("w-full font-semibold", plan.popular && "glow-ring")}
                            variant={plan.popular ? "default" : "outline"}
                          >
                            Comprar {plan.name}
                          </Button>
                        </Link>
                      </Card>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ---------------------------- CÓMO COMPRAR -------------------------- */}
      <section id="como-comprar" className="scroll-mt-24 py-20 lg:py-24">
        <div className="container">
          <div className="grid gap-14 lg:grid-cols-[0.9fr_1.1fr]">
            <SectionHeading
              eyebrow="Cómo comprar"
              title={
                <>
                  Comprar es simple y{" "}
                  <span className="text-gradient-ember">el pago es seguro</span>
                </>
              }
              description={
                settings["payment.steps"] ??
                `Elegí tu plan, completá tus datos y realizá el pago por ${provider}. Verificamos la operación y arrancamos.`
              }
            />

            <div className="grid gap-4 sm:grid-cols-2">
              {[
                {
                  icon: Rocket,
                  step: "01",
                  title: "Elegí tu plan",
                  text: "Recorré el catálogo y seleccioná el servicio y el plan que mejor se ajuste.",
                },
                {
                  icon: CreditCard,
                  step: "02",
                  title: "Pagá de forma segura",
                  text: tebex.data?.canCharge
                    ? `Al confirmar tu pedido te llevamos a la pantalla de pago de ${provider}, con tarjeta, PayPal o el método que prefieras.`
                    : `Al confirmar tu pedido te damos tu código y abrís un ticket en Discord: te pasamos el enlace de pago al toque.`,
                },
                {
                  icon: BadgeCheck,
                  step: "03",
                  title: "Verificamos",
                  text: "Confirmamos el pago y tu pedido pasa automáticamente a producción.",
                },
                {
                  icon: Zap,
                  step: "04",
                  title: "Recibís tu servicio",
                  text: "Te entregamos todo funcionando y te acompañamos con el soporte.",
                },
              ].map((item, index) => (
                <Card
                  key={item.step}
                  className="surface surface-hover rise-in rounded-3xl border-0 p-6"
                  style={{ animationDelay: `${index * 70}ms` }}
                >
                  <div className="flex items-center justify-between">
                    <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-primary/12 text-primary">
                      <item.icon className="h-5 w-5" />
                    </span>
                    <span className="font-display text-2xl font-black text-white/8">
                      {item.step}
                    </span>
                  </div>
                  <h3 className="mt-4 font-display text-base font-bold">{item.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                    {item.text}
                  </p>
                </Card>
              ))}
            </div>
          </div>

          {/* Métodos de pago: los procesa Tebex con la cuenta de la tienda. */}
          <Card className="surface mt-10 rounded-3xl border-0 p-7">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-start gap-4">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-primary/12 text-primary">
                  <ShieldCheck className="h-6 w-6" />
                </span>
                <div>
                  <p className="font-display text-base font-bold">
                    Todos los métodos de pago, en un solo lugar
                  </p>
                  <p className="mt-1 max-w-xl text-sm text-muted-foreground">
                    {tebex.data?.canCharge
                      ? `Los pagos se procesan con ${provider}, la plataforma que usa la comunidad. Elegís el método que prefieras en una pantalla segura y tu pedido se confirma al instante.`
                      : `El cobro en línea todavía se está terminando de habilitar. Mientras tanto, creá tu pedido y abrí un ticket en Discord: te pasamos el enlace de pago y arrancamos con tu proyecto.`}
                  </p>
                </div>
              </div>
              <Badge variant="outline" className="border-primary/30 bg-primary/8 text-primary">
                {tebex.data?.canCharge ? "Pago protegido" : "Pedido registrado"}
              </Badge>
            </div>
            <div className="mt-6 flex flex-wrap gap-2">
              {/*
                Mostramos solo lo que la tienda realmente ofrece hoy: mientras
                el cobro no esté habilitado no anunciamos métodos que el
                cliente no va a encontrar al pagar.
              */}
              <PaymentMethods
                canCharge={Boolean(tebex.data?.canCharge)}
                activos={extras.data?.settings["payment.methods"]}
              />
            </div>
          </Card>

          <Card className="surface mt-10 flex flex-col items-start justify-between gap-6 rounded-3xl border-0 p-7 sm:flex-row sm:items-center">
            <div className="flex items-start gap-4">
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-primary/12 text-primary">
                <CreditCard className="h-6 w-6" />
              </span>
              <div>
                <p className="font-display text-base font-bold">
                    {tebex.data?.canCharge
                      ? `Pagos gestionados con ${provider}`
                      : "Cobro en línea en preparación"}
                  </p>
                <p className="mt-1 max-w-xl text-sm text-muted-foreground">
                  {tebex.data?.canCharge
                    ? settings["payment.instructions"] ||
                      "Al finalizar tu compra te llevamos a la pantalla de pago segura y confirmamos la operación automáticamente."
                    : "Al finalizar tu compra te damos tu código de pedido y coordinamos el pago por Discord para no hacerte perder tiempo."}
                </p>
              </div>
            </div>
          </Card>
        </div>
      </section>

      {/* --------------------------- TESTIMONIOS ---------------------------- */}
      {testimonials.length > 0 && (
        <section className="border-y border-white/8 bg-[oklch(0.125_0.012_18)] py-20 lg:py-24">
          <div className="container">
            <SectionHeading
              eyebrow="Clientes"
              align="center"
              title={
                <>
                  Lo que dicen quienes ya{" "}
                  <span className="text-gradient-ember">trabajan con nosotros</span>
                </>
              }
            />
            <div className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              {testimonials.map((item, index) => (
                <Card
                  key={item.id}
                  className="surface surface-hover rise-in flex h-full flex-col rounded-3xl border-0 p-6"
                  style={{ animationDelay: `${index * 60}ms` }}
                >
                  <Quote className="h-6 w-6 text-primary/60" />
                  <p className="mt-4 flex-1 text-sm leading-relaxed text-muted-foreground">
                    "{item.quote}"
                  </p>
                  <div className="mt-5 flex items-center gap-0.5">
                    {Array.from({ length: item.rating }).map((_, starIndex) => (
                      <Star
                        key={starIndex}
                        className="h-3.5 w-3.5 fill-primary text-primary"
                      />
                    ))}
                  </div>
                  <div className="mt-3 border-t border-white/8 pt-3">
                    <p className="text-sm font-semibold">{item.author}</p>
                    <p className="text-xs text-muted-foreground">{item.role}</p>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ------------------------- RESEÑAS VERIFICADAS ---------------------- */}
      {reviews.length > 0 && (
        <section className="py-20 lg:py-24">
          <div className="container">
            <SectionHeading
              eyebrow="Reseñas verificadas"
              align="center"
              title={
                <>
                  Opiniones reales de{" "}
                  <span className="text-gradient-ember">clientes con cuenta</span>
                </>
              }
              description="Solo publicamos reseñas de personas que compraron y crearon su cuenta en Imperio Shop."
            />
            <div className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {reviews.map((review, index) => (
                <Card
                  key={review.id}
                  className="surface surface-hover rise-in flex h-full flex-col rounded-3xl border-0 p-6"
                  style={{ animationDelay: `${index * 60}ms` }}
                >
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-0.5">
                      {Array.from({ length: 5 }).map((_, starIndex) => (
                        <Star
                          key={starIndex}
                          className={cn(
                            "h-4 w-4",
                            starIndex < review.rating
                              ? "fill-primary text-primary"
                              : "text-white/20",
                          )}
                        />
                      ))}
                    </div>
                    <Badge
                      variant="outline"
                      className="gap-1 border-emerald-500/30 bg-emerald-500/10 text-[0.65rem] text-emerald-300"
                    >
                      <BadgeCheck className="h-3 w-3" />
                      Verificada
                    </Badge>
                  </div>

                  <p className="mt-4 flex-1 text-sm leading-relaxed text-muted-foreground">
                    "{review.comment}"
                  </p>

                  {review.reply && (
                    <div className="mt-4 rounded-2xl border border-white/8 bg-white/4 p-3.5">
                      <p className="flex items-center gap-1.5 text-xs font-semibold text-primary">
                        <MessageCircle className="h-3 w-3" />
                        Respuesta de Imperio Shop
                      </p>
                      <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">
                        {review.reply}
                      </p>
                    </div>
                  )}

                  <div className="mt-5 flex items-center gap-3 border-t border-white/8 pt-4">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/12 text-xs font-bold text-primary">
                      {review.author.slice(0, 2).toUpperCase()}
                    </span>
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold">{review.author}</p>
                      <p className="truncate text-xs text-muted-foreground">
                        {review.serviceName || "Cliente de Imperio Shop"}
                      </p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
            <div className="mt-10 flex justify-center">
              <Button
                asChild
                variant="outline"
                className="gap-2 border-white/15 bg-white/4 font-semibold hover:bg-white/8"
              >
                <Link href="/resenas">
                  Ver todas las reseñas y dejar la mía
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
      )}

      {/* -------------------------------- FAQ ------------------------------- */}
      {faqs.length > 0 && (
        <section id="faq" className="scroll-mt-24 py-20 lg:py-24">
          <div className="container grid gap-12 lg:grid-cols-[0.8fr_1.2fr]">
            <SectionHeading
              eyebrow="Preguntas frecuentes"
              title={
                <>
                  Dudas <span className="text-gradient-ember">resueltas</span>
                </>
              }
              description="Si te queda alguna pregunta, escribinos por Discord y te respondemos al instante."
            />
            <div className="space-y-3">
              {faqs.map((faq) => (
                <details
                  key={faq.id}
                  className="surface group rounded-2xl border-white/8 px-5 py-4 transition-colors open:border-primary/30"
                >
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-medium">
                    <span>{faq.question}</span>
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-white/12 text-primary transition-transform group-open:rotate-45">
                      +
                    </span>
                  </summary>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                    {faq.answer}
                  </p>
                </details>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ------------------------------ CONTACTO ---------------------------- */}
      <section id="contacto" className="scroll-mt-24 pb-4">
        <div className="container">
          <div className="surface relative overflow-hidden rounded-[2rem] p-8 sm:p-12">
            <div
              className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-primary/20 blur-3xl pulse-glow"
              aria-hidden
            />
            <div className="relative grid items-center gap-8 lg:grid-cols-[1.3fr_0.7fr]">
              <div>
                <h2 className="font-display text-3xl font-extrabold leading-tight sm:text-4xl">
                  ¿Listo para empezar tu{" "}
                  <span className="text-gradient-ember">proyecto imperial</span>?
                </h2>
                <p className="mt-4 max-w-xl text-base text-muted-foreground">
                  Contanos qué necesitás y te armamos una propuesta a medida. Si ya sabés
                  qué querés, elegí tu plan y en minutos tenés tu pedido en marcha.
                </p>
                <div className="mt-8 flex flex-wrap gap-3">
                  <a href="#servicios">
                    <Button size="lg" className="glow-ring gap-2 font-semibold">
                      Comprar ahora
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </a>
                  {discord && (
                    <a href={discord} target="_blank" rel="noreferrer">
                      <Button
                        size="lg"
                        variant="outline"
                        className="gap-2 border-[#5865F2]/45 bg-[#5865F2]/15 font-semibold hover:border-[#5865F2]/70 hover:bg-[#5865F2]/25"
                      >
                        <DiscordIcon className="h-4 w-4 text-[#8b95f7]" />
                        Unirse al Discord
                      </Button>
                    </a>
                  )}
                </div>
              </div>
              <div className="grid gap-3">
                {[
                  { icon: Clock, text: "Respuesta en minutos" },
                  {
                    icon: ShieldCheck,
                    text: tebex.data?.canCharge
                      ? `Pago protegido con ${provider}`
                      : "Pedido registrado al instante",
                  },
                  { icon: Headphones, text: "Soporte post-venta incluido" },
                ].map((item) => (
                  <div
                    key={item.text}
                    className="flex items-center gap-3 rounded-2xl border border-white/8 bg-white/4 px-4 py-3.5"
                  >
                    <item.icon className="h-5 w-5 shrink-0 text-primary" />
                    <span className="text-sm font-medium">{item.text}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
