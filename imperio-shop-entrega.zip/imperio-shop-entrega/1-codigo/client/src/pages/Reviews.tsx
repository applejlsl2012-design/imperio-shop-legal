import { ImperioMark } from "@/components/brand/ImperioLogo";
import { SectionHeading } from "@/components/site/SectionHeading";
import { SiteLayout } from "@/components/site/SiteLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import {
  AlertCircle,
  BadgeCheck,
  CheckCircle2,
  Loader2,
  LogIn,
  MessageCircle,
  Send,
  Star,
} from "lucide-react";
import { useEffect, useState } from "react";
import { Link } from "wouter";
import { toast } from "sonner";

/** Estrellas seleccionables para puntuar el servicio. */
function RatingPicker({
  value,
  onChange,
}: {
  value: number;
  onChange: (rating: number) => void;
}) {
  const [hover, setHover] = useState(0);
  const shown = hover || value;
  return (
    <div className="flex items-center gap-1.5" onMouseLeave={() => setHover(0)}>
      {Array.from({ length: 5 }).map((_, index) => {
        const star = index + 1;
        return (
          <button
            key={star}
            type="button"
            aria-label={`${star} estrella${star > 1 ? "s" : ""}`}
            onMouseEnter={() => setHover(star)}
            onClick={() => onChange(star)}
            className="transition-transform duration-150 hover:scale-110 active:scale-95"
          >
            <Star
              className={cn(
                "h-7 w-7 transition-colors",
                star <= shown ? "fill-primary text-primary" : "text-white/20",
              )}
            />
          </button>
        );
      })}
    </div>
  );
}

function Stars({ rating }: { rating: number }) {
  return (
    <span className="flex items-center gap-0.5">
      {Array.from({ length: 5 }).map((_, index) => (
        <Star
          key={index}
          className={cn(
            "h-4 w-4",
            index < rating ? "fill-primary text-primary" : "text-white/20",
          )}
        />
      ))}
    </span>
  );
}

export default function Reviews() {
  const utils = trpc.useUtils();
  const extras = trpc.catalog.extras.useQuery(undefined, { staleTime: 60_000 });
  const session = trpc.customer.me.useQuery(undefined, {
    retry: false,
    refetchOnWindowFocus: false,
  });
  const reviewable = trpc.customer.reviewableOrders.useQuery(undefined, {
    enabled: Boolean(session.data?.authenticated),
    retry: false,
  });
  const myReviews = trpc.customer.reviews.useQuery(undefined, {
    enabled: Boolean(session.data?.authenticated),
    retry: false,
  });

  const [rating, setRating] = useState(5);
  const [orderId, setOrderId] = useState<string>("none");
  const [comment, setComment] = useState("");

  const reviews = extras.data?.reviews ?? [];
  const authenticated = Boolean(session.data?.authenticated);
  const orders = reviewable.data ?? [];
  const mine = myReviews.data ?? [];

  const average =
    reviews.length > 0
      ? reviews.reduce((total, item) => total + item.rating, 0) / reviews.length
      : 0;

  const createReview = trpc.customer.createReview.useMutation({
    onSuccess: async (data) => {
      setComment("");
      setRating(5);
      setOrderId("none");
      await Promise.all([
        utils.customer.reviewableOrders.invalidate(),
        utils.customer.reviews.invalidate(),
        utils.catalog.extras.invalidate(),
      ]);
      toast.success(data.message);
    },
    onError: (error) => toast.error("No pudimos enviar tu reseña", { description: error.message }),
  });

  // Si ya reseñó todo, mostramos el formulario igual para dejar una opinión general.
  useEffect(() => {
    if (orders.length === 0) setOrderId("none");
  }, [orders.length]);

  return (
    <SiteLayout>
      <section className="relative overflow-hidden border-b border-white/8 py-16 lg:py-20">
        <div
          className="absolute inset-0 -z-10 bg-cover bg-center opacity-25"
          style={{ backgroundImage: "url(/manus-storage/hero-bg_55705e89.jpg)" }}
          aria-hidden
        />
        <div
          className="absolute inset-0 -z-10 bg-[linear-gradient(180deg,oklch(0.11_0.01_18/0.75),oklch(0.11_0.01_18/0.96))]"
          aria-hidden
        />
        <div className="container">
          <SectionHeading
            eyebrow="Reseñas"
            title={
              <>
                Lo que dicen nuestros{" "}
                <span className="text-gradient-ember">clientes</span>
              </>
            }
            description="Todas las reseñas son de personas con cuenta en Imperio Shop. Las revisamos antes de publicarlas para que sean reales."
          />

          {reviews.length > 0 && (
            <div className="mt-8 flex flex-wrap items-center gap-6">
              <div className="flex items-center gap-3">
                <span className="font-display text-4xl font-black">
                  {average.toFixed(1)}
                </span>
                <div>
                  <Stars rating={Math.round(average)} />
                  <p className="mt-1 text-xs text-muted-foreground">
                    {reviews.length} reseña{reviews.length === 1 ? "" : "s"} publicada
                    {reviews.length === 1 ? "" : "s"}
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>

      <section className="py-16 lg:py-20">
        <div className="container grid gap-12 lg:grid-cols-[1.25fr_0.75fr]">
          {/* Listado */}
          <div>
            <h2 className="font-display text-2xl font-extrabold">
              Reseñas publicadas
            </h2>

            {extras.isLoading ? (
              <div className="mt-6 space-y-4">
                {Array.from({ length: 3 }).map((_, index) => (
                  <Skeleton key={index} className="h-40 rounded-3xl" />
                ))}
              </div>
            ) : reviews.length === 0 ? (
              <Card className="surface mt-6 rounded-3xl border-0 p-10 text-center">
                <ImperioMark size={44} glow />
                <p className="mt-4 font-display text-lg font-bold">
                  Todavía no hay reseñas publicadas
                </p>
                <p className="mt-2 text-sm text-muted-foreground">
                  Si ya compraste algo, entrá a tu cuenta y contanos cómo te fue.
                  Serías la primera reseña del sitio.
                </p>
              </Card>
            ) : (
              <div className="mt-6 space-y-4">
                {reviews.map((review) => (
                  <Card key={review.id} className="surface rounded-3xl border-0 p-6">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/12 text-sm font-bold text-primary">
                          {review.author.slice(0, 2).toUpperCase()}
                        </span>
                        <div>
                          <p className="text-sm font-semibold">{review.author}</p>
                          <p className="text-xs text-muted-foreground">
                            {review.serviceName || "Cliente de Imperio Shop"}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Stars rating={review.rating} />
                        <Badge
                          variant="outline"
                          className="gap-1 border-emerald-500/30 bg-emerald-500/10 text-[0.65rem] text-emerald-300"
                        >
                          <BadgeCheck className="h-3 w-3" />
                          Verificada
                        </Badge>
                      </div>
                    </div>

                    <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
                      "{review.comment}"
                    </p>

                    {review.reply && (
                      <div className="mt-4 rounded-2xl border border-white/8 bg-white/4 p-4">
                        <p className="flex items-center gap-1.5 text-xs font-semibold text-primary">
                          <MessageCircle className="h-3 w-3" />
                          Respuesta de Imperio Shop
                        </p>
                        <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                          {review.reply}
                        </p>
                      </div>
                    )}
                  </Card>
                ))}
              </div>
            )}
          </div>

          {/* Formulario / estado de sesión */}
          <div className="lg:sticky lg:top-24 lg:self-start">
            <Card className="surface rounded-3xl border-0 p-6">
              <h2 className="font-display text-xl font-extrabold">
                Dejá tu reseña
              </h2>

              {session.isLoading ? (
                <Skeleton className="mt-5 h-48 rounded-2xl" />
              ) : !authenticated ? (
                <>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                    Para reseñar necesitás tu cuenta: así confirmamos que compraste
                    con nosotros y tu opinión aparece como verificada.
                  </p>
                  <Button asChild className="mt-5 w-full gap-2 font-semibold">
                    <Link href="/cuenta">
                      <LogIn className="h-4 w-4" />
                      Iniciar sesión o crear cuenta
                    </Link>
                  </Button>
                </>
              ) : (
                <form
                  className="mt-5 space-y-5"
                  onSubmit={(event) => {
                    event.preventDefault();
                    createReview.mutate({
                      rating,
                      comment,
                      orderId: orderId === "none" ? undefined : Number(orderId),
                    });
                  }}
                >
                  <div className="space-y-2">
                    <Label>Tu puntuación</Label>
                    <RatingPicker value={rating} onChange={setRating} />
                  </div>

                  {orders.length > 0 && (
                    <div className="space-y-2">
                      <Label htmlFor="review-order">¿Sobre qué servicio?</Label>
                      <Select value={orderId} onValueChange={setOrderId}>
                        <SelectTrigger id="review-order" className="border-white/12 bg-white/4">
                          <SelectValue placeholder="Elegí un pedido" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">Opinión general</SelectItem>
                          {orders.map((order) => (
                            <SelectItem key={order.orderId} value={String(order.orderId)}>
                              {order.serviceName} · {order.code}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  <div className="space-y-2">
                    <Label htmlFor="review-comment">Tu experiencia</Label>
                    <Textarea
                      id="review-comment"
                      rows={5}
                      maxLength={1200}
                      value={comment}
                      onChange={(event) => setComment(event.target.value)}
                      placeholder="Contanos cómo fue la atención, la entrega y el resultado del servicio."
                      className="border-white/12 bg-white/4"
                    />
                    <p className="text-xs text-muted-foreground">
                      {comment.trim().length}/1200 · mínimo 10 caracteres
                    </p>
                  </div>

                  {createReview.error && (
                    <div className="flex items-start gap-2.5 rounded-2xl border border-destructive/30 bg-destructive/8 p-3.5">
                      <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
                      <p className="text-sm text-destructive">
                        {createReview.error.message}
                      </p>
                    </div>
                  )}

                  <Button
                    type="submit"
                    className="w-full gap-2 font-semibold"
                    disabled={createReview.isPending || comment.trim().length < 10}
                  >
                    {createReview.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Send className="h-4 w-4" />
                    )}
                    Enviar reseña
                  </Button>

                  <p className="text-xs leading-relaxed text-muted-foreground">
                    Revisamos cada reseña antes de publicarla. Te avisamos cuando esté
                    en el sitio.
                  </p>
                </form>
              )}
            </Card>

            {authenticated && mine.length > 0 && (
              <Card className="surface mt-4 rounded-3xl border-0 p-6">
                <h3 className="font-display text-base font-bold">Tus reseñas</h3>
                <div className="mt-4 space-y-4">
                  {mine.map((review) => (
                    <div
                      key={review.id}
                      className="rounded-2xl border border-white/8 bg-white/4 p-4"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <Stars rating={review.rating} />
                        <span
                          className={cn(
                            "rounded-full border px-2 py-0.5 text-[0.6rem] font-semibold uppercase tracking-wide",
                            review.status === "approved"
                              ? "border-emerald-500/30 bg-emerald-500/12 text-emerald-300"
                              : review.status === "rejected"
                                ? "border-white/15 bg-white/6 text-muted-foreground"
                                : "border-amber-500/30 bg-amber-500/12 text-amber-300",
                          )}
                        >
                          {review.status === "approved"
                            ? "Publicada"
                            : review.status === "rejected"
                              ? "No publicada"
                              : "En revisión"}
                        </span>
                      </div>
                      <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
                        {review.comment}
                      </p>
                      {review.reply && (
                        <p className="mt-2 flex items-start gap-1.5 text-xs text-primary">
                          <CheckCircle2 className="mt-0.5 h-3 w-3 shrink-0" />
                          {review.reply}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </Card>
            )}
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
