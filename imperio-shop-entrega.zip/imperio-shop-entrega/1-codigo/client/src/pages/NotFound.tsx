import { ImperioMark } from "@/components/brand/ImperioLogo";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { Link } from "wouter";

export default function NotFound() {
  return (
    <div className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden px-6 text-center">
      <div
        className="absolute inset-0 -z-10 bg-cover bg-center opacity-35"
        style={{ backgroundImage: "url(/manus-storage/hero-bg_55705e89.jpg)" }}
        aria-hidden
      />
      <div
        className="absolute inset-0 -z-10 bg-[linear-gradient(180deg,oklch(0.11_0.01_18/0.92),oklch(0.11_0.01_18/0.98))]"
        aria-hidden
      />
      <ImperioMark size={64} glow />
      <p className="mt-8 font-display text-7xl font-black text-gradient-ember">404</p>
      <h1 className="mt-4 font-display text-2xl font-bold sm:text-3xl">
        Esta página no existe
      </h1>
      <p className="mt-3 max-w-md text-sm text-muted-foreground">
        Puede que el enlace esté mal escrito o que el contenido haya cambiado de lugar.
        Volvé al inicio para ver todos nuestros servicios.
      </p>
      <Link href="/" className="mt-8">
        <Button className="glow-ring gap-2 font-semibold">
          <ArrowLeft className="h-4 w-4" />
          Volver al inicio
        </Button>
      </Link>
    </div>
  );
}
