import { ImperioMark } from "@/components/brand/ImperioLogo";
import { PaymentMethods } from "@/components/site/PaymentMethods";
import { TebexCheckoutButton } from "@/components/site/TebexCheckoutButton";
import { SiteLayout } from "@/components/site/SiteLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { formatPrice } from "@/lib/format";
import { iconFor } from "@/lib/format";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import {
  AlertCircle,
  ArrowLeft,
  ArrowRight,
  BadgeCheck,
  Check,
  Clock,
  Copy,
  CreditCard,
  Loader2,
  MessageCircle,
  ShieldCheck,
  Sparkles,
  Ticket,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Link, useLocation, useRoute } from "wouter";
import { toast } from "sonner";

type OrderResult = {
  code: string;
  amountCents: number;
  currency: string;
  billing: string;
  planName: string;
  serviceName: string;
  paymentSteps: string;
  paymentInstructions: string;
  paymentAccount: string;
  paymentQrUrl: string;
  contactDiscord: string;
  /** Enlace al checkout de Tebex. Si viene, el pago se completa ahí. */
  checkoutUrl: string;
  /** Identificador de la canasta: abre el pago dentro de la web. */
  basketIdent?: string;
  /** Enlace de acceso que exige la tienda antes de poder pagar. */
  authUrl?: string;
  /** Nombre del proveedor de acceso (por ejemplo FiveM). */
  authProvider?: string;
  /** Tebex está activo pero no pudo generar el cobro. */
  tebexFailed?: boolean;
  /** "tebex" cuando el cobro lo procesa Tebex; "manual" cuando es a mano. */
  paymentMethod: string;
};

/**
 * Da formato a la descripción del servicio: respeta los saltos de línea y
 * convierte las viñetas "•" en una lista prolija.
 */
function ServiceDescription({ text }: { text: string }) {
  const blocks = text.split("\n").map((line) => line.trim()).filter(Boolean);

  return (
    <>
      {blocks.map((line, index) => {
        if (line.startsWith("•")) {
          const item = line.replace(/^•\s*/, "");
          return (
            <p key={index} className="flex items-start gap-2.5 text-sm sm:text-base">
              <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
              <span>{item}</span>
            </p>
          );
        }
        return <p key={index}>{line}</p>;
      })}
    </>
  );
}

export default function ServiceDetail() {
  const [, params] = useRoute("/servicio/:slug");
  const [location, setLocation] = useLocation();
  const slug = params?.slug ?? "";

  const { data: service, isLoading } = trpc.catalog.service.useQuery(
    { slug },
    { enabled: Boolean(slug), retry: false },
  );

  const initialPlanId = useMemo(() => {
    const search = new URLSearchParams(
      typeof window === "undefined" ? "" : window.location.search,
    );
    const value = Number(search.get("plan"));
    return Number.isFinite(value) && value > 0 ? value : null;
  }, [location]);

  const extras = trpc.catalog.extras.useQuery(undefined, { staleTime: 60_000 });
  const provider = extras.data?.settings["payment.provider"] ?? "Tebex";
  const discordLink = extras.data?.settings["contact.discord"] ?? "";
  // Estado real de la tienda: si no puede cobrar, lo avisamos ANTES de que el
  // cliente intente pagar, en lugar de dejarlo fallar en el checkout.
  const tebex = trpc.orders.tebexStatus.useQuery(undefined, { staleTime: 120_000 });
  const pagoNoDisponible = tebex.data?.configured && !tebex.data.canCharge;
  // Con el cobro caído no mostramos pasos ni cuentas de pago: sería contradictorio.
  const cobroManual = !pagoNoDisponible;

  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [selectedPlanId, setSelectedPlanId] = useState<number | null>(null);
  const [result, setResult] = useState<OrderResult | null>(null);

  // ¿Quién está comprando? Con cuenta de cliente va a sus compras; si es el
  // equipo del panel probando, lo llevamos al panel a ver el pedido.
  const sesionCliente = trpc.customer.me.useQuery(undefined, {
    retry: false,
    refetchOnWindowFocus: false,
  });

  useEffect(() => {
    if (initialPlanId && service?.plans.some((p) => p.id === initialPlanId)) {
      setSelectedPlanId(initialPlanId);
      setCheckoutOpen(true);
    }
  }, [initialPlanId, service]);

  const selectedPlan = service?.plans.find((plan) => plan.id === selectedPlanId) ?? null;
  const Icon = iconFor(service?.icon ?? "package");

  if (isLoading) {
    return (
      <SiteLayout>
        <div className="container py-20">
          <Skeleton className="h-10 w-56 rounded-xl" />
          <Skeleton className="mt-6 h-72 w-full rounded-3xl" />
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {Array.from({ length: 3 }).map((_, index) => (
              <Skeleton key={index} className="h-96 rounded-3xl" />
            ))}
          </div>
        </div>
      </SiteLayout>
    );
  }

  if (!service) {
    return (
      <SiteLayout>
        <div className="container flex flex-col items-center py-28 text-center">
          <AlertCircle className="h-12 w-12 text-primary" />
          <h1 className="mt-6 font-display text-2xl font-bold">Servicio no encontrado</h1>
          <p className="mt-3 max-w-md text-sm text-muted-foreground">
            El servicio que buscás no existe o fue dado de baja. Volvé al catálogo para ver
            todas las opciones disponibles.
          </p>
          <Link href="/" className="mt-8">
            <Button className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Volver al inicio
            </Button>
          </Link>
        </div>
      </SiteLayout>
    );
  }

  return (
    <SiteLayout>
      {/* Encabezado */}
      <section className="relative overflow-hidden border-b border-white/8">
        <div
          className="absolute inset-0 -z-10 bg-cover bg-center opacity-45"
          style={{ backgroundImage: `url(${service.imageUrl || "/manus-storage/hero-bg_55705e89.jpg"})` }}
          aria-hidden
        />
        <div
          className="absolute inset-0 -z-10 bg-[linear-gradient(105deg,oklch(0.11_0.01_18/0.97)_0%,oklch(0.11_0.01_18/0.9)_45%,oklch(0.13_0.02_18/0.7)_100%)]"
          aria-hidden
        />

        <div className="container py-16 lg:py-20">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-primary"
          >
            <ArrowLeft className="h-4 w-4" />
            Volver al catálogo
          </Link>

          <div className="mt-8 grid gap-10 lg:grid-cols-[1.2fr_0.8fr] lg:items-center">
            <div>
              <div className="flex flex-wrap items-center gap-3">
                <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/12 text-primary">
                  <Icon className="h-6 w-6" />
                </span>
                {service.badge && (
                  <Badge className="border-0 bg-primary/90 text-primary-foreground">
                    {service.badge}
                  </Badge>
                )}
                {service.deliveryTime && (
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/4 px-3 py-1.5 text-xs text-muted-foreground">
                    <Clock className="h-3.5 w-3.5 text-primary" />
                    Entrega: {service.deliveryTime}
                  </span>
                )}
              </div>

              <h1 className="mt-6 font-display text-4xl font-black leading-tight sm:text-5xl">
                {service.name}
              </h1>
              <div className="mt-4 max-w-2xl space-y-3 text-base leading-relaxed text-muted-foreground sm:text-lg">
                <ServiceDescription text={service.description} />
              </div>

              {service.features.length > 0 && (
                <ul className="mt-8 grid gap-3 sm:grid-cols-2">
                  {service.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-2.5 text-sm">
                      <BadgeCheck className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                      <span className="text-muted-foreground">{feature}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <Card className="surface rounded-3xl border-0 p-6">
              <div className="flex items-center gap-3">
                <ImperioMark size={40} glow />
                <div>
                  <p className="text-xs uppercase tracking-wider text-muted-foreground">
                    Desde
                  </p>
                  <p className="font-display text-2xl font-extrabold">
                    {service.plans.length
                      ? formatPrice(Math.min(...service.plans.map((p) => p.priceCents)))
                      : "A medida"}
                  </p>
                </div>
              </div>
              <div className="mt-5 space-y-2.5 text-sm">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <ShieldCheck className="h-4 w-4 text-primary" />
                  Pago seguro gestionado por {provider}
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Clock className="h-4 w-4 text-primary" />
                  {service.deliveryTime || "Entrega rápida"}
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <MessageCircle className="h-4 w-4 text-primary" />
                  Soporte post-venta incluido
                </div>
              </div>
              <Button
                className="glow-ring mt-6 w-full gap-2 font-semibold"
                onClick={() => {
                  const target = document.getElementById("planes");
                  target?.scrollIntoView({ behavior: "smooth", block: "start" });
                }}
              >
                Ver planes disponibles
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Card>
          </div>
        </div>
      </section>

      {/* Planes */}
      <section id="planes" className="scroll-mt-24 py-16 lg:py-20">
        <div className="container">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/8 px-3.5 py-1.5 text-[0.7rem] font-semibold uppercase tracking-[0.22em] text-primary">
                <Sparkles className="h-3.5 w-3.5" />
                Planes de {service.name}
              </span>
              <h2 className="mt-4 font-display text-3xl font-extrabold sm:text-4xl">
                Elegí el plan que necesitás
              </h2>
            </div>
            <p className="max-w-md text-sm text-muted-foreground">
              {pagoNoDisponible
                ? "Cada plan queda registrado con un código de pedido para que puedas seguirlo."
                : `Todos los planes se pagan con ${provider} y quedan registrados con un código de pedido para que puedas seguirlos.`}
            </p>
          </div>

          {/* Aviso honesto: si la tienda todavía no puede cobrar, lo decimos acá. */}
          {pagoNoDisponible && (
            <div className="mt-6 flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-amber-500/30 bg-amber-500/8 p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-amber-300" />
                <p className="text-sm text-amber-100/90">{tebex.data?.message}</p>
              </div>
              {discordLink && (
                <a href={discordLink} target="_blank" rel="noreferrer">
                  <Button size="sm" variant="outline" className="rounded-full border-amber-400/40">
                    Abrir ticket
                  </Button>
                </a>
              )}
            </div>
          )}

          <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {service.plans.map((plan) => (
              <Card
                key={plan.id}
                className={cn(
                  "surface surface-hover relative flex flex-col rounded-3xl border-0 p-7",
                  plan.popular && "glow-ring",
                )}
              >
                {plan.popular && (
                  <Badge className="absolute -top-3 left-7 border-0 bg-primary text-primary-foreground">
                    Más elegido
                  </Badge>
                )}
                <div className="flex items-start justify-between gap-3">
                  <h3 className="font-display text-lg font-bold">{plan.name}</h3>
                  {plan.stockLabel && (
                    <span className="rounded-full border border-white/10 bg-white/4 px-2.5 py-1 text-[0.65rem] uppercase tracking-wider text-muted-foreground">
                      {plan.stockLabel}
                    </span>
                  )}
                </div>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {plan.summary}
                </p>

                <p className="mt-6 font-display text-4xl font-black">
                  {formatPrice(plan.priceCents, plan.currency)}
                  <span className="ml-1.5 text-sm font-medium text-muted-foreground">
                    {plan.billing === "monthly" ? "/ mes" : "pago único"}
                  </span>
                </p>

                <ul className="mt-6 flex-1 space-y-2.5">
                  {plan.specs.map((spec) => (
                    <li key={spec} className="flex items-start gap-2 text-sm">
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                      <span className="text-muted-foreground">{spec}</span>
                    </li>
                  ))}
                </ul>

                {plan.features.length > 0 && (
                  <div className="mt-5 flex flex-wrap gap-1.5 border-t border-white/8 pt-4">
                    {plan.features.map((feature) => (
                      <span
                        key={feature}
                        className="rounded-full border border-primary/25 bg-primary/8 px-2.5 py-1 text-[0.68rem] font-medium text-primary"
                      >
                        {feature}
                      </span>
                    ))}
                  </div>
                )}

                <Button
                  className={cn("mt-6 w-full gap-2 font-semibold", plan.popular && "glow-ring")}
                  variant={plan.popular ? "default" : "outline"}
                  onClick={() => {
                    setSelectedPlanId(plan.id);
                    setResult(null);
                    setCheckoutOpen(true);
                  }}
                >
                  <CreditCard className="h-4 w-4" />
                  Comprar {plan.name}
                </Button>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <CheckoutDialog
        open={checkoutOpen}
        onOpenChange={setCheckoutOpen}
        plan={selectedPlan}
        serviceName={service.name}
        slug={service.slug}
        provider={provider}
        result={result}
        setResult={setResult}
        cobroManual={cobroManual}
        canCharge={Boolean(tebex.data?.canCharge)}
        metodosActivos={extras.data?.settings["payment.methods"]}
        alVolver={() => {
          setCheckoutOpen(false);
          setLocation("/");
        }}
        alPagar={(codigo) =>
          setLocation(
            sesionCliente.data?.authenticated
              ? `/mis-compras?pago=ok&pedido=${codigo}`
              : `/panel/pedidos?pago=ok&pedido=${codigo}`,
          )
        }
        onDone={() => {
          setCheckoutOpen(false);
          if (result?.code)
            setLocation(sesionCliente.data?.authenticated ? "/mis-compras" : "/panel/pedidos");
        }}
        discordLink={discordLink}
        ticketTemplate={extras.data?.settings["orders.ticketMessage"] ?? ""}
      />
    </SiteLayout>
  );
}

/* -------------------------------------------------------------------------- */

function CheckoutDialog({
  open,
  onOpenChange,
  plan,
  serviceName,
  slug,
  provider,
  result,
  setResult,
  onDone,
  discordLink,
  ticketTemplate,
  cobroManual,
  canCharge,
  metodosActivos,
  alVolver,
  alPagar,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  plan: { id: number; name: string; priceCents: number; currency: string; billing: string } | null;
  serviceName: string;
  slug: string;
  provider: string;
  result: OrderResult | null;
  setResult: (value: OrderResult | null) => void;
  onDone: () => void;
  discordLink: string;
  ticketTemplate: string;
  /** ¿Se puede cobrar de forma normal? Si no, no mostramos pasos ni cuentas. */
  cobroManual: boolean;
  /** ¿La tienda de Tebex puede cobrar hoy? */
  canCharge: boolean;
  /** Métodos de pago visibles, según lo configurado en el panel. */
  metodosActivos?: string;
  /**
   * Vuelve al catálogo. Lo usa el cliente que abrió el formulario y cambió de
   * opinión: cierra el pedido sin crear nada.
   */
  alVolver: () => void;
  /** A dónde ir cuando Tebex avisa que el pago terminó. */
  alPagar: (codigo: string) => void;
}) {
  // Texto del aviso final, con el código del pedido ya reemplazado.
  const ticketMessage = (
    ticketTemplate ||
    "Abrí un ticket en nuestro Discord con tu código de pedido {code} y te atendemos al toque para crear tu bot, activar tu hosting o arrancar con tu página web."
  ).replace("{code}", result?.code ?? "tu pedido");
  const [form, setForm] = useState({
    customerDiscord: "",
    customerNote: "",
    paymentReference: "",
  });
  // Método con el que el cliente quiere pagar. Es solo su preferencia: el cobro
  // ocurre después en la pantalla segura de Tebex, que es la que cobra de verdad.
  const [metodoPago, setMetodoPago] = useState<string | null>(null);

  // La compra siempre queda vinculada a la cuenta del cliente.
  const session = trpc.customer.me.useQuery(undefined, {
    retry: false,
    refetchOnWindowFocus: false,
  });
  const account = session.data?.authenticated ? session.data.customer : null;

  // El equipo del panel (dueño o socio) también puede comprar sin crear una
  // cuenta de cliente: sirve para probar el circuito completo desde la web.
  const staffSession = trpc.admin.session.me.useQuery(undefined, {
    retry: false,
    refetchOnWindowFocus: false,
  });
  const equipo = staffSession.data?.authenticated ? staffSession.data : null;

  // Precargamos los datos que ya tenemos de su cuenta.
  useEffect(() => {
    if (account) {
      setForm((prev) => ({
        ...prev,
        customerDiscord: prev.customerDiscord || account.discord || "",
      }));
    }
  }, [account?.id, account?.discord, account]);

  const createOrder = trpc.orders.create.useMutation({
    onSuccess: (data) => {
      const pedido = data as OrderResult;
      setResult(pedido);
      // Si la tienda ya puede cobrar, el cliente termina el pago en Tebex.
      // Lo llevamos ahí mismo: al volver, verificamos que el dinero llegó.
      if (canCharge && irAlCheckout(pedido)) return;
      toast.success("Pedido creado", {
        description: `Tu código es ${data.code}. Completá el pago por ${provider}.`,
      });
    },
    onError: (error) => {
      toast.error("No pudimos crear el pedido", { description: error.message });
    },
  });

  /**
   * Lleva al cliente a la pantalla segura de Tebex.
   *
   * Es la pasarela la que cobra: acá solo lo enviamos. Al terminar vuelve solo
   * a Mis compras, donde verificamos de verdad si el pago llegó.
   */
  const irAlCheckout = (pedido: OrderResult): boolean => {
    if (pedido.checkoutUrl) {
      toast.success("Te llevamos a Tebex para completar el pago", {
        description: `Tu pedido ${pedido.code} queda reservado. Volvés solo al terminar.`,
      });
      window.location.href = pedido.checkoutUrl;
      return true;
    }
    if (pedido.authUrl) {
      window.location.href = pedido.authUrl;
      return true;
    }
    return false;
  };

  /** Arranca la compra del plan con el método que el cliente tocó. */
  const comprarConMetodo = (nombre: string) => {
    if (!canCharge) {
      toast.success(`Vas a pagar con ${nombre}`, {
        description: "Coordinamos el pago por Discord con tu código de pedido.",
      });
      return;
    }
    // Ya hay un pedido con su canasta: retomamos el pago sin crear otro.
    if (result && irAlCheckout(result)) return;
    if (!account && !equipo) {
      toast.error("Iniciá sesión para completar la compra", {
        description: "Guardamos tu plan elegido para que no lo pierdas.",
      });
      return;
    }
    if (!plan) return;
    createOrder.mutate({
      planId: plan.id,
      details: {
        ...form,
        customerName: account?.name ?? `Prueba ${equipo?.label ?? "del panel"}`,
        customerEmail: account?.email ?? "prueba@imperioshop.com",
      },
    });
  };

  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    if (!plan) return;
    // Alcanza con la cuenta de cliente o con la sesión del panel: el equipo
    // prueba la compra sin crear una cuenta aparte.
    if (!account && !equipo) {
      toast.error("Iniciá sesión para completar la compra", {
        description: "Guarda el plan elegido y volvé a intentarlo.",
      });
      return;
    }
    createOrder.mutate({
      planId: plan.id,
      details: {
        ...form,
        customerName: account?.name ?? `Prueba ${equipo?.label ?? "del panel"}`,
        customerEmail: account?.email ?? "prueba@imperioshop.com",
      },
    });
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(value) => {
        onOpenChange(value);
        if (!value) {
          createOrder.reset();
        }
      }}
    >
      <DialogContent className="max-h-[92vh] w-[95vw] max-w-2xl overflow-y-auto border-white/10 bg-[oklch(0.17_0.014_18)] p-0 sm:max-w-2xl">
        <DialogHeader className="border-b border-white/8 px-6 py-5">
          <DialogTitle className="font-display text-xl font-bold">
            {result ? "¡Pedido registrado!" : `Comprar ${plan?.name ?? ""}`}
          </DialogTitle>
          <DialogDescription className="text-sm text-muted-foreground">
            {result
              ? result.checkoutUrl
                ? "Completá el pago en la pantalla segura de Tebex."
                : result.authUrl
                  ? "Tebex te pide identificarte una vez y después seguís con el pago."
                  : cobroManual
                    ? `Seguí los pasos para completar el pago por ${provider}.`
                    : "Tu pedido quedó registrado. Coordinamos el pago por Discord."
              : `${serviceName} · ${plan ? formatPrice(plan.priceCents, plan.currency) : ""} ${
                  plan?.billing === "monthly" ? "por mes" : "pago único"
                }`}
          </DialogDescription>
        </DialogHeader>

        {result ? (
          <div className="space-y-5 px-6 py-6">
            <div className="rounded-2xl border border-primary/30 bg-primary/8 p-5 text-center">
              <p className="text-xs uppercase tracking-[0.22em] text-muted-foreground">
                Código de pedido
              </p>
              <p className="mt-2 font-display text-3xl font-black tracking-wider text-primary">
                {result.code}
              </p>
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard?.writeText(result.code);
                  toast.success("Código copiado");
                }}
                className="mx-auto mt-3 inline-flex items-center gap-1.5 text-xs text-muted-foreground transition-colors hover:text-primary"
              >
                <Copy className="h-3.5 w-3.5" />
                Copiar código
              </button>
            </div>

            <div className="rounded-2xl border border-white/10 bg-white/3 p-5">
              <p className="font-display text-sm font-bold">
                {result.checkoutUrl
                  ? "Importe a pagar"
                  : result.authUrl
                    ? "Importe de tu pedido"
                    : result.tebexFailed
                    ? "Importe de tu pedido"
                    : `Importe a transferir por ${provider}`}
              </p>
              <p className="mt-2 font-display text-2xl font-extrabold text-foreground">
                {formatPrice(result.amountCents, result.currency)}
                {result.billing === "monthly" && (
                  <span className="ml-1 text-sm font-medium text-muted-foreground">
                    / mes
                  </span>
                )}
              </p>
              {result.checkoutUrl && (
                <p className="mt-2 text-sm text-muted-foreground">
                  Pagás en la pantalla segura de Tebex, con PayPal, tarjeta o el método
                  que prefieras. La entrega arranca apenas se confirma el pago.
                </p>
              )}
              {result.authUrl && (
                <p className="mt-2 text-sm text-muted-foreground">
                  Tebex te pide identificarte una vez
                  {result.authProvider ? ` con tu cuenta de ${result.authProvider}` : ""} antes
                  de mostrar la pantalla de pago. Después volvés solo acá y seguís con el pago.
                </p>
              )}
              {result.tebexFailed && (
                <p className="mt-2 text-sm text-muted-foreground">
                  No pudimos abrir la pantalla de pago automáticamente. Abrí tu ticket en
                  Discord con el código de arriba y te pasamos el enlace de pago al toque.
                </p>
              )}
              {!result.checkoutUrl && !result.authUrl && !result.tebexFailed && cobroManual && result.paymentAccount && (
                <p className="mt-2 text-sm text-muted-foreground">
                  Cuenta de destino:{" "}
                  <span className="font-semibold text-foreground">
                    {result.paymentAccount}
                  </span>
                </p>
              )}
              {!result.checkoutUrl && !result.authUrl && !result.tebexFailed && !cobroManual && (
                <p className="mt-2 text-sm text-muted-foreground">
                  El cobro automático todavía no está habilitado. Tu pedido ya quedó
                  registrado a tu nombre: abrí un ticket en Discord con el código de
                  arriba y coordinamos el pago al instante.
                </p>
              )}
              {!result.checkoutUrl && !result.authUrl && !result.tebexFailed && cobroManual && !result.paymentAccount && (
                <p className="mt-2 text-sm text-muted-foreground">
                  Te pasamos la cuenta de {provider} para el pago apenas confirmes: podés
                  verla en esta pantalla o pedirla por Discord.
                </p>
              )}
            </div>

            {!result.checkoutUrl && !result.authUrl && !result.tebexFailed && cobroManual && result.paymentSteps && (
              <div className="rounded-2xl border border-white/10 bg-white/3 p-5">
                <p className="font-display text-sm font-bold">Pasos para pagar</p>
                <pre className="mt-3 whitespace-pre-wrap font-sans text-sm leading-relaxed text-muted-foreground">
                  {result.paymentSteps}
                </pre>
              </div>
            )}

            {!result.checkoutUrl && !result.authUrl && !result.tebexFailed && cobroManual && result.paymentQrUrl && (
              <div className="flex flex-col items-center rounded-2xl border border-white/10 bg-white/3 p-5">
                <img
                  src={result.paymentQrUrl}
                  alt="Código QR para completar el pago"
                  className="h-48 w-48 rounded-xl bg-white p-2"
                />
                <p className="mt-3 text-xs text-muted-foreground">
                  Escaneá el código para completar el pago
                </p>
              </div>
            )}

            <div className="flex items-start gap-3 rounded-2xl border border-amber-500/25 bg-amber-500/8 p-4">
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-amber-300" />
              <p className="text-sm text-amber-100/90">
                {result.checkoutUrl || result.authUrl ? (
                  <>
                    Guardá tu código <strong>{result.code}</strong>: podés seguir el
                    estado de tu pedido desde <strong>Mis compras</strong>.
                  </>
                ) : result.tebexFailed ? (
                  <>
                    Tu pedido <strong>{result.code}</strong> ya quedó registrado a tu
                    nombre. Falta solo el pago: pedilo por Discord y te lo enviamos.
                  </>
                ) : !cobroManual ? (
                  <>
                    Guardá tu código <strong>{result.code}</strong>: podés seguir el
                    estado de tu pedido desde <strong>Mis compras</strong>.
                  </>
                ) : (
                  <>
                    Indicá el código <strong>{result.code}</strong> en el concepto del
                    pago. Así podemos verificar tu compra al instante y arrancar con la
                    entrega.
                  </>
                )}
              </p>
            </div>

            {/* Aviso principal: sin el ticket no arranca la entrega. */}
            {!result.basketIdent && !result.checkoutUrl && !result.authUrl && (
            <div className="rounded-2xl border border-primary/35 bg-primary/10 p-5">
              <div className="flex items-start gap-3">
                <Ticket className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
                <div className="flex-1">
                  <p className="font-display text-sm font-bold text-foreground">
                    Abrí tu ticket para arrancar
                  </p>
                  <p className="mt-1 text-sm text-muted-foreground">{ticketMessage}</p>
                  {discordLink && (
                    <a
                      href={discordLink}
                      target="_blank"
                      rel="noreferrer"
                      className="mt-3 inline-flex"
                    >
                      <Button size="sm" className="gap-2 font-semibold">
                        <MessageCircle className="h-4 w-4" />
                        Abrir ticket en Discord
                      </Button>
                    </a>
                  )}
                </div>
              </div>
            </div>
            )}

            <div className="flex flex-col gap-3 sm:flex-row">
              {result.basketIdent ? (
                <TebexCheckoutButton
                  className="flex-1 gap-2 font-semibold"
                  basketIdent={result.basketIdent}
                  etiqueta="Pagar ahora"
                  onPagoCompletado={() => {
                    // Tebex avisó que terminó: pasamos a verificar de verdad
                    // contra Tebex antes de dar nada por pagado.
                    if (result.code) {
                      alPagar(result.code);
                    }
                  }}
                  onPagoFallido={(detalle) => {
                    toast.error("No se pudo completar el pago", {
                      description: detalle
                        ? detalle
                        : "Revisá los datos de tu tarjeta e intentá de nuevo.",
                    });
                  }}
                />
              ) : result.checkoutUrl ? (
                <a
                  href={result.checkoutUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="flex-1"
                >
                  <Button className="w-full gap-2 font-semibold">
                    <CreditCard className="h-4 w-4" />
                    Pagar ahora
                  </Button>
                </a>
              ) : result.authUrl ? (
                <a
                  href={result.authUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="flex-1"
                >
                  <Button className="w-full gap-2 font-semibold">
                    <CreditCard className="h-4 w-4" />
                    Iniciar sesión y pagar
                  </Button>
                </a>
              ) : (
                <Button className="flex-1 font-semibold" onClick={onDone}>
                  Ver mis compras y su estado
                </Button>
              )}
              {result.contactDiscord && (
                <a
                  href={result.contactDiscord}
                  target="_blank"
                  rel="noreferrer"
                  className="flex-1"
                >
                  <Button
                    variant="outline"
                    className="w-full gap-2 border-white/15 bg-white/4"
                  >
                    <MessageCircle className="h-4 w-4" />
                    Enviar comprobante
                  </Button>
                </a>
              )}
            </div>
          </div>
        ) : (
          <form onSubmit={submit} className="space-y-5 px-6 py-6">
            {/* Cuenta del cliente: la compra queda registrada a su nombre. */}
            {account ? (
              <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-emerald-500/25 bg-emerald-500/8 p-4">
                <div className="flex items-center gap-3">
                  <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-500/15 text-xs font-bold text-emerald-200">
                    {account.name.slice(0, 2).toUpperCase()}
                  </span>
                  <div>
                    <p className="text-sm font-semibold">{account.name}</p>
                    <p className="text-xs text-muted-foreground">{account.email}</p>
                  </div>
                </div>
                <Link
                  href="/mis-compras"
                  className="text-xs font-medium text-emerald-200 hover:underline"
                >
                  Ver mi cuenta
                </Link>
              </div>
            ) : equipo ? (
              // El equipo del panel está identificado: no le pedimos cuenta.
              <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-primary/30 bg-primary/8 p-4">
                <div className="flex items-center gap-3">
                  <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/15 text-xs font-bold text-primary">
                    {equipo.label.slice(0, 2).toUpperCase()}
                  </span>
                  <div>
                    <p className="text-sm font-semibold">{equipo.label}</p>
                    <p className="text-xs text-muted-foreground">
                      {equipo.role === "owner" ? "Dueño" : "Socio"} · compra de prueba del
                      equipo
                    </p>
                  </div>
                </div>
                <span className="rounded-full border border-primary/30 bg-primary/10 px-2.5 py-1 text-[0.65rem] font-semibold text-primary">
                  Prueba interna
                </span>
              </div>
            ) : (
              <div className="rounded-2xl border border-amber-500/30 bg-amber-500/8 p-4">
                <div className="flex items-start gap-3">
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-amber-300" />
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-amber-100">
                      Necesitás una cuenta para comprar
                    </p>
                    <p className="mt-1 text-xs text-amber-100/80">
                      Así tu pedido queda registrado a tu nombre y podés seguir su estado
                      desde tu perfil.
                    </p>
                    <div className="mt-3 flex flex-wrap gap-2">
                      <Link
                        href="/cuenta"
                        onClick={() => {
                          if (plan) {
                            sessionStorage.setItem(
                              "imperio-pending-plan",
                              `/servicio/${slug}?plan=${plan.id}`,
                            );
                          }
                        }}
                      >
                        <Button size="sm" type="button" className="gap-1.5 font-semibold">
                          Iniciar sesión
                          <ArrowRight className="h-3.5 w-3.5" />
                        </Button>
                      </Link>
                      <Link
                        href="/cuenta"
                        onClick={() => {
                          if (plan) {
                            sessionStorage.setItem(
                              "imperio-pending-plan",
                              `/servicio/${slug}?plan=${plan.id}`,
                            );
                          }
                        }}
                      >
                        <Button
                          size="sm"
                          type="button"
                          variant="outline"
                          className="border-white/15 bg-white/4 font-semibold"
                        >
                          Crear cuenta
                        </Button>
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="customerDiscord">Usuario de Discord</Label>
              <Input
                id="customerDiscord"
                maxLength={120}
                value={form.customerDiscord}
                onChange={(event) =>
                  setForm((prev) => ({ ...prev, customerDiscord: event.target.value }))
                }
                placeholder="usuario#0000 o @usuario"
                className="border-white/12 bg-white/4"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="customerNote">Contanos sobre tu proyecto</Label>
              <Textarea
                id="customerNote"
                rows={4}
                maxLength={1500}
                value={form.customerNote}
                onChange={(event) =>
                  setForm((prev) => ({ ...prev, customerNote: event.target.value }))
                }
                placeholder="Ej: necesito un bot con sistema de tickets y ventas automáticas para un servidor de 5.000 miembros."
                className="border-white/12 bg-white/4"
              />
            </div>

            {/* Métodos de pago: el cliente elige y después paga en la pantalla
                segura de Tebex, que es la que cobra de verdad. */}
            <div className="space-y-3 rounded-2xl border border-white/10 bg-white/3 p-5">
              <div>
                <p className="font-display text-sm font-bold">
                  ¿Con qué querés pagar?
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  Elegí tu método y a continuación completás el pago en la pantalla
                  segura de Tebex.
                </p>
              </div>
              <PaymentMethods
                canCharge={canCharge}
                activos={metodosActivos}
                onElegir={(id, nombre) => {
                  setMetodoPago(id);
                  // Coordinar el pago por ticket no pasa por Tebex: se resuelve
                  // en el Discord con el código del pedido.
                  if (id === "ticket") {
                    toast.success("Coordinamos el pago por Discord", {
                      description:
                        "Confirmá tu pedido y después abrí el ticket con el código que te damos.",
                    });
                    return;
                  }
                  comprarConMetodo(nombre);
                }}
                elegido={metodoPago}
              />
            </div>

            <div className="flex items-start gap-3 rounded-2xl border border-white/10 bg-white/3 p-4">
              <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
              <p className="text-xs leading-relaxed text-muted-foreground">
                {equipo && !account
                  ? `Estás comprando como ${equipo.role === "owner" ? "dueño" : "socio"}: el pedido queda marcado como prueba interna y podés seguir el pago desde el panel.`
                  : `Al confirmar generamos tu código de pedido y se abre la pantalla de pago de ${provider}, donde cargás los datos de tu tarjeta o pagás con PayPal. Los datos de tu tarjeta nunca pasan por esta web.`}
              </p>
            </div>

            <div className="flex flex-col-reverse gap-3 sm:flex-row">
              <Button
                type="button"
                variant="outline"
                onClick={alVolver}
                className="gap-2 border-white/15 bg-white/4 font-semibold sm:w-auto"
              >
                <ArrowLeft className="h-4 w-4" />
                Volver atrás
              </Button>
              <Button
                type="submit"
                className="glow-ring flex-1 gap-2 font-semibold"
                disabled={createOrder.isPending}
              >
                {createOrder.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Generando pedido…
                  </>
                ) : (
                  <>
                    <CreditCard className="h-4 w-4" />
                    Confirmar y ver datos de pago
                  </>
                )}
              </Button>
            </div>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
