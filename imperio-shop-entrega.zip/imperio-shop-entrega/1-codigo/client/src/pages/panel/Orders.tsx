import { PanelHeading, PanelLoading } from "@/components/panel/PanelLayout";
import { PaymentCheckPanel } from "@/components/panel/PaymentCheckPanel";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import {
  ORDER_STATUS_ORDER,
  formatDate,
  formatPrice,
  statusInfo,
} from "@/lib/format";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import {
  Check,
  Copy,
  FlaskConical,
  Loader2,
  Mail,
  MessageCircle,
  Search,
  StickyNote,
  User,
} from "lucide-react";
import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";

export default function PanelOrders() {
  const [location, setLocation] = useLocation();
  const focusId = Number(new URLSearchParams(window.location.search).get("focus"));
  const [status, setStatus] = useState("all");
  const [search, setSearch] = useState("");
  const [debounced, setDebounced] = useState("");
  const [openId, setOpenId] = useState<number | null>(
    Number.isFinite(focusId) && focusId > 0 ? focusId : null,
  );
  const [testOpen, setTestOpen] = useState(false);

  // Al probar una compra desde la web, Tebex devuelve acá con el código del
  // pedido: verificamos contra Tebex que el dinero llegó antes de dar nada por
  // pagado.
  const params = new URLSearchParams(window.location.search);
  const pedidoPrueba = params.get("pedido") ?? "";
  const [verificando, setVerificando] = useState(
    params.get("pago") === "ok" && Boolean(pedidoPrueba),
  );

  useEffect(() => {
    const timer = setTimeout(() => setDebounced(search), 320);
    return () => clearTimeout(timer);
  }, [search]);

  const list = trpc.admin.orders.list.useQuery(
    { status, search: debounced, limit: 100, offset: 0 },
    { refetchOnWindowFocus: false },
  );

  const detail = trpc.admin.orders.detail.useQuery(
    { id: openId ?? 0 },
    { enabled: Boolean(openId), refetchOnWindowFocus: false },
  );

  const utils = trpc.useUtils();
  const update = trpc.admin.orders.update.useMutation({
    onSuccess: async () => {
      await Promise.all([
        utils.admin.orders.list.invalidate(),
        utils.admin.orders.detail.invalidate(),
        utils.admin.overview.invalidate(),
      ]);
      toast.success("Pedido actualizado");
    },
    onError: (error) => toast.error("No se pudo actualizar", { description: error.message }),
  });

  const advance = trpc.admin.orders.advance.useMutation({
    onSuccess: async () => {
      await Promise.all([
        utils.admin.orders.list.invalidate(),
        utils.admin.orders.detail.invalidate(),
        utils.admin.overview.invalidate(),
      ]);
      toast.success("Estado actualizado");
    },
    onError: (error) => toast.error("No se pudo cambiar el estado", { description: error.message }),
  });

  const orders = list.data?.rows ?? [];

  return (
    <div className="space-y-6">
      <PanelHeading
        title="Pedidos"
        description="Todos los pedidos de la tienda. Verificá los pagos recibidos, cambiá el estado y dejá notas internas."
        action={
          <Button
            className="gap-2 font-semibold"
            onClick={() => setTestOpen(true)}
          >
            <FlaskConical className="h-4 w-4" />
            Pedido de prueba
          </Button>
        }
      />

      <Card className="surface rounded-2xl border-0 p-4">
        {verificando && pedidoPrueba && (
          <div className="mb-4">
            <PaymentCheckPanel
              orderCode={pedidoPrueba}
              onFinished={() => {
                setVerificando(false);
                utils.admin.orders.list.invalidate();
                utils.admin.overview.invalidate();
                setLocation("/panel/pedidos");
              }}
            />
          </div>
        )}
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Buscar por código, cliente, correo o servicio…"
              className="border-white/12 bg-white/4 pl-9"
            />
          </div>
          <Select value={status} onValueChange={setStatus}>
            <SelectTrigger className="w-full border-white/12 bg-white/4 sm:w-56">
              <SelectValue placeholder="Estado" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos los estados</SelectItem>
              {ORDER_STATUS_ORDER.map((value) => (
                <SelectItem key={value} value={value}>
                  {statusInfo(value).label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </Card>

      {list.isLoading ? (
        <PanelLoading />
      ) : orders.length === 0 ? (
        <Card className="surface rounded-2xl border-0 p-10 text-center">
          <p className="font-display text-lg font-bold">Sin pedidos para mostrar</p>
          <p className="mt-2 text-sm text-muted-foreground">
            {debounced || status !== "all"
              ? "Probá cambiando los filtros de búsqueda."
              : "Cuando un cliente complete una compra, el pedido aparece acá."}
          </p>
        </Card>
      ) : (
        <Card className="surface overflow-hidden rounded-2xl border-0">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[840px] text-sm">
              <thead>
                <tr className="border-b border-white/8 text-left text-xs uppercase tracking-wider text-muted-foreground">
                  <th className="px-5 py-3.5 font-medium">Código</th>
                  <th className="px-5 py-3.5 font-medium">Cliente</th>
                  <th className="px-5 py-3.5 font-medium">Servicio</th>
                  <th className="px-5 py-3.5 font-medium">Importe</th>
                  <th className="px-5 py-3.5 font-medium">Estado</th>
                  <th className="px-5 py-3.5 font-medium">Fecha</th>
                  <th className="px-5 py-3.5" />
                </tr>
              </thead>
              <tbody>
                {orders.map((order) => {
                  const info = statusInfo(order.status);
                  return (
                    <tr
                      key={order.id}
                      className="border-b border-white/6 transition-colors last:border-0 hover:bg-white/3"
                    >
                      <td className="px-5 py-4 font-mono text-xs font-semibold text-primary">
                        {order.code}
                      </td>
                      <td className="px-5 py-4">
                        <p className="font-medium">{order.customerName}</p>
                        <p className="text-xs text-muted-foreground">
                          {order.customerEmail}
                        </p>
                      </td>
                      <td className="px-5 py-4">
                        <p>{order.serviceName}</p>
                        <p className="text-xs text-muted-foreground">{order.planName}</p>
                      </td>
                      <td className="px-5 py-4 font-medium">
                        {formatPrice(order.amountCents, order.currency)}
                      </td>
                      <td className="px-5 py-4">
                        <span
                          className={cn(
                            "inline-block rounded-full border px-2.5 py-1 text-[0.65rem] font-semibold",
                            info.tone,
                          )}
                        >
                          {info.label}
                        </span>
                      </td>
                      <td className="px-5 py-4 text-xs text-muted-foreground">
                        {formatDate(order.createdAt)}
                      </td>
                      <td className="px-5 py-4 text-right">
                        <Button
                          size="sm"
                          variant="outline"
                          className="gap-1.5 border-white/12 bg-white/4"
                          onClick={() => setOpenId(order.id)}
                        >
                          Gestionar
                        </Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      <OrderDialog
        open={Boolean(openId)}
        onOpenChange={(value) => {
          if (!value) {
            setOpenId(null);
            if (location.includes("focus=")) setLocation("/panel/pedidos");
          }
        }}
        order={detail.data?.order ?? null}
        events={detail.data?.events ?? []}
        loading={detail.isLoading}
        onSave={(patch) => openId && update.mutate({ id: openId, ...patch })}
        onAdvance={(nextStatus, note) =>
          openId && advance.mutate({ id: openId, status: nextStatus, note })
        }
        saving={update.isPending || advance.isPending}
      />

      <TestOrderDialog
        open={testOpen}
        onOpenChange={setTestOpen}
        onCreated={async () => {
          await utils.admin.orders.list.invalidate();
          await utils.admin.overview.invalidate();
        }}
      />
    </div>
  );
}

/* -------------------------------------------------------------------------- */

type OrderStatus = (typeof ORDER_STATUS_ORDER)[number];

/**
 * Crea un pedido de prueba.
 *
 * Sirve para revisar el panel y ensayar la entrega sin depender de un cobro
 * real. El pedido queda marcado como prueba en la nota interna.
 */
function TestOrderDialog({
  open,
  onOpenChange,
  onCreated,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onCreated: () => Promise<void>;
}) {
  const catalog = trpc.admin.catalog.list.useQuery(undefined, {
    enabled: open,
    refetchOnWindowFocus: false,
  });
  const [planId, setPlanId] = useState("");
  const [name, setName] = useState("Cliente de prueba");
  const [email, setEmail] = useState("prueba@imperioshop.com");
  const [discord, setDiscord] = useState("");
  const [note, setNote] = useState("");
  const [status, setStatus] = useState<OrderStatus>("pending_payment");

  // Todos los planes del catálogo, con el nombre del servicio adelante.
  const opciones = (catalog.data ?? []).flatMap((service) =>
    service.plans.map((plan) => ({
      value: String(plan.id),
      label: `${service.name} · ${plan.name}`,
    })),
  );

  const create = trpc.admin.orders.createTest.useMutation({
    onSuccess: async (result) => {
      await onCreated();
      toast.success(`Pedido de prueba ${result.code} creado`, {
        description: "Ya aparece en la lista para que lo gestiones.",
      });
      onOpenChange(false);
    },
    onError: (error) =>
      toast.error("No se pudo crear el pedido", { description: error.message }),
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] w-[95vw] max-w-xl overflow-y-auto border-white/10 bg-[oklch(0.17_0.014_18)]">
        <DialogHeader>
          <DialogTitle className="font-display text-lg font-bold">
            Pedido de prueba
          </DialogTitle>
          <DialogDescription className="text-sm text-muted-foreground">
            Crea un pedido que no depende de un cobro real, para revisar el panel y
            ensayar la entrega. Queda marcado como prueba.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Plan *</Label>
            <Select value={planId} onValueChange={setPlanId}>
              <SelectTrigger className="border-white/12 bg-white/4">
                <SelectValue placeholder="Elegí un plan" />
              </SelectTrigger>
              <SelectContent>
                {opciones.map((opcion) => (
                  <SelectItem key={opcion.value} value={opcion.value}>
                    {opcion.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="test-name">Nombre *</Label>
              <Input
                id="test-name"
                value={name}
                onChange={(event) => setName(event.target.value)}
                className="border-white/12 bg-white/4"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="test-email">Correo *</Label>
              <Input
                id="test-email"
                type="email"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                className="border-white/12 bg-white/4"
              />
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="test-discord">Discord</Label>
              <Input
                id="test-discord"
                value={discord}
                onChange={(event) => setDiscord(event.target.value)}
                placeholder="usuario#0000"
                className="border-white/12 bg-white/4"
              />
            </div>
            <div className="space-y-2">
              <Label>Estado inicial</Label>
              <Select value={status} onValueChange={(v) => setStatus(v as OrderStatus)}>
                <SelectTrigger className="border-white/12 bg-white/4">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ORDER_STATUS_ORDER.map((value) => (
                    <SelectItem key={value} value={value}>
                      {statusInfo(value).label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="test-note">Detalle del pedido</Label>
            <Textarea
              id="test-note"
              rows={3}
              value={note}
              onChange={(event) => setNote(event.target.value)}
              placeholder="Ej: pedido de prueba para revisar el flujo de entrega."
              className="border-white/12 bg-white/4"
            />
          </div>

          <Button
            className="w-full gap-2 font-semibold"
            disabled={!planId || name.trim().length < 2 || create.isPending}
            onClick={() =>
              create.mutate({
                planId: Number(planId),
                customerName: name,
                customerEmail: email,
                customerDiscord: discord,
                customerNote: note,
                status,
              })
            }
          >
            {create.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <FlaskConical className="h-4 w-4" />
            )}
            Crear pedido de prueba
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

type OrderRow = {
  id: number;
  code: string;
  serviceName: string;
  planName: string;
  amountCents: number;
  currency: string;
  billing: string;
  customerName: string;
  customerEmail: string;
  customerDiscord: string;
  customerNote: string;
  payerAccount: string;
  paymentReference: string;
  paymentMethod: string;
  status: string;
  staffNote: string;
  createdAt: Date;
  updatedAt: Date;
};

function OrderDialog({
  open,
  onOpenChange,
  order,
  events,
  loading,
  onSave,
  onAdvance,
  saving,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  order: OrderRow | null;
  events: { id: number; toStatus: string; note: string; actor: string; createdAt: Date }[];
  loading: boolean;
  onSave: (patch: {
    staffNote?: string;
    payerAccount?: string;
    paymentReference?: string;
    status?: OrderStatus;
  }) => void;
  onAdvance: (status: OrderStatus, note: string) => void;
  saving: boolean;
}) {
  const [note, setNote] = useState("");
  const [payer, setPayer] = useState("");
  const [reference, setReference] = useState("");

  useEffect(() => {
    if (order) {
      setNote(order.staffNote ?? "");
      setPayer(order.payerAccount ?? "");
      setReference(order.paymentReference ?? "");
    }
  }, [order?.id, order]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] w-[95vw] max-w-3xl overflow-y-auto border-white/10 bg-[oklch(0.17_0.014_18)] p-0">
        <DialogHeader className="border-b border-white/8 px-6 py-5">
          <DialogTitle className="font-display text-lg font-bold">
            {order ? `Pedido ${order.code}` : "Cargando pedido…"}
          </DialogTitle>
          <DialogDescription className="text-sm text-muted-foreground">
            {order
              ? `${order.serviceName} · ${order.planName} · ${formatPrice(order.amountCents, order.currency)}`
              : "Obteniendo información del pedido"}
          </DialogDescription>
        </DialogHeader>

        {loading || !order ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
          </div>
        ) : (
          <div className="space-y-6 px-6 py-6">
            <div className="flex flex-wrap items-center gap-3">
              <span
                className={cn(
                  "rounded-full border px-3 py-1.5 text-xs font-semibold",
                  statusInfo(order.status).tone,
                )}
              >
                {statusInfo(order.status).label}
              </span>
              <span className="text-xs text-muted-foreground">
                Creado el {formatDate(order.createdAt)}
              </span>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="rounded-2xl border border-white/8 bg-white/3 p-4">
                <p className="flex items-center gap-2 text-xs uppercase tracking-wider text-muted-foreground">
                  <User className="h-3.5 w-3.5" />
                  Cliente
                </p>
                <p className="mt-2 text-sm font-semibold">{order.customerName}</p>
                <a
                  href={`mailto:${order.customerEmail}`}
                  className="mt-1 flex items-center gap-1.5 text-xs text-muted-foreground hover:text-primary"
                >
                  <Mail className="h-3.5 w-3.5" />
                  {order.customerEmail}
                </a>
                {order.customerDiscord && (
                  <p className="mt-1 flex items-center gap-1.5 text-xs text-muted-foreground">
                    <MessageCircle className="h-3.5 w-3.5" />
                    {order.customerDiscord}
                  </p>
                )}
              </div>

              <div className="rounded-2xl border border-white/8 bg-white/3 p-4">
                <p className="text-xs uppercase tracking-wider text-muted-foreground">
                  Pago del cliente
                </p>
                <p className="mt-2 text-sm">
                  Método:{" "}
                  <span className="font-semibold">
                    {order.paymentMethod === "tebex"
                      ? "Tebex"
                      : order.paymentMethod === "manual"
                        ? "Coordinado por Discord"
                        : order.paymentMethod || "sin datos"}
                  </span>
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  Cuenta declarada:{" "}
                  <span className="text-foreground/90">
                    {order.payerAccount || "sin datos"}
                  </span>
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  Referencia:{" "}
                  <span className="text-foreground/90">
                    {order.paymentReference || "sin datos"}
                  </span>
                </p>
              </div>
            </div>

            {order.customerNote && (
              <div className="rounded-2xl border border-white/8 bg-white/3 p-4">
                <p className="text-xs uppercase tracking-wider text-muted-foreground">
                  Mensaje del cliente
                </p>
                <p className="mt-2 whitespace-pre-wrap text-sm text-foreground/90">
                  {order.customerNote}
                </p>
              </div>
            )}

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="payer">Método de pago informado por Tebex</Label>
                <Input
                  id="payer"
                  value={payer}
                  onChange={(event) => setPayer(event.target.value)}
                  className="border-white/12 bg-white/4"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="reference">Referencia / comprobante</Label>
                <Input
                  id="reference"
                  value={reference}
                  onChange={(event) => setReference(event.target.value)}
                  placeholder="ID de transacción de Tebex (tbx-...)"
                  className="border-white/12 bg-white/4"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="note" className="flex items-center gap-2">
                <StickyNote className="h-3.5 w-3.5" />
                Nota interna
              </Label>
              <Textarea
                id="note"
                rows={3}
                value={note}
                onChange={(event) => setNote(event.target.value)}
                placeholder="Ej: pago verificado, se entregó el acceso al cliente."
                className="border-white/12 bg-white/4"
              />
            </div>

            <Button
              variant="outline"
              className="gap-2 border-white/12 bg-white/4"
              onClick={() => onSave({ staffNote: note, payerAccount: payer, paymentReference: reference })}
              disabled={saving}
            >
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
              Guardar datos
            </Button>

            <div className="border-t border-white/8 pt-5">
              <p className="font-display text-sm font-bold">Cambiar estado</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {ORDER_STATUS_ORDER.map((value) => (
                  <Button
                    key={value}
                    size="sm"
                    variant={order.status === value ? "default" : "outline"}
                    className={cn(
                      "border-white/12",
                      order.status !== value && "bg-white/4",
                    )}
                    disabled={saving || order.status === value}
                    onClick={() => onAdvance(value, note)}
                  >
                    {statusInfo(value).label}
                  </Button>
                ))}
              </div>
            </div>

            {events.length > 0 && (
              <div className="border-t border-white/8 pt-5">
                <p className="font-display text-sm font-bold">Historial</p>
                <ul className="mt-3 space-y-2.5">
                  {events.map((event) => (
                    <li
                      key={event.id}
                      className="flex items-start justify-between gap-3 rounded-xl border border-white/8 bg-white/3 px-4 py-3"
                    >
                      <div>
                        <p className="text-sm font-medium">
                          {statusInfo(event.toStatus).label}
                        </p>
                        {event.note && (
                          <p className="mt-0.5 text-xs text-muted-foreground">{event.note}</p>
                        )}
                      </div>
                      <span className="shrink-0 text-xs text-muted-foreground">
                        {event.actor} · {formatDate(event.createdAt)}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div className="flex flex-wrap gap-2 border-t border-white/8 pt-5">
              <Button
                variant="outline"
                size="sm"
                className="gap-2 border-white/12 bg-white/4"
                onClick={() => {
                  navigator.clipboard?.writeText(order.code);
                  toast.success("Código copiado");
                }}
              >
                <Copy className="h-3.5 w-3.5" />
                Copiar código
              </Button>
              <Badge variant="outline" className="border-white/12 bg-white/4 text-xs">
                ID interno #{order.id}
              </Badge>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
