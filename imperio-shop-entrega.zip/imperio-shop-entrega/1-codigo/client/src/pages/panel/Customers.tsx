import { PanelHeading, PanelLoading } from "@/components/panel/PanelLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { formatDate, formatPrice, formatRelative, statusInfo } from "@/lib/format";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import {
  Check,
  Clock,
  Copy,
  KeyRound,
  Loader2,
  Mail,
  MessageCircle,
  Package,
  Receipt,
  RefreshCw,
  Search,
  Send,
  Trash2,
  UserPlus,
  Users,
} from "lucide-react";
import { useEffect, useState } from "react";
import { Link } from "wouter";
import { toast } from "sonner";

/** Indica con qué método entró el cliente por última vez. */
function ProviderBadge({ provider }: { provider: string }) {
  const labels: Record<string, string> = {
    google: "Google",
    apple: "Apple",
    microsoft: "Microsoft",
    email: "Correo y contraseña",
  };
  return (
    <span className="inline-flex items-center gap-1 rounded-full border border-white/12 px-2 py-0.5 text-[0.65rem]">
      {labels[provider] ?? provider}
    </span>
  );
}

export default function PanelCustomers() {
  const [search, setSearch] = useState("");
  const [debounced, setDebounced] = useState("");
  const [openId, setOpenId] = useState<number | null>(null);
  const [inviteOpen, setInviteOpen] = useState(false);
  const [inviteName, setInviteName] = useState("");
  const [inviteEmail, setInviteEmail] = useState("");
  const [manualCode, setManualCode] = useState<string | null>(null);
  const [resetId, setResetId] = useState<number | null>(null);
  const [resetPass, setResetPass] = useState("");
  const utils = trpc.useUtils();

  useEffect(() => {
    const timer = setTimeout(() => setDebounced(search), 320);
    return () => clearTimeout(timer);
  }, [search]);

  const list = trpc.admin.customers.list.useQuery(
    { search: debounced, limit: 100 },
    { refetchOnWindowFocus: false },
  );

  const detail = trpc.admin.customers.detail.useQuery(
    { id: openId ?? 0 },
    { enabled: Boolean(openId), refetchOnWindowFocus: false },
  );

  const customers = list.data ?? [];
  const totalSpent = customers.reduce((sum, row) => sum + row.spentCents, 0);

  const invitations = trpc.admin.customers.invitations.useQuery(
    { search: "", limit: 50 },
    { refetchOnWindowFocus: false },
  );
  const pending = invitations.data?.invitations ?? [];
  const inviteStats = invitations.data?.stats;

  const invite = trpc.admin.customers.invite.useMutation({
    onSuccess: async (data) => {
      await utils.admin.customers.invitations.invalidate();
      if (data.sent) {
        toast.success("Invitación enviada", {
          description: `${inviteName} va a recibir el código en su correo.`,
        });
        setInviteOpen(false);
      } else {
        // Sin correo configurado: mostramos el código para pasarlo a mano.
        setManualCode(data.manualCode ?? null);
        toast.info("Correo sin conectar", {
          description: "Pasale el código a mano hasta que conectemos el envío.",
          duration: 10000,
        });
      }
      setInviteName("");
      setInviteEmail("");
    },
    onError: (error) => toast.error(error.message),
  });

  const resend = trpc.admin.customers.resendInvitation.useMutation({
    onSuccess: async (data) => {
      await utils.admin.customers.invitations.invalidate();
      if (data.sent) {
        toast.success("Invitación reenviada");
      } else {
        setManualCode(data.manualCode ?? null);
        toast.info("Correo sin conectar", {
          description: "Pasale el código a mano hasta que conectemos el envío.",
          duration: 10000,
        });
      }
    },
    onError: (error) => toast.error(error.message),
  });

  const cancel = trpc.admin.customers.cancelInvitation.useMutation({
    onSuccess: async () => {
      await utils.admin.customers.invitations.invalidate();
      toast.success("Invitación cancelada");
    },
    onError: (error) => toast.error(error.message),
  });

  const resetPassword = trpc.admin.customers.resetPassword.useMutation({
    onSuccess: () => {
      toast.success("Contraseña restablecida", {
        description: "Avisale al cliente su contraseña nueva para que ingrese y la cambie.",
      });
      setResetId(null);
      setResetPass("");
    },
    onError: (error) => toast.error(error.message),
  });

  const setActive = trpc.admin.customers.setActive.useMutation({
    onSuccess: async () => {
      await Promise.all([
        utils.admin.customers.list.invalidate(),
        utils.admin.customers.detail.invalidate(),
      ]);
      toast.success("Cuenta actualizada");
    },
    onError: (error) => toast.error(error.message),
  });

  // Registros que quedaron sin confirmar: sin correo conectado, la persona no
  // recibe el código y su cuenta nunca se crea. El dueño puede habilitarla acá.
  const pendingSignups = trpc.admin.customers.pendingSignups.useQuery(undefined, {
    refetchOnWindowFocus: false,
  });
  const approveSignup = trpc.admin.customers.approvePendingSignup.useMutation({
    onSuccess: async (data) => {
      await Promise.all([
        utils.admin.customers.pendingSignups.invalidate(),
        utils.admin.customers.list.invalidate(),
      ]);
      toast.success(`Cuenta habilitada: ${data.name}`, {
        description: "Ya puede ingresar con el correo y la contraseña que eligió.",
      });
    },
    onError: (error) => toast.error(error.message),
  });
  const signups = pendingSignups.data ?? [];

  return (
    <div className="space-y-6">
      <PanelHeading
        title="Clientes"
        description="Cuentas, compras e invitaciones. Creá perfiles por correo y el cliente los activa con su código."
      />

      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-primary/18 bg-primary/6 p-4">
        <div className="flex items-start gap-3">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-primary/15 text-primary">
            <Mail className="h-4 w-4" />
          </span>
          <div>
            <p className="text-sm font-semibold">Crear cuenta para un cliente</p>
            <p className="mt-0.5 text-xs text-muted-foreground">
              Le mandamos un código por correo. La cuenta se activa cuando él elige su contraseña.
            </p>
          </div>
        </div>
        <Button className="gap-2 font-semibold" onClick={() => setInviteOpen(true)}>
          <UserPlus className="h-4 w-4" />
          Invitar cliente
        </Button>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        {[
          { label: "Cuentas registradas", value: String(customers.length), icon: Users },
          {
            label: "Clientes con compras",
            value: String(customers.filter((row) => row.orderCount > 0).length),
            icon: Package,
          },
          { label: "Facturación de clientes", value: formatPrice(totalSpent), icon: Receipt },
        ].map((item) => (
          <Card key={item.label} className="surface rounded-2xl border-0 p-5">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/12 text-primary">
              <item.icon className="h-4 w-4" />
            </span>
            <p className="mt-3 font-display text-xl font-extrabold">{item.value}</p>
            <p className="text-xs text-muted-foreground">{item.label}</p>
          </Card>
        ))}
      </div>

      <Card className="surface rounded-2xl border-0 p-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Buscar por nombre o correo…"
            className="border-white/12 bg-white/4 pl-9"
          />
        </div>
      </Card>

      {list.isLoading ? (
        <PanelLoading />
      ) : customers.length === 0 ? (
        <Card className="surface rounded-2xl border-0 p-10 text-center">
          <UserPlus className="mx-auto h-8 w-8 text-muted-foreground" />
          <p className="mt-3 font-display text-lg font-bold">
            {debounced ? "Sin resultados" : "Todavía no hay clientes registrados"}
          </p>
          <p className="mt-2 text-sm text-muted-foreground">
            {debounced
              ? "Probá con otro nombre o correo."
              : "Cuando alguien cree su cuenta para comprar, aparece acá con su historial."}
          </p>
        </Card>
      ) : (
        <Card className="surface overflow-hidden rounded-2xl border-0">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[820px] text-sm">
              <thead>
                <tr className="border-b border-white/8 text-left text-xs uppercase tracking-wider text-muted-foreground">
                  <th className="px-5 py-3.5 font-medium">Cliente</th>
                  <th className="px-5 py-3.5 font-medium">Contacto</th>
                  <th className="px-5 py-3.5 font-medium">Compras</th>
                  <th className="px-5 py-3.5 font-medium">Gastado</th>
                  <th className="px-5 py-3.5 font-medium">Última compra</th>
                  <th className="px-5 py-3.5" />
                </tr>
              </thead>
              <tbody>
                {customers.map((row) => (
                  <tr
                    key={row.id}
                    className="border-b border-white/6 transition-colors last:border-0 hover:bg-white/3"
                  >
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-3">
                        <span className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/12 text-xs font-bold text-primary">
                          {row.name.slice(0, 2).toUpperCase()}
                        </span>
                        <div>
                          <div className="flex items-center gap-2">
                            <p className="font-medium">{row.name}</p>
                            {!row.active && (
                              <Badge variant="outline" className="border-destructive/30 text-[0.6rem] text-destructive">
                                Suspendida
                              </Badge>
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground">
                            Alta: {formatDate(row.createdAt)}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-4">
                      <p className="text-xs text-muted-foreground">{row.email}</p>
                      <p className="mt-0.5 flex items-center gap-1.5 text-xs text-muted-foreground">
                        <ProviderBadge provider={row.provider} />
                      </p>
                      {row.discord && (
                        <p className="mt-0.5 flex items-center gap-1.5 text-xs text-muted-foreground">
                          <MessageCircle className="h-3 w-3" />
                          {row.discord}
                        </p>
                      )}
                    </td>
                    <td className="px-5 py-4">
                      <Badge
                        variant="outline"
                        className={cn(
                          "text-xs",
                          row.orderCount > 0
                            ? "border-primary/40 text-primary"
                            : "border-white/15 text-muted-foreground",
                        )}
                      >
                        {row.orderCount}
                      </Badge>
                    </td>
                    <td className="px-5 py-4 font-medium">
                      {formatPrice(row.spentCents)}
                    </td>
                    <td className="px-5 py-4 text-xs text-muted-foreground">
                      {row.lastOrderAt ? formatRelative(row.lastOrderAt) : "—"}
                    </td>
                    <td className="px-5 py-4 text-right">
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-white/12 bg-white/4"
                        onClick={() => setOpenId(row.id)}
                      >
                        Ver ficha
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {/* Altas que quedaron sin confirmar */}
      {signups.length > 0 && (
        <div className="space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="font-display text-sm font-bold">
              Registros sin confirmar
              <span className="ml-2 font-sans text-xs font-normal text-muted-foreground">
                {signups.length} esperando
              </span>
            </p>
            <p className="text-xs text-muted-foreground">
              No pudieron recibir el código por correo. Habilitalos para que entren.
            </p>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            {signups.map((item) => (
              <Card
                key={item.id}
                className="surface flex flex-col gap-3 rounded-2xl border-0 p-4"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold">{item.name}</p>
                    <p className="truncate text-xs text-muted-foreground">{item.email}</p>
                    {item.discord && (
                      <p className="truncate text-xs text-muted-foreground">{item.discord}</p>
                    )}
                  </div>
                  <Badge
                    variant="outline"
                    className={cn(
                      "shrink-0 text-[0.65rem]",
                      item.expired
                        ? "border-white/15 text-muted-foreground"
                        : "border-amber-400/40 text-amber-300",
                    )}
                  >
                    {item.expired ? "Código vencido" : "Esperando código"}
                  </Badge>
                </div>
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <span className="inline-flex items-center gap-1.5">
                    <Clock className="h-3 w-3" />
                    {formatRelative(item.createdAt)}
                  </span>
                </div>
                <div className="border-t border-white/8 pt-3">
                  <Button
                    size="sm"
                    className="w-full gap-1.5 font-semibold"
                    disabled={approveSignup.isPending}
                    onClick={() => approveSignup.mutate({ email: item.email })}
                  >
                    {approveSignup.isPending ? (
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    ) : (
                      <Check className="h-3.5 w-3.5" />
                    )}
                    Habilitar cuenta
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Invitaciones pendientes de activar */}
      {pending.length > 0 && (
        <div className="space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="font-display text-sm font-bold">
              Invitaciones sin activar
              <span className="ml-2 font-sans text-xs font-normal text-muted-foreground">
                {inviteStats ? `${inviteStats.activated} ya activadas` : ""}
              </span>
            </p>
            <p className="text-xs text-muted-foreground">
              El código vence a los 15 minutos; podés reenviarlo.
            </p>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            {pending.map((item) => (
              <Card
                key={item.id}
                className="surface flex flex-col gap-3 rounded-2xl border-0 p-4"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold">{item.name}</p>
                    <p className="truncate text-xs text-muted-foreground">{item.email}</p>
                  </div>
                  <Badge
                    variant="outline"
                    className={cn(
                      "shrink-0 text-[0.65rem]",
                      item.expired
                        ? "border-white/15 text-muted-foreground"
                        : "border-primary/40 text-primary",
                    )}
                  >
                    {item.expired ? "Vencida" : "Pendiente"}
                  </Badge>
                </div>
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <span className="inline-flex items-center gap-1.5">
                    <Clock className="h-3 w-3" />
                    {formatRelative(item.createdAt)}
                  </span>
                  {item.invitedBy && <span>· Invitó {item.invitedBy}</span>}
                </div>
                <div className="flex items-center gap-2 border-t border-white/8 pt-3">
                  <Button
                    size="sm"
                    variant="outline"
                    className="gap-1.5 border-white/12 bg-white/4"
                    disabled={resend.isPending}
                    onClick={() => resend.mutate({ id: item.id })}
                  >
                    {resend.isPending ? (
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    ) : (
                      <RefreshCw className="h-3.5 w-3.5" />
                    )}
                    Reenviar
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="gap-1.5 border-destructive/30 bg-destructive/8 text-destructive"
                    disabled={cancel.isPending}
                    onClick={() => cancel.mutate({ id: item.id })}
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    Cancelar
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      <Dialog open={Boolean(openId)} onOpenChange={(value) => !value && setOpenId(null)}>
        <DialogContent className="max-h-[92vh] w-[95vw] max-w-2xl overflow-y-auto border-white/10 bg-[oklch(0.17_0.014_18)]">
          <DialogHeader>
            <DialogTitle className="font-display text-lg font-bold">
              {detail.data ? detail.data.customer.name : "Cargando ficha…"}
            </DialogTitle>
            <DialogDescription className="text-sm text-muted-foreground">
              {detail.data
                ? `${detail.data.customer.email} · ${detail.data.orders.length} compra(s)`
                : "Obteniendo información del cliente"}
            </DialogDescription>
          </DialogHeader>

          {detail.data && (
            <div className="space-y-5">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="rounded-2xl border border-white/8 bg-white/3 p-4">
                  <p className="text-xs uppercase tracking-wider text-muted-foreground">
                    Contacto
                  </p>
                  <a
                    href={`mailto:${detail.data.customer.email}`}
                    className="mt-2 flex items-center gap-1.5 text-sm hover:text-primary"
                  >
                    <Mail className="h-3.5 w-3.5" />
                    {detail.data.customer.email}
                  </a>
                  {detail.data.customer.discord && (
                    <p className="mt-1 flex items-center gap-1.5 text-sm text-muted-foreground">
                      <MessageCircle className="h-3.5 w-3.5" />
                      {detail.data.customer.discord}
                    </p>
                  )}
                </div>
                <div className="rounded-2xl border border-white/8 bg-white/3 p-4">
                  <p className="text-xs uppercase tracking-wider text-muted-foreground">
                    Actividad
                  </p>
                  <p className="mt-2 text-sm">
                    Registro:{" "}
                    <span className="font-medium">
                      {formatDate(detail.data.customer.createdAt)}
                    </span>
                  </p>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Último ingreso:{" "}
                    {detail.data.customer.lastSignedIn
                      ? formatRelative(detail.data.customer.lastSignedIn)
                      : "nunca"}
                  </p>
                </div>
              </div>

              <div>
                <p className="font-display text-sm font-bold">Compras del cliente</p>
                {detail.data.orders.length === 0 ? (
                  <p className="mt-3 rounded-2xl border border-dashed border-white/12 p-6 text-center text-sm text-muted-foreground">
                    Esta cuenta todavía no completó ninguna compra.
                  </p>
                ) : (
                  <ul className="mt-3 space-y-2.5">
                    {detail.data.orders.map((order) => (
                      <li
                        key={order.id}
                        className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-white/8 bg-white/3 px-4 py-3"
                      >
                        <div className="min-w-0">
                          <p className="font-mono text-xs font-semibold text-primary">
                            {order.code}
                          </p>
                          <p className="mt-0.5 text-sm">
                            {order.serviceName} · {order.planName}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {formatDate(order.createdAt)}
                          </p>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="font-display text-sm font-bold">
                            {formatPrice(order.amountCents, order.currency)}
                          </span>
                          <span
                            className={cn(
                              "rounded-full border px-2.5 py-1 text-[0.65rem] font-semibold",
                              statusInfo(order.status).tone,
                            )}
                          >
                            {statusInfo(order.status).label}
                          </span>
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              <Link href="/panel/pedidos">
                <Button variant="outline" className="w-full gap-2 border-white/12 bg-white/4">
                  <Package className="h-4 w-4" />
                  Gestionar pedidos
                </Button>
              </Link>

              <div className="flex items-center justify-between gap-4 rounded-2xl border border-white/8 bg-white/3 p-4">
                <div>
                  <p className="text-sm font-semibold">Estado de la cuenta</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    {detail.data.customer.active
                      ? "Puede ingresar y comprar con normalidad."
                      : "Suspendida: no puede iniciar sesión."}
                  </p>
                </div>
                <Switch
                  checked={detail.data.customer.active}
                  disabled={setActive.isPending}
                  onCheckedChange={(value) =>
                    setActive.mutate({ id: detail.data!.customer.id, active: value })
                  }
                />
              </div>

              {/* Ayuda directa cuando el cliente no puede entrar. */}
              <div className="rounded-2xl border border-white/8 bg-white/3 p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="text-sm font-semibold">Restablecer la contraseña</p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      Usalo si el cliente no puede entrar. Solo el dueño puede hacerlo y queda
                      registrado en la bitácora.
                    </p>
                  </div>
                  <Button
                    variant="outline"
                    className="gap-2 border-white/12 bg-white/4"
                    onClick={() => {
                      setResetId(detail.data!.customer.id);
                      setResetPass("");
                    }}
                  >
                    <KeyRound className="h-4 w-4" />
                    Restablecer
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Restablecer la contraseña de un cliente */}
      <Dialog open={Boolean(resetId)} onOpenChange={(value) => !value && setResetId(null)}>
        <DialogContent className="border-white/10 bg-[oklch(0.17_0.014_18)]">
          <DialogHeader>
            <DialogTitle className="font-display text-lg font-bold">
              Restablecer la contraseña
            </DialogTitle>
            <DialogDescription className="text-sm text-muted-foreground">
              Escribí la contraseña nueva. El cliente entra con ella y puede cambiarla desde su
              cuenta cuando quiera.
            </DialogDescription>
          </DialogHeader>

          <form
            className="space-y-4"
            onSubmit={(event) => {
              event.preventDefault();
              if (resetId) resetPassword.mutate({ id: resetId, password: resetPass });
            }}
          >
            <div className="space-y-2">
              <Label htmlFor="reset-panel-password">Contraseña nueva</Label>
              <Input
                id="reset-panel-password"
                type="text"
                value={resetPass}
                onChange={(event) => setResetPass(event.target.value)}
                placeholder="Mínimo 8 caracteres"
                className="border-white/12 bg-white/4 font-mono"
              />
              <p className="text-xs text-muted-foreground">
                Se guarda cifrada: ni nosotros podemos verla de nuevo.
              </p>
            </div>

            <div className="flex gap-3">
              <Button
                type="button"
                variant="outline"
                className="flex-1 border-white/12 bg-white/4"
                onClick={() => setResetId(null)}
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                className="glow-ring flex-1 gap-2 font-semibold"
                disabled={resetPassword.isPending || resetPass.length < 8}
              >
                {resetPassword.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Guardando…
                  </>
                ) : (
                  <>
                    <KeyRound className="h-4 w-4" />
                    Guardar contraseña
                  </>
                )}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Invitar a un cliente nuevo */}
      <Dialog
        open={inviteOpen}
        onOpenChange={(value) => {
          setInviteOpen(value);
          if (!value) setManualCode(null);
        }}
      >
        <DialogContent className="border-white/10 bg-[oklch(0.17_0.014_18)]">
          <DialogHeader>
            <DialogTitle className="font-display text-lg font-bold">
              {manualCode ? "Código de invitación" : "Crear cuenta para un cliente"}
            </DialogTitle>
            <DialogDescription className="text-sm text-muted-foreground">
              {manualCode
                ? "El envío de correo todavía no está conectado. Pasale este código al cliente."
                : "Le enviamos un código por correo. La cuenta se activa cuando él elige su contraseña."}
            </DialogDescription>
          </DialogHeader>

          {manualCode ? (
            <div className="space-y-4">
              <div className="rounded-2xl border border-primary/30 bg-primary/8 p-5 text-center">
                <p className="font-mono text-3xl font-bold tracking-[0.25em] text-primary">
                  {manualCode}
                </p>
                <p className="mt-2 text-xs text-muted-foreground">
                  Vence en 15 minutos
                </p>
              </div>
              <Button
                className="w-full gap-2 font-semibold"
                onClick={() => {
                  navigator.clipboard?.writeText(manualCode);
                  toast.success("Código copiado");
                }}
              >
                <Copy className="h-4 w-4" />
                Copiar código
              </Button>
              <Button
                variant="outline"
                className="w-full border-white/12 bg-white/4"
                onClick={() => {
                  setManualCode(null);
                  setInviteOpen(false);
                }}
              >
                Listo
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="invite-name">Nombre del cliente *</Label>
                <Input
                  id="invite-name"
                  value={inviteName}
                  onChange={(event) => setInviteName(event.target.value)}
                  placeholder="Ej: Juan Pérez"
                  className="border-white/12 bg-white/4"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="invite-email">Correo electrónico *</Label>
                <Input
                  id="invite-email"
                  type="email"
                  value={inviteEmail}
                  onChange={(event) => setInviteEmail(event.target.value)}
                  placeholder="cliente@ejemplo.com"
                  className="border-white/12 bg-white/4"
                />
                <p className="text-xs text-muted-foreground">
                  Ahí le llega el código para activar su cuenta.
                </p>
              </div>
              <Button
                className="w-full gap-2 font-semibold"
                disabled={invite.isPending || inviteName.trim().length < 2 || !inviteEmail}
                onClick={() => invite.mutate({ name: inviteName, email: inviteEmail })}
              >
                {invite.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Send className="h-4 w-4" />
                )}
                Enviar invitación
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
