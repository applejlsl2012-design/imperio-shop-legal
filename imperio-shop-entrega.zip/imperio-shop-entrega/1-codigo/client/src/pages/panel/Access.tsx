import { PanelHeading, PanelLoading } from "@/components/panel/PanelLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { formatRelative } from "@/lib/format";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { Copy, KeyRound, Loader2, Plus, ShieldAlert, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function PanelAccess() {
  const utils = trpc.useUtils();
  const { data, isLoading } = trpc.admin.staff.list.useQuery(undefined, {
    refetchOnWindowFocus: false,
  });

  const [dialogOpen, setDialogOpen] = useState(false);
  const [label, setLabel] = useState("");
  const [role, setRole] = useState<"owner" | "staff">("staff");
  const [newCode, setNewCode] = useState<string | null>(null);

  const create = trpc.admin.staff.create.useMutation({
    onSuccess: async (result) => {
      await utils.admin.staff.list.invalidate();
      setNewCode(result.code);
      setLabel("");
      toast.success("Código generado", {
        description: "Copialo y compartilo con la persona correspondiente.",
      });
    },
    onError: (error) => toast.error("No se pudo crear", { description: error.message }),
  });

  const toggle = trpc.admin.staff.toggle.useMutation({
    onSuccess: async () => {
      await utils.admin.staff.list.invalidate();
    },
  });

  const remove = trpc.admin.staff.remove.useMutation({
    onSuccess: async () => {
      await utils.admin.staff.list.invalidate();
      toast.success("Código eliminado");
    },
    onError: (error) => toast.error("No se pudo eliminar", { description: error.message }),
  });

  if (isLoading) return <PanelLoading />;
  const codes = data ?? [];

  return (
    <div className="space-y-6">
      <PanelHeading
        title="Accesos del panel"
        description="Solo vos y tu socio deberían tener un código. Cada código es personal: podés desactivarlo o eliminarlo cuando quieras."
        action={
          <Button
            className="gap-2 font-semibold"
            onClick={() => {
              setNewCode(null);
              setDialogOpen(true);
            }}
          >
            <Plus className="h-4 w-4" />
            Nuevo acceso
          </Button>
        }
      />

      <Card className="surface flex items-start gap-3 rounded-2xl border-0 border-l-2 border-l-primary p-5">
        <ShieldAlert className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
        <div>
          <p className="text-sm font-semibold">Importante</p>
          <p className="mt-1 text-sm text-muted-foreground">
            Los códigos se guardan cifrados y solo se muestran una vez, al momento de
            crearlos. Si perdés uno, generá uno nuevo y eliminá el anterior.
          </p>
        </div>
      </Card>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {codes.map((code) => (
          <Card key={code.id} className="surface rounded-2xl border-0 p-5">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/12 text-primary">
                  <KeyRound className="h-4 w-4" />
                </span>
                <div>
                  <p className="text-sm font-semibold">{code.label}</p>
                  <p className="font-mono text-xs text-muted-foreground">{code.hint}</p>
                </div>
              </div>
              <Badge
                variant="outline"
                className={cn(
                  "text-[0.65rem]",
                  code.role === "owner"
                    ? "border-primary/40 text-primary"
                    : "border-white/15 text-muted-foreground",
                )}
              >
                {code.role === "owner" ? "Dueño" : "Socio"}
              </Badge>
            </div>

            <div className="mt-4 space-y-1.5 text-xs text-muted-foreground">
              <p>Usos: {code.useCount}</p>
              <p>
                Último ingreso:{" "}
                {code.lastUsedAt ? formatRelative(code.lastUsedAt) : "nunca"}
              </p>
            </div>

            <div className="mt-4 flex items-center justify-between gap-3 border-t border-white/8 pt-4">
              <div className="flex items-center gap-2">
                <Switch
                  checked={code.active}
                  onCheckedChange={(value) => toggle.mutate({ id: code.id, active: value })}
                />
                <span className="text-xs text-muted-foreground">
                  {code.active ? "Activo" : "Desactivado"}
                </span>
              </div>
              <Button
                size="sm"
                variant="outline"
                className="gap-1.5 border-destructive/30 bg-destructive/8 text-destructive"
                onClick={() => {
                  if (window.confirm(`¿Eliminar el acceso de "${code.label}"?`)) {
                    remove.mutate({ id: code.id });
                  }
                }}
              >
                <Trash2 className="h-3.5 w-3.5" />
                Eliminar
              </Button>
            </div>
          </Card>
        ))}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="border-white/10 bg-[oklch(0.17_0.014_18)]">
          <DialogHeader>
            <DialogTitle className="font-display text-lg font-bold">
              {newCode ? "Código generado" : "Nuevo acceso al panel"}
            </DialogTitle>
            <DialogDescription className="text-sm text-muted-foreground">
              {newCode
                ? "Guardá este código ahora: no se vuelve a mostrar."
                : "Creá un código personal para una persona de confianza."}
            </DialogDescription>
          </DialogHeader>

          {newCode ? (
            <div className="space-y-4">
              <div className="rounded-2xl border border-primary/30 bg-primary/8 p-5 text-center">
                <p className="font-mono text-2xl font-bold tracking-[0.18em] text-primary">
                  {newCode}
                </p>
              </div>
              <Button
                className="w-full gap-2 font-semibold"
                onClick={() => {
                  navigator.clipboard?.writeText(newCode);
                  toast.success("Código copiado");
                }}
              >
                <Copy className="h-4 w-4" />
                Copiar código
              </Button>
              <Button
                variant="outline"
                className="w-full border-white/12 bg-white/4"
                onClick={() => setDialogOpen(false)}
              >
                Listo
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="staff-label">Nombre de la persona *</Label>
                <Input
                  id="staff-label"
                  value={label}
                  onChange={(event) => setLabel(event.target.value)}
                  placeholder="Ej: Socio - Martín"
                  className="border-white/12 bg-white/4"
                />
              </div>
              <div className="space-y-2">
                <Label>Rol</Label>
                <Select value={role} onValueChange={(value) => setRole(value as "owner" | "staff")}>
                  <SelectTrigger className="border-white/12 bg-white/4">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="owner">Dueño</SelectItem>
                    <SelectItem value="staff">Socio</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button
                className="w-full gap-2 font-semibold"
                disabled={label.trim().length < 2 || create.isPending}
                onClick={() => create.mutate({ label, role })}
              >
                {create.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <KeyRound className="h-4 w-4" />
                )}
                Generar código
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
