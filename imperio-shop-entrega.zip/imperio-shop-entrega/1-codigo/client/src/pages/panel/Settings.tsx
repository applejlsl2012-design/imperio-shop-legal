import { PanelHeading, PanelLoading } from "@/components/panel/PanelLayout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import {
  CheckCircle2,
  CreditCard,
  Globe,
  Loader2,
  Mail,
  MessageCircle,
  Save,
  Send,
  Store,
  TrendingUp,
  TriangleAlert,
} from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

const FIELDS = [
  {
    group: "Identidad de la marca",
    icon: Store,
    items: [
      { key: "brand.name", label: "Nombre del negocio", type: "input" },
      { key: "brand.tagline", label: "Bajada / eslogan", type: "input" },
      { key: "brand.description", label: "Descripción para el pie de página", type: "textarea" },
    ],
  },
  {
    group: "Contacto",
    icon: MessageCircle,
    items: [
      { key: "contact.discord", label: "Enlace del servidor de Discord", type: "input" },
      { key: "contact.email", label: "Correo de ventas", type: "input" },
      { key: "contact.whatsapp", label: "Enlace de WhatsApp (opcional)", type: "input" },
    ],
  },
  {
    group: "Pagos (Tebex)",
    icon: CreditCard,
    items: [
      { key: "payment.provider", label: "Nombre del medio de pago (Tebex)", type: "input" },
      {
        key: "payment.methods",
        label: "Métodos visibles en la web (separados por coma)",
        type: "input",
      },
      { key: "payment.account", label: "Correo o cuenta que recibe el pago", type: "input" },
      { key: "payment.steps", label: "Pasos para pagar (se muestran al finalizar la compra)", type: "textarea" },
      { key: "payment.instructions", label: "Instrucciones adicionales", type: "textarea" },
      { key: "payment.qrUrl", label: "URL de un código QR de pago (opcional)", type: "input" },
    ],
  },
  {
    group: "Operación",
    icon: Globe,
    items: [
      { key: "orders.prefix", label: "Prefijo de los códigos de pedido", type: "input" },
      {
        key: "orders.ticketMessage",
        label: "Aviso al terminar la compra (usá {code} para el código del pedido)",
        type: "textarea",
      },
    ],
  },
  {
    group: "Números del inicio",
    icon: TrendingUp,
    items: [
      { key: "stats.uptime", label: "Disponibilidad (ej: 99.9%)", type: "input" },
      { key: "stats.uptimeLabel", label: "Texto de disponibilidad", type: "input" },
      { key: "stats.support", label: "Soporte (ej: 24/7)", type: "input" },
      { key: "stats.supportLabel", label: "Texto de soporte", type: "input" },
      {
        key: "stats.deliveredLabel",
        label: "Texto de entregas (el número sale de los pedidos entregados)",
        type: "input",
      },
    ],
  },
] as const;

/**
 * Estado del servicio de correo.
 *
 * Muestra por dónde salen los códigos de registro y de recuperación de
 * contraseña, y permite enviarse un correo de prueba para confirmar que
 * funcionan antes de que lo intente un cliente.
 */
function EmailStatusCard() {
  const { data, isLoading } = trpc.admin.settings.emailStatus.useQuery(undefined, {
    refetchOnWindowFocus: false,
  });
  const [destino, setDestino] = useState("");

  const prueba = trpc.admin.settings.emailTest.useMutation({
    onSuccess: (resultado) =>
      toast.success("Correo enviado", {
        description: `Salió por ${resultado.label}. Revisá la bandeja de entrada.`,
      }),
    onError: (error) => toast.error("No se pudo enviar", { description: error.message }),
  });

  const configurado = Boolean(data?.configured);

  return (
    <Card className="surface rounded-2xl border-0 p-6">
      <div className="flex items-start gap-3">
        <span
          className={cn(
            "flex h-9 w-9 shrink-0 items-center justify-center rounded-xl",
            configurado ? "bg-emerald-500/12 text-emerald-400" : "bg-amber-500/12 text-amber-400",
          )}
        >
          <Mail className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <h2 className="font-display text-base font-bold">Correo de la web</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Por acá salen los códigos que confirman una cuenta nueva y los que permiten
            recuperar una contraseña.
          </p>
        </div>
      </div>

      {isLoading ? (
        <div className="mt-4 h-20 animate-pulse rounded-xl bg-white/5" />
      ) : (
        <div
          className={cn(
            "mt-4 flex items-start gap-3 rounded-xl border p-4",
            configurado
              ? "border-emerald-500/25 bg-emerald-500/6"
              : "border-amber-500/25 bg-amber-500/6",
          )}
        >
          {configurado ? (
            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" />
          ) : (
            <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
          )}
          <div className="min-w-0 text-sm">
            <p className="font-semibold text-foreground">
              {configurado ? "Envío activo" : "Todavía sin configurar"}
            </p>
            <p className="mt-0.5 leading-relaxed text-muted-foreground">
              {configurado ? (
                <>
                  Los correos salen por <strong className="text-foreground">{data?.label}</strong>
                  {data?.from ? (
                    <>
                      {" "}
                      desde <strong className="text-foreground">{data.from}</strong>
                    </>
                  ) : null}
                  .
                </>
              ) : (
                <>
                  Mientras no haya un correo configurado, los códigos no llegan a la bandeja
                  y quedan a mano en <strong className="text-foreground">Clientes</strong>.
                  Cargá las credenciales y probá desde acá.
                </>
              )}
            </p>
          </div>
        </div>
      )}

      <div className="mt-4 space-y-2">
        <Label htmlFor="email-test">Enviar un correo de prueba</Label>
        <div className="flex flex-col gap-2 sm:flex-row">
          <Input
            id="email-test"
            type="email"
            placeholder="tucorreo@ejemplo.com"
            value={destino}
            onChange={(event) => setDestino(event.target.value)}
            className="border-white/12 bg-white/4"
          />
          <Button
            className="gap-2 font-semibold sm:w-auto"
            disabled={prueba.isPending || destino.trim().length < 5}
            onClick={() => prueba.mutate({ to: destino.trim() })}
          >
            {prueba.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Send className="h-4 w-4" />
            )}
            Probar
          </Button>
        </div>
        <p className="text-xs text-muted-foreground">
          Te llega un mensaje con el diseño real de los códigos. Si lo ves, el registro y la
          recuperación de contraseña van a funcionar.
        </p>
      </div>
    </Card>
  );
}

export default function PanelSettings() {
  const utils = trpc.useUtils();
  const { data, isLoading } = trpc.admin.settings.get.useQuery(undefined, {
    refetchOnWindowFocus: false,
  });
  const [values, setValues] = useState<Record<string, string>>({});

  useEffect(() => {
    if (data) setValues(data);
  }, [data]);

  const save = trpc.admin.settings.save.useMutation({
    onSuccess: async () => {
      await Promise.all([
        utils.admin.settings.get.invalidate(),
        utils.catalog.list.invalidate(),
        utils.catalog.extras.invalidate(),
      ]);
      toast.success("Configuración guardada");
    },
    onError: (error) => toast.error("No se pudo guardar", { description: error.message }),
  });

  if (isLoading) return <PanelLoading />;

  return (
    <div className="space-y-6">
      <PanelHeading
        title="Configuración"
        description="Datos de contacto, textos del sitio e información de pago. Estos valores se usan en toda la web."
        action={
          <Button
            className="gap-2 font-semibold"
            disabled={save.isPending}
            onClick={() => save.mutate({ entries: values })}
          >
            {save.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Save className="h-4 w-4" />
            )}
            Guardar cambios
          </Button>
        }
      />

      <div className="grid gap-6 xl:grid-cols-2">
        {FIELDS.map((group) => (
          <Card key={group.group} className="surface rounded-2xl border-0 p-6">
            <div className="flex items-center gap-2.5">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/12 text-primary">
                <group.icon className="h-4 w-4" />
              </span>
              <h2 className="font-display text-base font-bold">{group.group}</h2>
            </div>

            <div className="mt-5 space-y-4">
              {group.items.map((field) => (
                <div key={field.key} className="space-y-2">
                  <Label htmlFor={field.key}>{field.label}</Label>
                  {field.type === "textarea" ? (
                    <Textarea
                      id={field.key}
                      rows={4}
                      value={values[field.key] ?? ""}
                      onChange={(event) =>
                        setValues((prev) => ({ ...prev, [field.key]: event.target.value }))
                      }
                      className="border-white/12 bg-white/4"
                    />
                  ) : (
                    <Input
                      id={field.key}
                      value={values[field.key] ?? ""}
                      onChange={(event) =>
                        setValues((prev) => ({ ...prev, [field.key]: event.target.value }))
                      }
                      className="border-white/12 bg-white/4"
                    />
                  )}
                </div>
              ))}
            </div>
          </Card>
        ))}
      </div>

      <EmailStatusCard />

      <Card className="surface rounded-2xl border-0 p-6">
        <h2 className="font-display text-base font-bold">Cómo funciona el pago</h2>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
          Cuando un cliente compra, el sitio genera un código de pedido y lo lleva a la
          pantalla segura de <strong className="text-foreground">Tebex</strong>, donde
          paga con PayPal, tarjeta o el método que prefiera. La plata entra a tu cuenta de
          Tebex y el aviso de esta sección le indica al cliente que abra un ticket en
          Discord con su código. Seguí cada compra en{" "}
          <strong className="text-foreground">Pedidos</strong>: al marcar el pedido como{" "}
          <strong className="text-foreground">Pago confirmado</strong> pasa a producción y
          el cliente lo ve reflejado en el estado de su compra, dentro de su cuenta.
        </p>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
          Los botones que se ven en la web son los que Tebex tiene activados hoy:{" "}
          <strong className="text-foreground">tarjetas</strong> (Visa, Mastercard, JCB y
          American Express), <strong className="text-foreground">Google Pay</strong>,{" "}
          <strong className="text-foreground">PayPal</strong> y el{" "}
          <strong className="text-foreground">pago por ticket</strong> como respaldo. Si
          activás o desactivás un método en Tebex, cambiá esta lista con los mismos nombres
          separados por coma para que la web muestre exactamente lo que la pasarela acepta:
          escribí solo los que estén <strong className="text-foreground">activos</strong>.
        </p>
      </Card>
    </div>
  );
}
