import { PanelHeading, PanelLoading } from "@/components/panel/PanelLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { formatPrice } from "@/lib/format";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import {
  ChevronDown,
  Loader2,
  Pencil,
  Plus,
  Save,
  Star,
  Trash2,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

type PlanForm = {
  id?: number;
  serviceId: number;
  name: string;
  priceCents: number;
  currency: string;
  billing: "once" | "monthly";
  /** ID del paquete en Tebex. Vacío = se cobra de forma manual. */
  tebexPackageId: string;
  summary: string;
  specs: string;
  features: string;
  popular: boolean;
  stockLabel: string;
  sortOrder: number;
  active: boolean;
};

type ServiceForm = {
  id?: number;
  slug: string;
  name: string;
  tagline: string;
  description: string;
  imageUrl: string;
  icon: string;
  badge: string;
  accent: string;
  features: string;
  deliveryTime: string;
  sortOrder: number;
  active: boolean;
};

export default function PanelCatalog() {
  const utils = trpc.useUtils();
  const { data, isLoading } = trpc.admin.catalog.list.useQuery(undefined, {
    refetchOnWindowFocus: false,
  });

  const [serviceForm, setServiceForm] = useState<ServiceForm | null>(null);
  const [planForm, setPlanForm] = useState<PlanForm | null>(null);
  const [expanded, setExpanded] = useState<number | null>(null);

  const saveService = trpc.admin.catalog.saveService.useMutation({
    onSuccess: async () => {
      await utils.admin.catalog.invalidate();
      await utils.catalog.list.invalidate();
      setServiceForm(null);
      toast.success("Servicio guardado");
    },
    onError: (error) => toast.error("No se pudo guardar", { description: error.message }),
  });

  const savePlan = trpc.admin.catalog.savePlan.useMutation({
    onSuccess: async () => {
      await utils.admin.catalog.invalidate();
      await utils.catalog.list.invalidate();
      setPlanForm(null);
      toast.success("Plan guardado");
    },
    onError: (error) => toast.error("No se pudo guardar", { description: error.message }),
  });

  const removePlan = trpc.admin.catalog.deletePlan.useMutation({
    onSuccess: async () => {
      await utils.admin.catalog.invalidate();
      await utils.catalog.list.invalidate();
      toast.success("Plan eliminado");
    },
  });

  const removeService = trpc.admin.catalog.deleteService.useMutation({
    onSuccess: async () => {
      await utils.admin.catalog.invalidate();
      await utils.catalog.list.invalidate();
      toast.success("Servicio eliminado");
    },
  });

  if (isLoading) return <PanelLoading />;
  const services = data ?? [];

  return (
    <div className="space-y-6">
      <PanelHeading
        title="Catálogo"
        description="Editá los servicios, sus planes, precios y descripciones. Los cambios se ven al instante en el sitio público."
        action={
          <Button
            className="gap-2 font-semibold"
            onClick={() =>
              setServiceForm({
                slug: "",
                name: "",
                tagline: "",
                description: "",
                imageUrl: "",
                icon: "package",
                badge: "",
                accent: "#FF1F3D",
                features: "",
                deliveryTime: "",
                sortOrder: services.length + 1,
                active: true,
              })
            }
          >
            <Plus className="h-4 w-4" />
            Nuevo servicio
          </Button>
        }
      />

      <div className="space-y-4">
        {services.map((service) => {
          const isOpen = expanded === service.id;
          return (
            <Card key={service.id} className="surface overflow-hidden rounded-2xl border-0">
              <div className="flex flex-wrap items-center justify-between gap-4 p-5">
                <button
                  type="button"
                  onClick={() => setExpanded(isOpen ? null : service.id)}
                  className="flex min-w-0 flex-1 items-center gap-4 text-left"
                >
                  <ChevronDown
                    className={cn(
                      "h-4 w-4 shrink-0 text-muted-foreground transition-transform",
                      isOpen && "rotate-180",
                    )}
                  />
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="font-display text-base font-bold">{service.name}</p>
                      {!service.active && (
                        <Badge variant="outline" className="border-white/15 text-xs">
                          Oculto
                        </Badge>
                      )}
                      {service.badge && (
                        <Badge className="border-0 bg-primary/85 text-primary-foreground">
                          {service.badge}
                        </Badge>
                      )}
                    </div>
                    <p className="mt-1 truncate text-xs text-muted-foreground">
                      /{service.slug} · {service.plans.length} planes
                    </p>
                  </div>
                </button>

                <div className="flex shrink-0 items-center gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="gap-1.5 border-white/12 bg-white/4"
                    onClick={() =>
                      setServiceForm({
                        id: service.id,
                        slug: service.slug,
                        name: service.name,
                        tagline: service.tagline,
                        description: service.description,
                        imageUrl: service.imageUrl,
                        icon: service.icon,
                        badge: service.badge,
                        accent: service.accent,
                        features: service.features.join("\n"),
                        deliveryTime: service.deliveryTime,
                        sortOrder: service.sortOrder,
                        active: service.active,
                      })
                    }
                  >
                    <Pencil className="h-3.5 w-3.5" />
                    Editar
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="gap-1.5 border-destructive/30 bg-destructive/8 text-destructive"
                    onClick={() => {
                      if (
                        window.confirm(
                          `¿Eliminar "${service.name}" y todos sus planes? Esta acción no se puede deshacer.`,
                        )
                      ) {
                        removeService.mutate({ id: service.id });
                      }
                    }}
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>

              {isOpen && (
                <div className="border-t border-white/8 bg-white/2 p-5">
                  <div className="flex items-center justify-between">
                    <p className="font-display text-sm font-bold">Planes</p>
                    <Button
                      size="sm"
                      variant="outline"
                      className="gap-1.5 border-white/12 bg-white/4"
                      onClick={() =>
                        setPlanForm({
                          serviceId: service.id,
                          name: "",
                          priceCents: 1000,
                          currency: "USD",
                          billing: "once",
                          tebexPackageId: "",
                          summary: "",
                          specs: "",
                          features: "",
                          popular: false,
                          stockLabel: "Disponible",
                          sortOrder: service.plans.length + 1,
                          active: true,
                        })
                      }
                    >
                      <Plus className="h-3.5 w-3.5" />
                      Nuevo plan
                    </Button>
                  </div>

                  <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                    {service.plans.map((plan) => (
                      <div
                        key={plan.id}
                        className={cn(
                          "rounded-2xl border p-4",
                          plan.popular
                            ? "border-primary/40 bg-primary/8"
                            : "border-white/8 bg-white/3",
                        )}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <p className="flex items-center gap-1.5 truncate text-sm font-semibold">
                              {plan.popular && (
                                <Star className="h-3.5 w-3.5 fill-primary text-primary" />
                              )}
                              {plan.name}
                            </p>
                            <p className="mt-1 font-display text-lg font-extrabold">
                              {formatPrice(plan.priceCents, plan.currency)}
                              <span className="ml-1 text-xs font-medium text-muted-foreground">
                                {plan.billing === "monthly" ? "/ mes" : "único"}
                              </span>
                            </p>
                          </div>
                          {!plan.active && (
                            <Badge variant="outline" className="border-white/15 text-[0.65rem]">
                              Oculto
                            </Badge>
                          )}
                        </div>

                        <p className="mt-2 line-clamp-2 text-xs text-muted-foreground">
                          {plan.summary}
                        </p>

                        <div className="mt-3 flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            className="flex-1 gap-1.5 border-white/12 bg-white/4"
                            onClick={() =>
                              setPlanForm({
                                id: plan.id,
                                serviceId: service.id,
                                name: plan.name,
                                priceCents: plan.priceCents,
                                currency: plan.currency,
                                billing: plan.billing as "once" | "monthly",
                                tebexPackageId: plan.tebexPackageId
                                  ? String(plan.tebexPackageId)
                                  : "",
                                summary: plan.summary,
                                specs: plan.specs.join("\n"),
                                features: plan.features.join("\n"),
                                popular: plan.popular,
                                stockLabel: plan.stockLabel,
                                sortOrder: plan.sortOrder,
                                active: plan.active,
                              })
                            }
                          >
                            <Pencil className="h-3.5 w-3.5" />
                            Editar
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="gap-1.5 border-destructive/30 bg-destructive/8 text-destructive"
                            onClick={() => {
                              if (window.confirm(`¿Eliminar el plan "${plan.name}"?`)) {
                                removePlan.mutate({ id: plan.id });
                              }
                            }}
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </div>
                    ))}

                    {service.plans.length === 0 && (
                      <p className="rounded-2xl border border-dashed border-white/12 p-6 text-center text-sm text-muted-foreground md:col-span-2 xl:col-span-3">
                        Este servicio todavía no tiene planes cargados.
                      </p>
                    )}
                  </div>
                </div>
              )}
            </Card>
          );
        })}
      </div>

      {/* Diálogo de servicio */}
      <Dialog open={Boolean(serviceForm)} onOpenChange={(value) => !value && setServiceForm(null)}>
        <DialogContent className="max-h-[92vh] w-[95vw] max-w-2xl overflow-y-auto border-white/10 bg-[oklch(0.17_0.014_18)]">
          <DialogHeader>
            <DialogTitle className="font-display text-lg font-bold">
              {serviceForm?.id ? "Editar servicio" : "Nuevo servicio"}
            </DialogTitle>
            <DialogDescription className="text-sm text-muted-foreground">
              Los campos con * son obligatorios. Cada línea de la lista se convierte en un
              punto de la descripción.
            </DialogDescription>
          </DialogHeader>

          {serviceForm && (
            <div className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>Nombre *</Label>
                  <Input
                    value={serviceForm.name}
                    onChange={(event) =>
                      setServiceForm({ ...serviceForm, name: event.target.value })
                    }
                    className="border-white/12 bg-white/4"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Identificador (URL) *</Label>
                  <Input
                    value={serviceForm.slug}
                    onChange={(event) =>
                      setServiceForm({
                        ...serviceForm,
                        slug: event.target.value
                          .toLowerCase()
                          .replace(/[^a-z0-9-]/g, "-"),
                      })
                    }
                    placeholder="bots-discord"
                    className="border-white/12 bg-white/4"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Frase corta</Label>
                <Input
                  value={serviceForm.tagline}
                  onChange={(event) =>
                    setServiceForm({ ...serviceForm, tagline: event.target.value })
                  }
                  className="border-white/12 bg-white/4"
                />
              </div>

              <div className="space-y-2">
                <Label>Descripción</Label>
                <Textarea
                  rows={4}
                  value={serviceForm.description}
                  onChange={(event) =>
                    setServiceForm({ ...serviceForm, description: event.target.value })
                  }
                  className="border-white/12 bg-white/4"
                />
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>URL de la imagen</Label>
                  <Input
                    value={serviceForm.imageUrl}
                    onChange={(event) =>
                      setServiceForm({ ...serviceForm, imageUrl: event.target.value })
                    }
                    placeholder="/manus-storage/imagen.jpg"
                    className="border-white/12 bg-white/4"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Ícono</Label>
                  <Select
                    value={serviceForm.icon}
                    onValueChange={(value) => setServiceForm({ ...serviceForm, icon: value })}
                  >
                    <SelectTrigger className="border-white/12 bg-white/4">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {["bot", "server", "globe", "cpu", "lifebuoy", "cloud", "shield", "wrench", "sparkles", "package"].map(
                        (icon) => (
                          <SelectItem key={icon} value={icon}>
                            {icon}
                          </SelectItem>
                        ),
                      )}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-3">
                <div className="space-y-2">
                  <Label>Etiqueta destacada</Label>
                  <Input
                    value={serviceForm.badge}
                    onChange={(event) =>
                      setServiceForm({ ...serviceForm, badge: event.target.value })
                    }
                    placeholder="Más vendido"
                    className="border-white/12 bg-white/4"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Tiempo de entrega</Label>
                  <Input
                    value={serviceForm.deliveryTime}
                    onChange={(event) =>
                      setServiceForm({ ...serviceForm, deliveryTime: event.target.value })
                    }
                    placeholder="24 a 72 horas"
                    className="border-white/12 bg-white/4"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Orden</Label>
                  <Input
                    type="number"
                    value={serviceForm.sortOrder}
                    onChange={(event) =>
                      setServiceForm({
                        ...serviceForm,
                        sortOrder: Number(event.target.value) || 0,
                      })
                    }
                    className="border-white/12 bg-white/4"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Características (una por línea)</Label>
                <Textarea
                  rows={4}
                  value={serviceForm.features}
                  onChange={(event) =>
                    setServiceForm({ ...serviceForm, features: event.target.value })
                  }
                  className="border-white/12 bg-white/4"
                />
              </div>

              <div className="flex items-center gap-3 rounded-2xl border border-white/8 bg-white/3 p-4">
                <Switch
                  checked={serviceForm.active}
                  onCheckedChange={(value) =>
                    setServiceForm({ ...serviceForm, active: value })
                  }
                />
                <div>
                  <p className="text-sm font-medium">Visible en el sitio</p>
                  <p className="text-xs text-muted-foreground">
                    Si lo desactivás, deja de mostrarse en el catálogo público.
                  </p>
                </div>
              </div>

              <Button
                className="w-full gap-2 font-semibold"
                disabled={saveService.isPending}
                onClick={() =>
                  saveService.mutate({
                    id: serviceForm.id,
                    slug: serviceForm.slug,
                    name: serviceForm.name,
                    tagline: serviceForm.tagline,
                    description: serviceForm.description,
                    imageUrl: serviceForm.imageUrl,
                    icon: serviceForm.icon,
                    badge: serviceForm.badge,
                    accent: serviceForm.accent,
                    features: splitLines(serviceForm.features),
                    deliveryTime: serviceForm.deliveryTime,
                    sortOrder: serviceForm.sortOrder,
                    active: serviceForm.active,
                  })
                }
              >
                {saveService.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Save className="h-4 w-4" />
                )}
                Guardar servicio
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Diálogo de plan */}
      <Dialog open={Boolean(planForm)} onOpenChange={(value) => !value && setPlanForm(null)}>
        <DialogContent className="max-h-[92vh] w-[95vw] max-w-2xl overflow-y-auto border-white/10 bg-[oklch(0.17_0.014_18)]">
          <DialogHeader>
            <DialogTitle className="font-display text-lg font-bold">
              {planForm?.id ? "Editar plan" : "Nuevo plan"}
            </DialogTitle>
            <DialogDescription className="text-sm text-muted-foreground">
              El precio se ingresa en centavos de dólar: 3500 equivale a US$ 35.
            </DialogDescription>
          </DialogHeader>

          {planForm && (
            <div className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>Nombre del plan *</Label>
                  <Input
                    value={planForm.name}
                    onChange={(event) => setPlanForm({ ...planForm, name: event.target.value })}
                    className="border-white/12 bg-white/4"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Precio (centavos) *</Label>
                  <Input
                    type="number"
                    value={planForm.priceCents}
                    onChange={(event) =>
                      setPlanForm({ ...planForm, priceCents: Number(event.target.value) || 0 })
                    }
                    className="border-white/12 bg-white/4"
                  />
                  <p className="text-xs text-muted-foreground">
                    Se mostrará como {formatPrice(planForm.priceCents, planForm.currency)}
                  </p>
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-3">
                <div className="space-y-2">
                  <Label>Cobro</Label>
                  <Select
                    value={planForm.billing}
                    onValueChange={(value) =>
                      setPlanForm({ ...planForm, billing: value as "once" | "monthly" })
                    }
                  >
                    <SelectTrigger className="border-white/12 bg-white/4">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="once">Pago único</SelectItem>
                      <SelectItem value="monthly">Mensual</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Moneda</Label>
                  <Input
                    value={planForm.currency}
                    onChange={(event) =>
                      setPlanForm({ ...planForm, currency: event.target.value.toUpperCase() })
                    }
                    className="border-white/12 bg-white/4"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Orden</Label>
                  <Input
                    type="number"
                    value={planForm.sortOrder}
                    onChange={(event) =>
                      setPlanForm({ ...planForm, sortOrder: Number(event.target.value) || 0 })
                    }
                    className="border-white/12 bg-white/4"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Resumen corto</Label>
                <Input
                  value={planForm.summary}
                  onChange={(event) => setPlanForm({ ...planForm, summary: event.target.value })}
                  className="border-white/12 bg-white/4"
                />
              </div>

              <div className="space-y-2">
                <Label>Especificaciones (una por línea)</Label>
                <Textarea
                  rows={5}
                  value={planForm.specs}
                  onChange={(event) => setPlanForm({ ...planForm, specs: event.target.value })}
                  className="border-white/12 bg-white/4"
                />
              </div>

              <div className="space-y-2">
                <Label>Extras incluidos (uno por línea)</Label>
                <Textarea
                  rows={3}
                  value={planForm.features}
                  onChange={(event) => setPlanForm({ ...planForm, features: event.target.value })}
                  className="border-white/12 bg-white/4"
                />
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>Etiqueta de disponibilidad</Label>
                  <Input
                    value={planForm.stockLabel}
                    onChange={(event) =>
                      setPlanForm({ ...planForm, stockLabel: event.target.value })
                    }
                    className="border-white/12 bg-white/4"
                  />
                </div>
                <div className="flex items-center gap-3 rounded-2xl border border-white/8 bg-white/3 px-4 py-3">
                  <Switch
                    checked={planForm.popular}
                    onCheckedChange={(value) => setPlanForm({ ...planForm, popular: value })}
                  />
                  <span className="text-sm font-medium">Marcar como más elegido</span>
                </div>
              </div>

              <div className="space-y-2 rounded-2xl border border-white/8 bg-white/3 p-4">
                <Label>Paquete de Tebex</Label>
                <Input
                  value={planForm.tebexPackageId}
                  onChange={(event) =>
                    setPlanForm({
                      ...planForm,
                      tebexPackageId: event.target.value.replace(/[^0-9]/g, ""),
                    })
                  }
                  placeholder="Ej: 6543210"
                  className="border-white/12 bg-white/4"
                />
                <p className="text-xs text-muted-foreground">
                  ID del paquete en Tebex (Panel de Tebex → Packages). Si lo completás, el
                  cliente paga con PayPal, tarjeta o cualquier método de Tebex y el pedido
                  se marca como pagado solo. Si lo dejás vacío, el cobro queda manual.
                </p>
              </div>

              <div className="flex items-center gap-3 rounded-2xl border border-white/8 bg-white/3 p-4">
                <Switch
                  checked={planForm.active}
                  onCheckedChange={(value) => setPlanForm({ ...planForm, active: value })}
                />
                <div>
                  <p className="text-sm font-medium">Plan activo</p>
                  <p className="text-xs text-muted-foreground">
                    Si lo desactivás, no se puede comprar desde el sitio.
                  </p>
                </div>
              </div>

              <Button
                className="w-full gap-2 font-semibold"
                disabled={savePlan.isPending}
                onClick={() =>
                  savePlan.mutate({
                    id: planForm.id,
                    serviceId: planForm.serviceId,
                    name: planForm.name,
                    priceCents: planForm.priceCents,
                    currency: planForm.currency,
                    billing: planForm.billing,
                    tebexPackageId: planForm.tebexPackageId
                      ? Number.parseInt(planForm.tebexPackageId, 10)
                      : undefined,
                    summary: planForm.summary,
                    specs: splitLines(planForm.specs),
                    features: splitLines(planForm.features),
                    popular: planForm.popular,
                    stockLabel: planForm.stockLabel,
                    sortOrder: planForm.sortOrder,
                    active: planForm.active,
                  })
                }
              >
                {savePlan.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Save className="h-4 w-4" />
                )}
                Guardar plan
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function splitLines(value: string): string[] {
  return value
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean);
}
