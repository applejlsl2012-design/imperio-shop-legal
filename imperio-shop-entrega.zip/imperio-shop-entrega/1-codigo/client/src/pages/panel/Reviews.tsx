import { PanelHeading, PanelLoading } from "@/components/panel/PanelLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import {
  Check,
  Loader2,
  MessageSquareReply,
  Sparkles,
  Star,
  Trash2,
  X,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

type ReviewStatus = "pending" | "approved" | "rejected";

const FILTERS: { value: ReviewStatus | "all"; label: string }[] = [
  { value: "pending", label: "Por revisar" },
  { value: "approved", label: "Publicadas" },
  { value: "rejected", label: "Descartadas" },
  { value: "all", label: "Todas" },
];

const STATUS_STYLE: Record<ReviewStatus, string> = {
  pending: "border-amber-500/30 bg-amber-500/12 text-amber-300",
  approved: "border-emerald-500/30 bg-emerald-500/12 text-emerald-300",
  rejected: "border-white/15 bg-white/6 text-muted-foreground",
};

const STATUS_LABEL: Record<ReviewStatus, string> = {
  pending: "Por revisar",
  approved: "Publicada",
  rejected: "Descartada",
};

function Stars({ rating }: { rating: number }) {
  return (
    <span className="flex items-center gap-0.5">
      {Array.from({ length: 5 }).map((_, index) => (
        <Star
          key={index}
          className={cn(
            "h-3.5 w-3.5",
            index < rating ? "fill-primary text-primary" : "text-white/20",
          )}
        />
      ))}
    </span>
  );
}

export default function PanelReviews() {
  const utils = trpc.useUtils();
  const [filter, setFilter] = useState<ReviewStatus | "all">("pending");
  const [replyTo, setReplyTo] = useState<number | null>(null);
  const [replyText, setReplyText] = useState("");

  const { data, isLoading } = trpc.admin.reviews.list.useQuery(
    filter === "all" ? undefined : { status: filter },
    { refetchOnWindowFocus: false },
  );

  const refresh = async () => {
    await utils.admin.reviews.list.invalidate();
  };

  const setStatus = trpc.admin.reviews.setStatus.useMutation({
    onSuccess: async (_result, variables) => {
      await refresh();
      const messages: Record<ReviewStatus, string> = {
        approved: "Reseña publicada en el sitio",
        rejected: "Reseña descartada",
        pending: "Reseña devuelta a revisión",
      };
      toast.success(messages[variables.status]);
    },
    onError: (error) => toast.error("No se pudo actualizar", { description: error.message }),
  });

  const setFeatured = trpc.admin.reviews.setFeatured.useMutation({
    onSuccess: async () => {
      await refresh();
      toast.success("Destacado actualizado");
    },
    onError: (error) => toast.error("No se pudo actualizar", { description: error.message }),
  });

  const setReply = trpc.admin.reviews.setReply.useMutation({
    onSuccess: async () => {
      await refresh();
      setReplyTo(null);
      setReplyText("");
      toast.success("Respuesta guardada");
    },
    onError: (error) => toast.error("No se pudo guardar", { description: error.message }),
  });

  const remove = trpc.admin.reviews.remove.useMutation({
    onSuccess: async () => {
      await refresh();
      toast.success("Reseña eliminada");
    },
    onError: (error) => toast.error("No se pudo eliminar", { description: error.message }),
  });

  if (isLoading) return <PanelLoading />;

  const stats = data?.stats;
  const reviews = data?.reviews ?? [];

  return (
    <div className="space-y-6">
      <PanelHeading
        title="Reseñas"
        description="Las reseñas de los clientes llegan acá para que las revises antes de publicarlas en el sitio."
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="surface rounded-2xl border-0 p-5">
          <p className="text-xs uppercase tracking-[0.14em] text-muted-foreground">
            Por revisar
          </p>
          <p className="mt-2 font-display text-3xl font-extrabold">{stats?.pending ?? 0}</p>
        </Card>
        <Card className="surface rounded-2xl border-0 p-5">
          <p className="text-xs uppercase tracking-[0.14em] text-muted-foreground">
            Publicadas
          </p>
          <p className="mt-2 font-display text-3xl font-extrabold text-emerald-300">
            {stats?.approved ?? 0}
          </p>
        </Card>
        <Card className="surface rounded-2xl border-0 p-5">
          <p className="text-xs uppercase tracking-[0.14em] text-muted-foreground">
            Descartadas
          </p>
          <p className="mt-2 font-display text-3xl font-extrabold">
            {stats?.rejected ?? 0}
          </p>
        </Card>
        <Card className="surface rounded-2xl border-0 p-5">
          <p className="text-xs uppercase tracking-[0.14em] text-muted-foreground">
            Promedio publicado
          </p>
          <p className="mt-2 flex items-baseline gap-2 font-display text-3xl font-extrabold">
            {(stats?.average ?? 0).toFixed(1)}
            <Star className="h-4 w-4 fill-primary text-primary" />
          </p>
        </Card>
      </div>

      <div className="flex flex-wrap gap-2">
        {FILTERS.map((item) => (
          <Button
            key={item.value}
            size="sm"
            variant={filter === item.value ? "default" : "outline"}
            className={cn(
              "font-semibold",
              filter !== item.value && "border-white/12 bg-white/4",
            )}
            onClick={() => setFilter(item.value)}
          >
            {item.label}
          </Button>
        ))}
      </div>

      {reviews.length === 0 ? (
        <Card className="surface rounded-2xl border-0 p-10 text-center">
          <p className="font-display text-lg font-bold">No hay reseñas en esta vista</p>
          <p className="mt-2 text-sm text-muted-foreground">
            Cuando un cliente deje su reseña, la vas a ver acá para aprobarla.
          </p>
        </Card>
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {reviews.map((review) => (
            <Card key={review.id} className="surface rounded-2xl border-0 p-5">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="font-semibold">{review.author}</p>
                  <p className="text-xs text-muted-foreground">{review.email}</p>
                </div>
                <span
                  className={cn(
                    "rounded-full border px-2.5 py-1 text-[0.65rem] font-semibold uppercase tracking-wide",
                    STATUS_STYLE[review.status as ReviewStatus],
                  )}
                >
                  {STATUS_LABEL[review.status as ReviewStatus]}
                </span>
              </div>

              <div className="mt-3 flex items-center gap-2">
                <Stars rating={review.rating} />
                {review.serviceName && (
                  <Badge variant="outline" className="border-white/12 bg-white/4 text-xs">
                    {review.serviceName}
                  </Badge>
                )}
                {review.featured && (
                  <Badge className="gap-1 bg-primary/15 text-primary">
                    <Sparkles className="h-3 w-3" />
                    Destacada
                  </Badge>
                )}
              </div>

              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                "{review.comment}"
              </p>

              {review.reply && (
                <div className="mt-3 rounded-xl border border-white/8 bg-white/4 p-3">
                  <p className="text-xs font-semibold text-primary">Tu respuesta</p>
                  <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                    {review.reply}
                  </p>
                </div>
              )}

              <div className="mt-4 flex flex-wrap gap-2 border-t border-white/8 pt-4">
                {review.status !== "approved" && (
                  <Button
                    size="sm"
                    className="gap-1.5 font-semibold"
                    disabled={setStatus.isPending}
                    onClick={() => setStatus.mutate({ id: review.id, status: "approved" })}
                  >
                    <Check className="h-3.5 w-3.5" />
                    Publicar
                  </Button>
                )}
                {review.status !== "rejected" && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="gap-1.5 border-white/12 bg-white/4 font-semibold"
                    disabled={setStatus.isPending}
                    onClick={() => setStatus.mutate({ id: review.id, status: "rejected" })}
                  >
                    <X className="h-3.5 w-3.5" />
                    Descartar
                  </Button>
                )}
                {review.status === "approved" && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="gap-1.5 border-white/12 bg-white/4 font-semibold"
                    disabled={setFeatured.isPending}
                    onClick={() =>
                      setFeatured.mutate({ id: review.id, featured: !review.featured })
                    }
                  >
                    <Sparkles className="h-3.5 w-3.5" />
                    {review.featured ? "Quitar destaque" : "Destacar"}
                  </Button>
                )}
                <Button
                  size="sm"
                  variant="outline"
                  className="gap-1.5 border-white/12 bg-white/4 font-semibold"
                  onClick={() => {
                    setReplyTo(review.id);
                    setReplyText(review.reply ?? "");
                  }}
                >
                  <MessageSquareReply className="h-3.5 w-3.5" />
                  Responder
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="gap-1.5 border-white/12 bg-white/4 font-semibold text-muted-foreground hover:text-foreground"
                  disabled={remove.isPending}
                  onClick={() => {
                    if (confirm("¿Eliminar esta reseña definitivamente?")) {
                      remove.mutate({ id: review.id });
                    }
                  }}
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  Eliminar
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={replyTo !== null} onOpenChange={(open) => !open && setReplyTo(null)}>
        <DialogContent className="border-white/10 bg-[oklch(0.16_0.014_18)] sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="font-display">Responder la reseña</DialogTitle>
            <DialogDescription>
              Tu respuesta se muestra públicamente debajo de la reseña del cliente.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Label htmlFor="review-reply">Respuesta</Label>
            <Textarea
              id="review-reply"
              rows={4}
              maxLength={600}
              value={replyText}
              onChange={(event) => setReplyText(event.target.value)}
              placeholder="¡Gracias por la confianza! Cualquier cosa escribinos por Discord."
              className="border-white/12 bg-white/4"
            />
          </div>
          <DialogFooter>
            <Button
              className="w-full gap-2 font-semibold"
              disabled={setReply.isPending}
              onClick={() => {
                if (replyTo === null) return;
                setReply.mutate({ id: replyTo, reply: replyText });
              }}
            >
              {setReply.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
              Guardar respuesta
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
