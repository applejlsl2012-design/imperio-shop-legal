import { PanelHeading, PanelLoading } from "@/components/panel/PanelLayout";
import { Card } from "@/components/ui/card";
import { formatPrice, formatRelative, statusInfo } from "@/lib/format";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import {
  ArrowRight,
  AlertTriangle,
  CheckCircle2,
  Clock,
  DollarSign,
  LogIn,
  Package,
  TrendingUp,
  UserCheck,
} from "lucide-react";
import { Link } from "wouter";

export default function PanelOverview() {
  const { data, isLoading } = trpc.admin.overview.useQuery(undefined, {
    refetchOnWindowFocus: false,
  });
  // Estado real del cobro: dice si la tienda ya puede recibir dinero.
  const cobro = trpc.orders.tebexStatus.useQuery(undefined, {
    refetchOnWindowFocus: false,
    staleTime: 120_000,
  });

  if (isLoading) return <PanelLoading />;
  if (!data) return null;

  const { stats, recentOrders, logins } = data;

  const cards = [
    {
      label: "Facturación confirmada",
      value: formatPrice(stats.revenueCents),
      hint: "Pedidos pagados, en producción y entregados",
      icon: DollarSign,
      tone: "text-emerald-300 bg-emerald-500/12",
    },
    {
      label: "Pedidos totales",
      value: String(stats.total),
      hint: `${stats.last30} en los últimos 30 días`,
      icon: Package,
      tone: "text-primary bg-primary/12",
    },
    {
      label: "Por verificar",
      value: String(stats.pending + stats.review),
      hint: `${stats.pending} sin pagar · ${stats.review} en revisión`,
      icon: Clock,
      tone: "text-amber-300 bg-amber-500/12",
    },
    {
      label: "En producción",
      value: String(stats.inProgress),
      hint: `${stats.delivered} entregados`,
      icon: TrendingUp,
      tone: "text-sky-300 bg-sky-500/12",
    },
  ];

  return (
    <div className="space-y-8">
      <PanelHeading
        title="Resumen"
        description="Estado general de la tienda: ventas, pedidos pendientes y actividad del equipo."
      />

      {/*
        Aviso del cobro en línea. Mientras la tienda de pagos no esté
        habilitada, el dinero no puede entrar por la web: conviene verlo de
        entrada y no descubrirlo cuando un cliente intenta pagar.
      */}
      {cobro.data && !cobro.data.canCharge && (
        <Card className="surface flex items-start gap-3 rounded-2xl border-0 border-l-2 border-l-amber-400 p-5">
          <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-amber-300" />
          <div>
            <p className="text-sm font-semibold">
              El cobro en línea todavía no está habilitado
            </p>
            <p className="mt-1 text-sm text-muted-foreground">
              {cobro.data.platform
                ? `La tienda de pagos está configurada como ${cobro.data.platform}${cobro.data.disabled ? " y figura deshabilitada" : ""}. `
                : ""}
              Hasta habilitarlo, los pedidos se coordinan por Discord con el código
              del cliente. Los pedidos y las pruebas funcionan igual.
            </p>
          </div>
        </Card>
      )}

      {/*
        La tienda está conectada pero en modo de prueba: se puede recorrer todo
        el circuito de compra, pero Tebex todavía no cobra de verdad. Conviene
        distinguirlo del cobro real para no confundir una prueba con una venta.
      */}
      {cobro.data?.canCharge && cobro.data.testMode && (
        <Card className="surface flex items-start gap-3 rounded-2xl border-0 border-l-2 border-l-sky-400 p-5">
          <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-sky-300" />
          <div>
            <p className="text-sm font-semibold">
              El cobro está conectado en modo de prueba
            </p>
            <p className="mt-1 text-sm text-muted-foreground">
              {cobro.data.platform
                ? `La tienda de pagos está configurada como ${cobro.data.platform} y todavía no fue aprobada por Tebex. `
                : ""}
              El circuito completo funciona —el cliente elige su método, paga en
              Tebex y el pedido se confirma solo—, pero Tebex no descuenta dinero
              real. Cuando aprueben la tienda, el cobro pasa a ser real sin
              cambiar nada del sitio.
            </p>
          </div>
        </Card>
      )}

      {cobro.data?.canCharge && !cobro.data.testMode && (
        <Card className="surface flex items-start gap-3 rounded-2xl border-0 border-l-2 border-l-emerald-400 p-5">
          <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-emerald-300" />
          <div>
            <p className="text-sm font-semibold">El cobro en línea está activo</p>
            <p className="mt-1 text-sm text-muted-foreground">
              La tienda de pagos puede recibir dinero y los pedidos se confirman solos
              cuando el pago se acredita.
            </p>
          </div>
        </Card>
      )}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {cards.map((card) => (
          <Card key={card.label} className="surface rounded-2xl border-0 p-5">
            <div className="flex items-start justify-between">
              <span
                className={cn(
                  "flex h-10 w-10 items-center justify-center rounded-xl",
                  card.tone,
                )}
              >
                <card.icon className="h-5 w-5" />
              </span>
            </div>
            <p className="mt-4 font-display text-2xl font-extrabold">{card.value}</p>
            <p className="mt-1 text-sm font-medium">{card.label}</p>
            <p className="mt-1 text-xs text-muted-foreground">{card.hint}</p>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.5fr_1fr]">
        <Card className="surface rounded-2xl border-0 p-6">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-bold">Últimos pedidos</h2>
            <Link
              href="/panel/pedidos"
              className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"
            >
              Ver todos
              <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </div>

          {recentOrders.length === 0 ? (
            <p className="mt-6 rounded-xl border border-white/8 bg-white/3 p-6 text-center text-sm text-muted-foreground">
              Todavía no hay pedidos. Cuando un cliente compre vas a verlo acá.
            </p>
          ) : (
            <div className="mt-4 space-y-3">
              {recentOrders.map((order) => {
                const info = statusInfo(order.status);
                return (
                  <Link
                    key={order.id}
                    href={`/panel/pedidos?focus=${order.id}`}
                    className="flex items-center justify-between gap-4 rounded-xl border border-white/8 bg-white/3 p-4 transition-colors hover:border-primary/30"
                  >
                    <div className="min-w-0">
                      <p className="font-mono text-sm font-semibold text-primary">
                        {order.code}
                      </p>
                      <p className="mt-0.5 truncate text-sm">
                        {order.serviceName} · {order.planName}
                      </p>
                      <p className="mt-0.5 truncate text-xs text-muted-foreground">
                        {order.customerName} · {formatRelative(order.createdAt)}
                      </p>
                    </div>
                    <div className="flex shrink-0 flex-col items-end gap-2">
                      <span className="font-display text-sm font-bold">
                        {formatPrice(order.amountCents, order.currency)}
                      </span>
                      <span
                        className={cn(
                          "rounded-full border px-2.5 py-1 text-[0.65rem] font-semibold",
                          info.tone,
                        )}
                      >
                        {info.label}
                      </span>
                    </div>
                  </Link>
                );
              })}
            </div>
          )}
        </Card>

        <Card className="surface rounded-2xl border-0 p-6">
          <div className="flex items-center gap-2">
            <UserCheck className="h-4 w-4 text-primary" />
            <h2 className="font-display text-lg font-bold">Actividad de accesos</h2>
          </div>
          <p className="mt-1.5 text-xs text-muted-foreground">
            Quién entró al panel y cuándo.
          </p>

          {logins.length === 0 ? (
            <p className="mt-6 rounded-xl border border-white/8 bg-white/3 p-6 text-center text-sm text-muted-foreground">
              Sin registros todavía.
            </p>
          ) : (
            <ul className="mt-4 space-y-3">
              {logins.map((entry, index) => (
                <li
                  key={index}
                  className="flex items-center justify-between gap-3 rounded-xl border border-white/8 bg-white/3 px-4 py-3"
                >
                  <span className="flex items-center gap-2.5">
                    <LogIn
                      className={cn(
                        "h-4 w-4",
                        entry.success ? "text-emerald-300" : "text-destructive",
                      )}
                    />
                    <span className="text-sm font-medium">{entry.label}</span>
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {formatRelative(entry.createdAt)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </div>
  );
}
