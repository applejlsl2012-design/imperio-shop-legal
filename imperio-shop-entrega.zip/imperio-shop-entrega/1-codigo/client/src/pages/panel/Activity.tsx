import { PanelHeading, PanelLoading } from "@/components/panel/PanelLayout";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { formatRelative } from "@/lib/format";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import {
  Activity as ActivityIcon,
  Eye,
  Globe,
  MessageSquare,
  Search,
  ShoppingBag,
  Star,
  UserPlus,
} from "lucide-react";
import { useEffect, useState } from "react";

/** Aspecto de cada tipo de movimiento en la bitácora. */
const KINDS: Record<
  string,
  { label: string; icon: typeof Eye; tone: string }
> = {
  visita: { label: "Visitas", icon: Eye, tone: "border-white/15 text-muted-foreground" },
  "cuenta.creada": {
    label: "Cuentas",
    icon: UserPlus,
    tone: "border-sky-400/40 text-sky-300",
  },
  "cuenta.confirmada": {
    label: "Cuentas",
    icon: UserPlus,
    tone: "border-sky-400/40 text-sky-300",
  },
  "cuenta.invitada": {
    label: "Invitaciones",
    icon: UserPlus,
    tone: "border-violet-400/40 text-violet-300",
  },
  "cuenta.activada": {
    label: "Invitaciones",
    icon: UserPlus,
    tone: "border-violet-400/40 text-violet-300",
  },
  "cuenta.ingreso": {
    label: "Ingresos",
    icon: Globe,
    tone: "border-emerald-400/40 text-emerald-300",
  },
  "pedido.nuevo": {
    label: "Pedidos",
    icon: ShoppingBag,
    tone: "border-primary/50 text-primary",
  },
  "pedido.actualizado": {
    label: "Pedidos",
    icon: ShoppingBag,
    tone: "border-primary/50 text-primary",
  },
  "resena.nueva": { label: "Reseñas", icon: Star, tone: "border-amber-400/40 text-amber-300" },
  "resena.moderada": {
    label: "Reseñas",
    icon: Star,
    tone: "border-amber-400/40 text-amber-300",
  },
  "catalogo.consultado": {
    label: "Catálogo",
    icon: MessageSquare,
    tone: "border-white/15 text-muted-foreground",
  },
  "config.actualizada": {
    label: "Configuración",
    icon: ActivityIcon,
    tone: "border-white/15 text-muted-foreground",
  },
};

const FILTERS = [
  { value: "all", label: "Todo" },
  { value: "visita", label: "Visitas" },
  { value: "cuenta.confirmada", label: "Cuentas nuevas" },
  { value: "cuenta.ingreso", label: "Ingresos" },
  { value: "pedido.nuevo", label: "Pedidos" },
  { value: "resena.nueva", label: "Reseñas" },
];

function kindInfo(kind: string) {
  return (
    KINDS[kind] ?? {
      label: kind,
      icon: ActivityIcon,
      tone: "border-white/15 text-muted-foreground",
    }
  );
}

export default function PanelActivity() {
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [debounced, setDebounced] = useState("");

  useEffect(() => {
    const timer = setTimeout(() => setDebounced(search), 320);
    return () => clearTimeout(timer);
  }, [search]);

  const feed = trpc.admin.customers.activity.useQuery(
    { kind: filter, limit: 120 },
    { refetchOnWindowFocus: false },
  );

  const stats = feed.data?.stats;
  const rows = (feed.data?.activity ?? []).filter((row) => {
    if (!debounced.trim()) return true;
    const needle = debounced.trim().toLowerCase();
    return (
      row.title.toLowerCase().includes(needle) ||
      row.detail.toLowerCase().includes(needle) ||
      row.actorEmail.toLowerCase().includes(needle)
    );
  });

  return (
    <div className="space-y-6">
      <PanelHeading
        title="Actividad de la web"
        description="Todo lo que pasa en el sitio público queda registrado acá: visitas, cuentas, compras y reseñas."
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          { label: "Movimientos (7 días)", value: stats?.total ?? 0, icon: ActivityIcon },
          { label: "Hoy", value: stats?.today ?? 0, icon: Eye },
          { label: "Cuentas nuevas", value: stats?.signups ?? 0, icon: UserPlus },
          { label: "Pedidos", value: stats?.orders ?? 0, icon: ShoppingBag },
        ].map((item) => (
          <Card key={item.label} className="surface rounded-2xl border-0 p-5">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/12 text-primary">
              <item.icon className="h-4 w-4" />
            </span>
            <p className="mt-3 font-display text-xl font-extrabold">{item.value}</p>
            <p className="text-xs text-muted-foreground">{item.label}</p>
          </Card>
        ))}
      </div>

      <Card className="surface rounded-2xl border-0 p-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Buscar por persona, correo o detalle…"
              className="border-white/12 bg-white/4 pl-9"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {FILTERS.map((item) => (
              <button
                key={item.value}
                type="button"
                onClick={() => setFilter(item.value)}
                className={cn(
                  "rounded-full border px-3 py-1.5 text-xs font-medium transition-colors",
                  filter === item.value
                    ? "border-primary/50 bg-primary/12 text-primary"
                    : "border-white/12 bg-white/4 text-muted-foreground hover:text-foreground",
                )}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </Card>

      {feed.isLoading ? (
        <PanelLoading />
      ) : rows.length === 0 ? (
        <Card className="surface rounded-2xl border-0 p-10 text-center">
          <ActivityIcon className="mx-auto h-8 w-8 text-muted-foreground" />
          <p className="mt-3 font-display text-lg font-bold">
            {debounced || filter !== "all" ? "Sin resultados" : "Todavía no hay movimientos"}
          </p>
          <p className="mt-2 text-sm text-muted-foreground">
            {debounced || filter !== "all"
              ? "Probá con otro filtro o término de búsqueda."
              : "Cuando alguien visite el sitio, cree su cuenta o compre, aparece acá."}
          </p>
        </Card>
      ) : (
        <Card className="surface overflow-hidden rounded-2xl border-0">
          <ul className="divide-y divide-white/6">
            {rows.map((row) => {
              const info = kindInfo(row.kind);
              const Icon = info.icon;
              return (
                <li
                  key={row.id}
                  className="flex flex-wrap items-start gap-4 px-5 py-4 transition-colors hover:bg-white/3"
                >
                  <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-white/5 text-muted-foreground">
                    <Icon className="h-4 w-4" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-sm font-medium">{row.title}</p>
                      <Badge
                        variant="outline"
                        className={cn("text-[0.62rem]", info.tone)}
                      >
                        {info.label}
                      </Badge>
                    </div>
                    {row.detail && (
                      <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                        {row.detail}
                      </p>
                    )}
                    <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[0.68rem] text-muted-foreground">
                      {row.actorEmail && <span>{row.actorEmail}</span>}
                      {row.ip && <span className="font-mono">{row.ip}</span>}
                    </div>
                  </div>
                  <span className="shrink-0 text-xs text-muted-foreground">
                    {formatRelative(row.createdAt)}
                  </span>
                </li>
              );
            })}
          </ul>
        </Card>
      )}
    </div>
  );
}