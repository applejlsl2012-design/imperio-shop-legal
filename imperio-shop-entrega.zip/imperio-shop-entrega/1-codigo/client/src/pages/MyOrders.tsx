import { ImperioMark } from "@/components/brand/ImperioLogo";
import { SiteLayout } from "@/components/site/SiteLayout";
import { PaymentVerification } from "@/components/site/PaymentVerification";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDate, formatPrice, statusInfo } from "@/lib/format";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import {
  ArrowRight,
  LogOut,
  MessageCircle,
  Package,
  Receipt,
  Settings,
  ShoppingBag,
  Star,
  Ticket,
  TrendingUp,
  User,
} from "lucide-react";
import { useEffect, useState } from "react";
import { Link, useLocation, useSearch } from "wouter";
import { toast } from "sonner";

export default function MyOrders() {
  const [, setLocation] = useLocation();
  const search = useSearch();
  const utils = trpc.useUtils();

  // Al volver del checkout de Tebex llega `?pago=ok&pedido=IMP-XXXXXX`.
  // En ese caso verificamos el pago antes de mostrar el historial.
  const params = new URLSearchParams(search);
  const pedidoPendiente = params.get("pedido") ?? "";
  // Si el pedido volvió sin pago confirmado, puede haber quedado esperando
  // que el cliente se identifique en Tebex: reintentamos el checkout solo.
  const reanudar = params.get("reanudar") === "1";
  // Volvió del pago: corresponde verificar si el dinero llegó de verdad.
  const pagoOk = params.get("pago") === "ok";
  const [verificando, setVerificando] = useState(pagoOk && Boolean(pedidoPendiente));

  const session = trpc.customer.me.useQuery(undefined, {
    retry: false,
    refetchOnWindowFocus: false,
  });
  const orders = trpc.customer.orders.useQuery(undefined, {
    enabled: Boolean(session.data?.authenticated),
    refetchOnWindowFocus: false,
  });
  // Ajustes del sitio: enlace de Discord y aviso para abrir el ticket.
  const extras = trpc.catalog.extras.useQuery(undefined, { staleTime: 60_000 });
  const discordLink = extras.data?.settings["contact.discord"] ?? "";
  const ticketTemplate =
    extras.data?.settings["orders.ticketMessage"] ??
    "Abrí un ticket en nuestro Discord con tu código de pedido {code} y te atendemos al toque para crear tu bot, activar tu hosting o arrancar con tu página web.";

  const logout = trpc.customer.logout.useMutation({
    onSuccess: async () => {
      await utils.customer.me.invalidate();
      toast.success("Cerraste sesión");
      setLocation("/");
    },
  });

  // Sin sesión: invitamos a entrar.
  useEffect(() => {
    if (!session.isLoading && !session.data?.authenticated) {
      setLocation("/cuenta");
    }
  }, [session.isLoading, session.data, setLocation]);

  // Retoma el pago: vuelve a armar la canasta y, si ya no exige login,
  // manda al cliente directo a la pantalla de pago de Tebex.
  const resume = trpc.orders.resumeTebex.useMutation({
    onSuccess: (data) => {
      if (data.ok && data.checkoutUrl) {
        window.location.href = data.checkoutUrl;
        return;
      }
      if (data.authUrl) {
        window.location.href = data.authUrl;
        return;
      }
      toast.error("No pudimos retomar el pago", { description: data.message });
    },
    onError: (error) => toast.error(error.message),
  });

  // Se dispara una sola vez, solo si volvimos con la marca de reanudar.
  const [reanudado, setReanudado] = useState(false);
  useEffect(() => {
    if (!reanudar || reanudado || !pedidoPendiente) return;
    if (session.isLoading || !session.data?.authenticated) return;
    setReanudado(true);
    resume.mutate({ code: pedidoPendiente });
  }, [reanudar, reanudado, pedidoPendiente, session.isLoading, session.data, resume]);

  if (session.isLoading || !session.data?.authenticated) {
    return (
      <SiteLayout>
        <section className="container max-w-4xl py-16">
          <Skeleton className="h-40 rounded-3xl" />
        </section>
      </SiteLayout>
    );
  }

  const customer = session.data.customer;
  const rows = orders.data ?? [];
  const spentCents = rows
    .filter((order) => ["paid", "in_progress", "delivered"].includes(order.status))
    .reduce((total, order) => total + order.amountCents, 0);
  const activeCount = rows.filter((order) =>
    ["paid", "in_progress", "payment_review"].includes(order.status),
  ).length;

  return (
    <SiteLayout>
      <section className="container max-w-5xl py-12 lg:py-16">
        {/* Encabezado del perfil */}
        <Card className="surface relative overflow-hidden rounded-3xl border-0 p-6 sm:p-8">
          <div
            className="pointer-events-none absolute -right-20 -top-20 h-56 w-56 rounded-full bg-primary/18 blur-3xl"
            aria-hidden
          />
          <div className="relative flex flex-wrap items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/12">
                <ImperioMark size={30} glow />
              </span>
              <div>
                <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
                  Mi cuenta
                </p>
                <h1 className="mt-1 font-display text-2xl font-extrabold">{customer.name}</h1>
                <p className="text-sm text-muted-foreground">{customer.email}</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <Link href="/#servicios">
                <Button className="gap-2 font-semibold">
                  <ShoppingBag className="h-4 w-4" />
                  Comprar un servicio
                </Button>
              </Link>
              <Link href="/resenas">
                <Button
                  variant="outline"
                  className="gap-2 border-white/12 bg-white/4"
                >
                  <Star className="h-4 w-4" />
                  Dejar mi reseña
                </Button>
              </Link>
              <Button
                variant="outline"
                className="gap-2 border-white/12 bg-white/4"
                onClick={() => logout.mutate()}
                disabled={logout.isPending}
              >
                <LogOut className="h-4 w-4" />
                Cerrar sesión
              </Button>
            </div>
          </div>

          <div className="relative mt-7 grid gap-4 sm:grid-cols-3">
            {[
              { label: "Compras totales", value: String(rows.length), icon: Package },
              { label: "Servicios activos", value: String(activeCount), icon: TrendingUp },
              {
                label: "Total invertido",
                value: formatPrice(spentCents, "USD"),
                icon: Receipt,
              },
            ].map((item) => (
              <div
                key={item.label}
                className="rounded-2xl border border-white/8 bg-white/3 p-4"
              >
                <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/12 text-primary">
                  <item.icon className="h-4 w-4" />
                </span>
                <p className="mt-3 font-display text-xl font-extrabold">{item.value}</p>
                <p className="text-xs text-muted-foreground">{item.label}</p>
              </div>
            ))}
          </div>
        </Card>

        {/* Verificación del pago al volver del checkout de Tebex */}
        {verificando && pedidoPendiente && (
          <div className="mt-6">
            <PaymentVerification
              orderCode={pedidoPendiente}
              onFinished={() => {
                setVerificando(false);
                utils.customer.orders.invalidate();
                setLocation("/mis-compras", { replace: true });
              }}
            />
          </div>
        )}

        <div className="mt-8 grid gap-6 lg:grid-cols-[1.6fr_1fr]">
          {/* Historial de compras */}
          <div>
            <h2 className="font-display text-lg font-bold">Mis compras</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Todo lo que compraste queda registrado acá con su estado actualizado.
            </p>

            {orders.isLoading ? (
              <div className="mt-5 space-y-3">
                {Array.from({ length: 3 }).map((_, index) => (
                  <Skeleton key={index} className="h-24 rounded-2xl" />
                ))}
              </div>
            ) : rows.length === 0 ? (
              <Card className="surface mt-5 rounded-2xl border-0 p-8 text-center">
                <Package className="mx-auto h-8 w-8 text-muted-foreground" />
                <p className="mt-3 font-display text-base font-bold">
                  Todavía no tenés compras
                </p>
                <p className="mt-1.5 text-sm text-muted-foreground">
                  Cuando compres tu primer servicio, aparece acá con su código y el estado
                  actualizado.
                </p>
                <Link href="/#servicios">
                  <Button className="mt-5 gap-2 font-semibold">
                    Ver servicios
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
              </Card>
            ) : (
              <div className="mt-5 space-y-3">
                {rows.map((order) => {
                  const info = statusInfo(order.status);
                  return (
                    <Card
                      key={order.id}
                      className="surface rounded-2xl border-0 p-5 transition-colors hover:border-primary/25"
                    >
                      <div className="flex flex-wrap items-start justify-between gap-4">
                        <div className="min-w-0">
                          <p className="font-mono text-xs font-semibold tracking-wider text-primary">
                            {order.code}
                          </p>
                          <p className="mt-1 font-display text-base font-bold">
                            {order.serviceName}
                          </p>
                          <p className="text-sm text-muted-foreground">{order.planName}</p>
                        </div>
                        <div className="flex flex-col items-end gap-2">
                          <p className="font-display text-base font-extrabold">
                            {formatPrice(order.amountCents, order.currency)}
                            {order.billing === "monthly" && (
                              <span className="ml-1 text-xs font-medium text-muted-foreground">
                                / mes
                              </span>
                            )}
                          </p>
                          <span
                            className={cn(
                              "rounded-full border px-2.5 py-1 text-[0.65rem] font-semibold",
                              info.tone,
                            )}
                          >
                            {info.label}
                          </span>
                        </div>
                      </div>
                      <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-white/8 pt-3.5">
                        <p className="text-xs text-muted-foreground">
                          Comprado el {formatDate(order.createdAt)}
                        </p>
                        <span className="rounded-full border border-white/12 bg-white/4 px-3 py-1 font-mono text-xs tracking-wider text-muted-foreground">
                          {order.code}
                        </span>
                      </div>

                      {/* Recordatorio: sin el ticket no arranca la entrega. */}
                      <div className="mt-3.5 flex flex-wrap items-center gap-3 rounded-xl border border-primary/25 bg-primary/8 px-3.5 py-3">
                        <div className="flex min-w-0 flex-1 items-start gap-2.5">
                          <Ticket className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                          <p className="text-xs leading-relaxed text-muted-foreground">
                            {ticketTemplate.replace("{code}", order.code)}
                          </p>
                        </div>
                        {discordLink && (
                          <a
                            href={discordLink}
                            target="_blank"
                            rel="noreferrer"
                            className="shrink-0"
                          >
                            <Button size="sm" className="gap-1.5 text-xs font-semibold">
                              <MessageCircle className="h-3.5 w-3.5" />
                              Abrir ticket
                            </Button>
                          </a>
                        )}
                      </div>
                    </Card>
                  );
                })}
              </div>
            )}
          </div>

          {/* Datos del perfil */}
          <div>
            <h2 className="font-display text-lg font-bold">Mis datos</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Los usamos para entregarte los servicios.
            </p>
            <ProfileCard
              name={customer.name}
              discord={customer.discord}
              email={customer.email}
              onSaved={() => utils.customer.me.invalidate()}
            />
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}

function ProfileCard({
  name,
  discord,
  email,
  onSaved,
}: {
  name: string;
  discord: string;
  email: string;
  onSaved: () => void;
}) {
  const [values, setValues] = useState({ name, discord });
  const utils = trpc.useUtils();

  const save = trpc.customer.updateProfile.useMutation({
    onSuccess: async () => {
      await utils.customer.me.invalidate();
      onSaved();
      toast.success("Datos actualizados");
    },
    onError: (error) => toast.error(error.message),
  });

  return (
    <Card className="surface mt-5 rounded-2xl border-0 p-5">
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="profile-name" className="flex items-center gap-2">
            <User className="h-3.5 w-3.5" />
            Nombre
          </Label>
          <Input
            id="profile-name"
            value={values.name}
            onChange={(event) => setValues({ ...values, name: event.target.value })}
            className="border-white/12 bg-white/4"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="profile-discord">Usuario de Discord</Label>
          <Input
            id="profile-discord"
            value={values.discord}
            onChange={(event) => setValues({ ...values, discord: event.target.value })}
            placeholder="@usuario"
            className="border-white/12 bg-white/4"
          />
        </div>
        <div className="space-y-2">
          <Label className="flex items-center gap-2">
            <Settings className="h-3.5 w-3.5" />
            Correo
          </Label>
          <Input value={email} disabled className="border-white/12 bg-white/4 opacity-70" />
        </div>
        <Button
          variant="outline"
          className="w-full gap-2 border-white/12 bg-white/4"
          disabled={save.isPending}
          onClick={() => save.mutate(values)}
        >
          Guardar cambios
        </Button>
      </div>
    </Card>
  );
}
