import { ImperioMark } from "@/components/brand/ImperioLogo";
import { DiscordIcon } from "@/components/brand/DiscordIcon";
import { SiteLayout } from "@/components/site/SiteLayout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import {
  AlertCircle,
  ArrowRight,
  Check,
  Loader2,
  Lock,
  Mail,
  MessageCircle,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  User,
} from "lucide-react";
import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";

const PENDING_PLAN_KEY = "imperio-pending-plan";

export default function Account() {
  const [, setLocation] = useLocation();
  const [tab, setTab] = useState<"login" | "register" | "invite">("login");

  const session = trpc.customer.me.useQuery(undefined, {
    retry: false,
    refetchOnWindowFocus: true,
  });

  // Si la invitación vino por enlace, abrimos esa pestaña y precargamos el correo.
  const [inviteEmail, setInviteEmail] = useState("");
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const invitar = params.get("invitacion");
    const correo = params.get("correo");
    if (invitar === "1") {
      setTab("invite");
      if (correo) setInviteEmail(correo);
      window.history.replaceState({}, "", window.location.pathname);
    }
  }, []);

  // Si el portal devolvió un error, avisamos al cliente.
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const error = params.get("error");
    if (!error) return;
    const messages: Record<string, string> = {
      "sin-correo":
        "Tu cuenta de Google o Apple no compartió un correo. Entrá con tu correo y contraseña.",
      "cuenta-inactiva": "Tu cuenta está desactivada. Escribinos por Discord.",
      oauth: "No pudimos completar el ingreso. Probá de nuevo o usá tu correo.",
    };
    toast.error(messages[error] ?? "No pudimos completar el ingreso.");
    window.history.replaceState({}, "", window.location.pathname);
  }, []);

  // Si ya hay sesión, mandamos a donde el cliente quería ir.
  useEffect(() => {
    if (session.data?.authenticated) {
      const pending = sessionStorage.getItem(PENDING_PLAN_KEY);
      if (pending) {
        sessionStorage.removeItem(PENDING_PLAN_KEY);
        setLocation(pending);
      } else {
        setLocation("/mis-compras");
      }
    }
  }, [session.data, setLocation]);

  return (
    <SiteLayout>
      <section className="container max-w-5xl py-14 lg:py-20">
        <div className="grid items-start gap-10 lg:grid-cols-[1fr_1.05fr]">
          {/* Columna informativa */}
          <div className="lg:sticky lg:top-24">
            <span className="inline-flex items-center gap-2 rounded-full border border-primary/25 bg-primary/8 px-3.5 py-1.5 text-xs font-semibold uppercase tracking-[0.18em] text-primary">
              <ShieldCheck className="h-3.5 w-3.5" />
              Cuenta de cliente
            </span>
            <h1 className="mt-6 font-display text-3xl font-extrabold leading-tight sm:text-4xl">
              Tu cuenta imperial,{" "}
              <span className="text-gradient-ember">todo en un solo lugar.</span>
            </h1>
            <p className="mt-4 max-w-lg text-base leading-relaxed text-muted-foreground">
              Con tu cuenta comprás más rápido, seguís el estado de cada servicio y dejás tu
              reseña cuando lo recibís. Cada compra queda registrada a tu nombre.
            </p>

            <ul className="mt-8 space-y-4">
              {[
                {
                  icon: Check,
                  title: "Confirmás tu correo",
                  text: "Te enviamos un código de 6 dígitos para verificar que el correo es tuyo.",
                },
                {
                  icon: MessageCircle,
                  title: "Compras a tu nombre",
                  text: "Cada pedido queda vinculado a tu perfil y a tu Discord.",
                },
                {
                  icon: Sparkles,
                  title: "Reseñas y soporte",
                  text: "Dejá tu opinión de lo que compraste y seguí tus entregas.",
                },
              ].map((item) => (
                <li key={item.title} className="flex gap-3.5">
                  <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-primary/12 text-primary">
                    <item.icon className="h-4 w-4" />
                  </span>
                  <div>
                    <p className="text-sm font-semibold">{item.title}</p>
                    <p className="text-sm text-muted-foreground">{item.text}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>

          {/* Formularios */}
          <Card className="surface rounded-3xl border-0 p-6 sm:p-8">
            <Tabs
              value={tab}
              onValueChange={(value) => setTab(value as "login" | "register" | "invite")}
            >
              <TabsList className="grid w-full grid-cols-3 bg-white/5">
                <TabsTrigger value="login">Ingresar</TabsTrigger>
                <TabsTrigger value="register">Crear cuenta</TabsTrigger>
                <TabsTrigger value="invite">Tengo invitación</TabsTrigger>
              </TabsList>

              <TabsContent value="login" className="mt-6">
                <LoginForm onDone={() => setLocation("/mis-compras")} />
              </TabsContent>

              <TabsContent value="register" className="mt-6">
                <RegisterForm />
              </TabsContent>

              <TabsContent value="invite" className="mt-6">
                <InviteForm initialEmail={inviteEmail} />
              </TabsContent>
            </Tabs>
          </Card>
        </div>
      </section>
    </SiteLayout>
  );
}

/* -------------------------------------------------------------------------- */

function LoginForm({ onDone }: { onDone: () => void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [olvido, setOlvido] = useState(false);
  const utils = trpc.useUtils();

  const login = trpc.customer.login.useMutation({
    onSuccess: async (data) => {
      await utils.customer.me.invalidate();
      toast.success(`¡Hola de nuevo, ${data.customer.name}!`);
      onDone();
    },
    onError: (error) => toast.error(error.message),
  });

  // Modo recuperación: pide el código y después la contraseña nueva.
  if (olvido) {
    return <ResetPasswordForm initialEmail={email} onBack={() => setOlvido(false)} />;
  }

  return (
    <form
      className="space-y-4"
      onSubmit={(event) => {
        event.preventDefault();
        login.mutate({ email, password });
      }}
    >
      <div className="space-y-2">
        <Label htmlFor="login-email">Correo electrónico</Label>
        <Input
          id="login-email"
          type="email"
          autoComplete="email"
          value={email}
          onChange={(event) => setEmail(event.target.value)}
          placeholder="tucorreo@ejemplo.com"
          className="border-white/12 bg-white/4"
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="login-password">Contraseña</Label>
        <Input
          id="login-password"
          type="password"
          autoComplete="current-password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          placeholder="Tu contraseña"
          className="border-white/12 bg-white/4"
        />
      </div>

      <div className="flex justify-end">
        <button
          type="button"
          className="text-xs font-medium text-primary hover:underline"
          onClick={() => setOlvido(true)}
        >
          ¿Olvidaste tu contraseña?
        </button>
      </div>

      {login.error && <FormError message={login.error.message} />}

      <Button
        type="submit"
        className="glow-ring w-full gap-2 font-semibold"
        disabled={login.isPending || !email || password.length < 8}
      >
        {login.isPending ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin" />
            Ingresando…
          </>
        ) : (
          <>
            <Lock className="h-4 w-4" />
            Iniciar sesión
          </>
        )}
      </Button>
    </form>
  );
}

/**
 * Recuperar la contraseña cuando no se acuerda.
 *
 * Dos pasos: pide el código al correo y, con ese código, elige la contraseña
 * nueva. Si el correo todavía no está activado en el sitio, el mensaje lo dice
 * con claridad en vez de dejar a la persona esperando un código que no llega.
 */
function ResetPasswordForm({
  initialEmail,
  onBack,
}: {
  initialEmail: string;
  onBack: () => void;
}) {
  const [step, setStep] = useState<"pedir" | "cambiar">("pedir");
  const [email, setEmail] = useState(initialEmail);
  const [code, setCode] = useState("");
  const [password, setPassword] = useState("");
  const utils = trpc.useUtils();
  const [, setLocation] = useLocation();

  const pedir = trpc.customer.requestPasswordReset.useMutation({
    onSuccess: (data) => {
      setStep("cambiar");
      if (data.sent) {
        toast.success("Te enviamos un código", {
          description: `Revisá ${email}, incluso la carpeta de spam.`,
          duration: 10000,
        });
      } else {
        toast.warning("El correo todavía no está activado", {
          description: "Escribinos por Soporte y te habilitamos el acceso al instante.",
          duration: 12000,
        });
      }
    },
    onError: (error) => toast.error(error.message),
  });

  const cambiar = trpc.customer.resetPassword.useMutation({
    onSuccess: async (data) => {
      await utils.customer.me.invalidate();
      toast.success(`Listo, ${data.customer.name}: ya podés comprar con tu cuenta.`);
      setLocation("/mis-compras");
    },
    onError: (error) => toast.error(error.message),
  });

  if (step === "pedir") {
    return (
      <form
        className="space-y-4"
        onSubmit={(event) => {
          event.preventDefault();
          pedir.mutate({ email });
        }}
      >
        <div className="flex items-start gap-2.5 rounded-2xl border border-primary/25 bg-primary/8 p-3.5">
          <Mail className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
          <p className="text-sm text-muted-foreground">
            Escribí el correo de tu cuenta y te mandamos un código para elegir una contraseña
            nueva. Nadie más puede cambiarla sin ese código.
          </p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="reset-email">Correo electrónico</Label>
          <Input
            id="reset-email"
            type="email"
            autoComplete="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            placeholder="tucorreo@ejemplo.com"
            className="border-white/12 bg-white/4"
          />
        </div>

        {pedir.error && <FormError message={pedir.error.message} />}

        <Button
          type="submit"
          className="glow-ring w-full gap-2 font-semibold"
          disabled={pedir.isPending || !email}
        >
          {pedir.isPending ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Enviando código…
            </>
          ) : (
            <>
              Enviarme el código
              <ArrowRight className="h-4 w-4" />
            </>
          )}
        </Button>

        <button
          type="button"
          className="w-full text-center text-xs text-muted-foreground hover:text-foreground"
          onClick={onBack}
        >
          Volver al inicio de sesión
        </button>
      </form>
    );
  }

  return (
    <form
      className="space-y-4"
      onSubmit={(event) => {
        event.preventDefault();
        cambiar.mutate({ email, code, password });
      }}
    >
      <div className="flex items-start gap-2.5 rounded-2xl border border-primary/25 bg-primary/8 p-3.5">
        <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
        <p className="text-sm text-muted-foreground">
          Escribí el código que enviamos a <span className="font-medium">{email}</span> y elegí
          tu contraseña nueva. Si no te llegó, revisá la carpeta de spam o pedí otro código.
        </p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="reset-code">Código recibido</Label>
        <Input
          id="reset-code"
          inputMode="numeric"
          autoComplete="one-time-code"
          value={code}
          onChange={(event) => setCode(event.target.value.replace(/\D/g, "").slice(0, 6))}
          placeholder="6 dígitos"
          className="border-white/12 bg-white/4 font-mono tracking-[0.3em]"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="reset-password">Contraseña nueva</Label>
        <Input
          id="reset-password"
          type="password"
          autoComplete="new-password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          placeholder="Mínimo 8 caracteres"
          className="border-white/12 bg-white/4"
        />
      </div>

      {cambiar.error && <FormError message={cambiar.error.message} />}

      <Button
        type="submit"
        className="glow-ring w-full gap-2 font-semibold"
        disabled={cambiar.isPending || code.length !== 6 || password.length < 8}
      >
        {cambiar.isPending ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin" />
            Guardando…
          </>
        ) : (
          <>
            <Lock className="h-4 w-4" />
            Cambiar mi contraseña
          </>
        )}
      </Button>

      <div className="flex flex-col items-center gap-2 text-xs text-muted-foreground">
        <button
          type="button"
          className="inline-flex items-center gap-1.5 text-primary hover:underline disabled:opacity-60"
          onClick={() => pedir.mutate({ email })}
          disabled={pedir.isPending}
        >
          <RefreshCw className={cn("h-3.5 w-3.5", pedir.isPending && "animate-spin")} />
          Pedir otro código
        </button>
        <button type="button" className="hover:text-foreground" onClick={onBack}>
          Volver al inicio de sesión
        </button>
      </div>
    </form>
  );
}

/**
 * Registro en dos pasos: primero los datos y la contraseña, después el código
 * que llega al correo. La cuenta se crea recién cuando el código es correcto.
 */
function RegisterForm() {
  const [step, setStep] = useState<"datos" | "codigo">("datos");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [discord, setDiscord] = useState("");
  const [password, setPassword] = useState("");
  const [code, setCode] = useState("");
  const utils = trpc.useUtils();
  const [, setLocation] = useLocation();

  const goToAccount = async () => {
    await utils.customer.me.invalidate();
    const pending = sessionStorage.getItem(PENDING_PLAN_KEY);
    if (pending) {
      sessionStorage.removeItem(PENDING_PLAN_KEY);
      setLocation(pending);
    } else {
      setLocation("/mis-compras");
    }
  };

  const register = trpc.customer.register.useMutation({
    onSuccess: (data) => {
      setStep("codigo");
      toast.success("Te enviamos un código", {
        description:
          data.delivery.mode === "email"
            ? `Revisá ${data.email}, incluso la carpeta de spam.`
            : "El correo todavía no está conectado: pedile el código al equipo por Discord.",
        duration: 10000,
      });
    },
    onError: (error) => toast.error(error.message),
  });

  const verify = trpc.customer.verifySignup.useMutation({
    onSuccess: async (data) => {
      toast.success(`¡Cuenta creada, ${data.customer.name}!`);
      await goToAccount();
    },
    onError: (error) => toast.error(error.message),
  });

  const strength = passwordStrength(password);

  if (step === "codigo") {
    return (
      <CodeStep
        email={email}
        code={code}
        setCode={setCode}
        pending={verify.isPending}
        error={verify.error?.message}
        onConfirm={() => verify.mutate({ email, code })}
        onBack={() => setStep("datos")}
        onResend={() => register.mutate({ name, email, password, discord })}
        resending={register.isPending}
        title="Confirmá tu correo"
        description={`Escribí el código de 6 dígitos que enviamos a ${email}. Si no te llega, avisá en nuestro Discord: el equipo habilita tu cuenta y entrás directo con tu correo y contraseña.`}
      />
    );
  }

  return (
    <form
      className="space-y-4"
      onSubmit={(event) => {
        event.preventDefault();
        register.mutate({ name, email, password, discord });
      }}
    >
      <div className="space-y-2">
        <Label htmlFor="reg-name">Nombre y apellido</Label>
        <div className="relative">
          <User className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            id="reg-name"
            value={name}
            onChange={(event) => setName(event.target.value)}
            placeholder="Ej: Juan Pérez"
            className="border-white/12 bg-white/4 pl-9"
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="reg-email">Correo electrónico</Label>
        <div className="relative">
          <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            id="reg-email"
            type="email"
            autoComplete="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            placeholder="tucorreo@ejemplo.com"
            className="border-white/12 bg-white/4 pl-9"
          />
        </div>
        <p className="text-xs text-muted-foreground">
          A este correo te llega el código para activar la cuenta.
        </p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="reg-discord">Usuario de Discord (opcional)</Label>
        <div className="relative">
          <DiscordIcon className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#8b95f7]" />
          <Input
            id="reg-discord"
            value={discord}
            onChange={(event) => setDiscord(event.target.value)}
            placeholder="@usuario"
            className="border-white/12 bg-white/4 pl-9"
          />
        </div>
        <p className="text-xs text-muted-foreground">
          Lo usamos para entregarte los servicios y avisarte por Discord.
        </p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="reg-password">Contraseña</Label>
        <Input
          id="reg-password"
          type="password"
          autoComplete="new-password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          placeholder="Mínimo 8 caracteres"
          className="border-white/12 bg-white/4"
        />
        {password.length > 0 && (
          <div className="flex items-center gap-2">
            <div className="flex h-1.5 flex-1 gap-1">
              {[0, 1, 2].map((index) => (
                <span
                  key={index}
                  className={cn(
                    "h-full flex-1 rounded-full transition-colors",
                    index < strength.score
                      ? strength.score === 1
                        ? "bg-destructive"
                        : strength.score === 2
                          ? "bg-amber-400"
                          : "bg-emerald-400"
                      : "bg-white/10",
                  )}
                />
              ))}
            </div>
            <span className="text-xs text-muted-foreground">{strength.label}</span>
          </div>
        )}
      </div>

      {register.error && <FormError message={register.error.message} />}

      <Button
        type="submit"
        className="glow-ring w-full gap-2 font-semibold"
        disabled={register.isPending || name.length < 2 || !email || password.length < 8}
      >
        {register.isPending ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin" />
            Enviando código…
          </>
        ) : (
          <>
            Enviar código de verificación
            <ArrowRight className="h-4 w-4" />
          </>
        )}
      </Button>

      <p className="text-center text-xs text-muted-foreground">
        Te enviamos un código para confirmar tu correo y después creamos la cuenta.
      </p>
    </form>
  );
}

/** Activación de una cuenta invitada por el equipo desde el panel. */
function InviteForm({ initialEmail }: { initialEmail: string }) {
  const [email, setEmail] = useState(initialEmail);
  const [code, setCode] = useState("");
  const [password, setPassword] = useState("");
  const [discord, setDiscord] = useState("");
  const utils = trpc.useUtils();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (initialEmail) setEmail(initialEmail);
  }, [initialEmail]);

  const activate = trpc.customer.activateInvite.useMutation({
    onSuccess: async (data) => {
      await utils.customer.me.invalidate();
      toast.success(`¡Cuenta activada, ${data.customer.name}!`);
      const pending = sessionStorage.getItem(PENDING_PLAN_KEY);
      if (pending) {
        sessionStorage.removeItem(PENDING_PLAN_KEY);
        setLocation(pending);
      } else {
        setLocation("/mis-compras");
      }
    },
    onError: (error) => toast.error(error.message),
  });

  return (
    <form
      className="space-y-4"
      onSubmit={(event) => {
        event.preventDefault();
        activate.mutate({ email, code, password, discord });
      }}
    >
      <div className="flex items-start gap-2.5 rounded-2xl border border-primary/25 bg-primary/8 p-3.5">
        <Sparkles className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
        <p className="text-sm text-muted-foreground">
          Si el equipo te creó una cuenta, te llegó un código a tu correo. Ponelo acá, elegí
          tu contraseña y ya quedás adentro.
        </p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="inv-email">Correo electrónico</Label>
        <Input
          id="inv-email"
          type="email"
          value={email}
          onChange={(event) => setEmail(event.target.value)}
          placeholder="tucorreo@ejemplo.com"
          className="border-white/12 bg-white/4"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="inv-code">Código de invitación</Label>
        <Input
          id="inv-code"
          inputMode="numeric"
          value={code}
          onChange={(event) => setCode(event.target.value.replace(/\D/g, "").slice(0, 6))}
          placeholder="6 dígitos"
          className="border-white/12 bg-white/4 font-mono tracking-[0.3em]"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="inv-password">Elegí tu contraseña</Label>
        <Input
          id="inv-password"
          type="password"
          autoComplete="new-password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          placeholder="Mínimo 8 caracteres"
          className="border-white/12 bg-white/4"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="inv-discord">Usuario de Discord (opcional)</Label>
        <Input
          id="inv-discord"
          value={discord}
          onChange={(event) => setDiscord(event.target.value)}
          placeholder="@usuario"
          className="border-white/12 bg-white/4"
        />
      </div>

      {activate.error && <FormError message={activate.error.message} />}

      <Button
        type="submit"
        className="glow-ring w-full gap-2 font-semibold"
        disabled={
          activate.isPending || !email || code.length !== 6 || password.length < 8
        }
      >
        {activate.isPending ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin" />
            Activando…
          </>
        ) : (
          <>
            Activar mi cuenta
            <ArrowRight className="h-4 w-4" />
          </>
        )}
      </Button>
    </form>
  );
}

/** Paso de código: lo comparten el registro y la activación de invitación. */
function CodeStep({
  email,
  code,
  setCode,
  pending,
  error,
  onConfirm,
  onBack,
  onResend,
  resending,
  title,
  description,
}: {
  email: string;
  code: string;
  setCode: (value: string) => void;
  pending: boolean;
  error?: string;
  onConfirm: () => void;
  onBack: () => void;
  onResend: () => void;
  resending: boolean;
  title: string;
  description: string;
}) {
  return (
    <div className="space-y-5">
      <div className="text-center">
        <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/12 text-primary">
          <Mail className="h-5 w-5" />
        </span>
        <p className="mt-4 font-display text-lg font-bold">{title}</p>
        <p className="mt-1.5 text-sm text-muted-foreground">{description}</p>
      </div>

      <div className="flex justify-center">
        <InputOTP
          maxLength={6}
          value={code}
          onChange={(value) => setCode(value.replace(/\D/g, ""))}
        >
          <InputOTPGroup>
            {[0, 1, 2, 3, 4, 5].map((index) => (
              <InputOTPSlot
                key={index}
                index={index}
                className="h-12 w-11 border-white/12 bg-white/4 text-lg font-bold"
              />
            ))}
          </InputOTPGroup>
        </InputOTP>
      </div>

      {error && <FormError message={error} />}

      <Button
        className="glow-ring w-full gap-2 font-semibold"
        disabled={pending || code.length !== 6}
        onClick={onConfirm}
      >
        {pending ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin" />
            Verificando…
          </>
        ) : (
          <>
            <Check className="h-4 w-4" />
            Confirmar y entrar
          </>
        )}
      </Button>

      <div className="flex flex-col items-center gap-2 text-xs text-muted-foreground">
        <button
          type="button"
          className="inline-flex items-center gap-1.5 text-primary hover:underline disabled:opacity-60"
          onClick={onResend}
          disabled={resending}
        >
          <RefreshCw className={cn("h-3.5 w-3.5", resending && "animate-spin")} />
          Reenviar el código a {email}
        </button>
        <button type="button" className="hover:text-foreground" onClick={onBack}>
          Volver y corregir mis datos
        </button>
      </div>
    </div>
  );
}

function FormError({ message }: { message: string }) {
  return (
    <div className="flex items-start gap-2.5 rounded-2xl border border-destructive/30 bg-destructive/8 p-3.5">
      <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
      <p className="text-sm text-destructive">{message}</p>
    </div>
  );
}

function passwordStrength(password: string): { score: number; label: string } {
  if (password.length < 8) return { score: 1, label: "Muy corta" };
  const hasNumber = /\d/.test(password);
  const hasLetter = /[a-zA-Z]/.test(password);
  const hasSymbol = /[^a-zA-Z0-9]/.test(password);
  const score = 1 + (hasNumber ? 1 : 0) + (hasLetter && hasSymbol ? 1 : 0);
  if (score <= 1) return { score: 1, label: "Débil" };
  if (score === 2) return { score: 2, label: "Aceptable" };
  return { score: 3, label: "Fuerte" };
}
