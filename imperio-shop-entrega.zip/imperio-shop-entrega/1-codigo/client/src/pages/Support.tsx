import { SectionHeading } from "@/components/site/SectionHeading";
import { SiteLayout } from "@/components/site/SiteLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import {
  ArrowRight,
  BadgeCheck,
  Clock,
  CreditCard,
  ExternalLink,
  HelpCircle,
  LifeBuoy,
  MessageCircle,
  Package,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import { Link } from "wouter";

/**
 * Página de soporte.
 *
 * Toda la atención se centraliza en el Discord: ahí abrimos un ticket con el
 * código del pedido y resolvemos dudas de compras, pagos, productos o del
 * funcionamiento de la web. Dejamos a mano los accesos directos para que el
 * cliente llegue al lugar correcto sin dar vueltas.
 */

/** Motivos de consulta que atendemos, con su ícono y qué llevar a mano. */
const MOTIVOS = [
  {
    icon: Package,
    title: "Compras y pedidos",
    detail:
      "Seguimiento de tu pedido, cambios de plan, entregas pendientes o dudas sobre lo que incluye tu compra.",
    llevar: "Tu código de pedido (IMP-XXXXXX)",
  },
  {
    icon: CreditCard,
    title: "Pagos y cobros",
    detail:
      "Un pago que no se acreditó, un cobro duplicado, un reembolso o dudas sobre cómo pagar con tarjeta o PayPal.",
    llevar: "Código de pedido y comprobante del pago",
  },
  {
    icon: Sparkles,
    title: "Productos y servicios",
    detail:
      "Funciones de tu bot, configuración del hosting, cambios en tu web o cualquier ajuste después de la entrega.",
    llevar: "Nombre de tu servicio y qué querés cambiar",
  },
  {
    icon: LifeBuoy,
    title: "Problemas con la web",
    detail:
      "No podés crear tu cuenta, no te llega el código por correo, un error al comprar o algo que se ve mal.",
    llevar: "Qué estabas haciendo y una captura si podés",
  },
];

/** Pasos de la atención, para que se sepa qué esperar. */
const PASOS = [
  {
    title: "Entrás al Discord",
    detail: "Con un clic desde cualquier botón de esta página.",
  },
  {
    title: "Abrís un ticket",
    detail:
      "En el canal de soporte. Escribí tu código de pedido si tu consulta es por una compra.",
  },
  {
    title: "Te responde una persona",
    detail:
      "Siempre contesta el equipo de Imperio Shop, no un robot. Coordinamos y resolvemos.",
  },
  {
    title: "Seguís todo por ahí",
    detail:
      "Te avisamos en el mismo ticket cuando tu pedido avanza o queda entregado.",
  },
];

export default function Support() {
  const { data } = trpc.catalog.list.useQuery(undefined, { staleTime: 60_000 });
  const settings = data?.settings ?? {};
  const discord = settings["contact.discord"] || "https://discord.gg/cffbceYF2";
  const email = settings["contact.email"] || "";
  const ticketMessage = settings["orders.ticketMessage"] || "";
  const supportHours = settings["stats.support"] || "24/7";

  return (
    <SiteLayout>
      {/* Encabezado */}
      <section className="relative overflow-hidden border-b border-white/6">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(60%_60%_at_50%_0%,oklch(0.32_0.09_18/0.35),transparent_70%)]" />
        <div className="container relative py-14 sm:py-20">
          <div className="max-w-3xl">
            <Badge
              variant="outline"
              className="border-primary/30 bg-primary/10 text-primary"
            >
              <LifeBuoy className="mr-1.5 h-3.5 w-3.5" />
              Soporte de Imperio Shop
            </Badge>
            <h1 className="mt-5 font-display text-4xl font-extrabold leading-[1.05] sm:text-5xl">
              Estamos para <span className="text-primary">ayudarte</span>
            </h1>
            <p className="mt-4 max-w-2xl text-base text-muted-foreground sm:text-lg">
              ¿Tuviste un problema con una compra, un pago, un producto o con la
              web? Escribinos y lo resolvemos. Toda la atención se centraliza en
              nuestro Discord, así no perdés tiempo esperando un correo.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-3">
              <a href={discord} target="_blank" rel="noreferrer">
                <Button size="lg" className="gap-2">
                  <MessageCircle className="h-4 w-4" />
                  Abrir ticket en Discord
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </a>
              <Link href="/mis-compras">
                <Button size="lg" variant="outline" className="gap-2">
                  <Package className="h-4 w-4" />
                  Ver mis compras
                </Button>
              </Link>
            </div>

            <div className="mt-6 flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-muted-foreground">
              <span className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-primary" />
                Atención {supportHours}
              </span>
              <span className="flex items-center gap-2">
                <BadgeCheck className="h-4 w-4 text-primary" />
                Respuesta del equipo, no de un robot
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Motivos de consulta */}
      <section className="container py-14 sm:py-18">
        <SectionHeading
          eyebrow="En qué te ayudamos"
          title="Contanos qué te pasó"
          description="Estos son los temas que más nos consultan. Si el tuyo no está en la lista, igual escribinos: siempre contestamos."
        />

        <div className="mt-10 grid gap-5 sm:grid-cols-2">
          {MOTIVOS.map((motivo) => (
            <Card
              key={motivo.title}
              className="surface group rounded-2xl border-0 p-6 transition-colors hover:border-primary/25"
            >
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/12 text-primary">
                <motivo.icon className="h-5 w-5" />
              </span>
              <h3 className="mt-4 font-display text-lg font-bold">{motivo.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{motivo.detail}</p>
              <p className="mt-4 flex items-start gap-2 rounded-xl border border-white/8 bg-white/3 px-3.5 py-2.5 text-xs text-muted-foreground">
                <HelpCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
                <span>
                  <span className="font-medium text-foreground">Llevá a mano:</span>{" "}
                  {motivo.llevar}
                </span>
              </p>
            </Card>
          ))}
        </div>
      </section>

      {/* Cómo funciona la atención */}
      <section className="border-y border-white/6 bg-white/2">
        <div className="container py-14 sm:py-18">
          <SectionHeading
            eyebrow="Cómo funciona"
            title="Tu consulta en cuatro pasos"
            description="Sin formularios largos ni esperas: entrás al Discord, abrís el ticket y te atendemos."
          />

          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {PASOS.map((paso, index) => (
              <Card key={paso.title} className="surface relative rounded-2xl border-0 p-6">
                <span className="font-display text-3xl font-extrabold text-primary/25">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <h3 className="mt-3 font-display text-base font-bold">{paso.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{paso.detail}</p>
              </Card>
            ))}
          </div>

          {ticketMessage && (
            <p className="mt-8 rounded-2xl border border-primary/25 bg-primary/8 px-5 py-4 text-sm text-foreground">
              <span className="font-semibold">Importante:</span>{" "}
              {ticketMessage.replace("{code}", "IMP-XXXXXX")}
            </p>
          )}
        </div>
      </section>

      {/* Bloque de contacto */}
      <section className="container py-14 sm:py-18">
        <Card className="surface overflow-hidden rounded-3xl border-0 p-8 sm:p-10">
          <div className="grid items-center gap-8 lg:grid-cols-[1.4fr_1fr]">
            <div>
              <h2 className="font-display text-2xl font-extrabold sm:text-3xl">
                Abrí tu ticket y lo vemos al toque
              </h2>
              <p className="mt-3 max-w-xl text-sm text-muted-foreground">
                Si tu consulta es por un pago, tené a mano el código de tu pedido
                (lo encontrás en <span className="text-foreground">Mis compras</span>).
                Con eso ubicamos tu caso enseguida.
              </p>

              <div className="mt-6 flex flex-wrap gap-3">
                <a href={discord} target="_blank" rel="noreferrer">
                  <Button className="gap-2">
                    <MessageCircle className="h-4 w-4" />
                    Ir al Discord
                    <ExternalLink className="h-3.5 w-3.5" />
                  </Button>
                </a>
                {email && (
                  <a href={`mailto:${email}`}>
                    <Button variant="outline" className="gap-2">
                      Escribir a {email}
                    </Button>
                  </a>
                )}
              </div>
            </div>

            <div className="space-y-3">
              {[
                {
                  icon: ShieldCheck,
                  title: "Pago protegido",
                  detail:
                    "Los cobros los procesa Tebex, la plataforma de pagos de la comunidad.",
                },
                {
                  icon: BadgeCheck,
                  title: "Queda registrado",
                  detail:
                    "Cada compra y cada consulta queda guardada en tu cuenta y en nuestro panel.",
                },
                {
                  icon: Clock,
                  title: `Atención ${supportHours}`,
                  detail:
                    "Leemos los tickets todos los días y respondemos en cuanto los vemos.",
                },
              ].map((item) => (
                <div
                  key={item.title}
                  className={cn(
                    "flex items-start gap-3 rounded-2xl border border-white/8 bg-white/3 p-4",
                  )}
                >
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-primary/12 text-primary">
                    <item.icon className="h-4 w-4" />
                  </span>
                  <div>
                    <p className="text-sm font-semibold">{item.title}</p>
                    <p className="mt-0.5 text-xs text-muted-foreground">{item.detail}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Card>
      </section>
    </SiteLayout>
  );
}