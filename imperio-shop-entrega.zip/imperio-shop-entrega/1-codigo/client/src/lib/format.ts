import {
  Bot,
  Cloud,
  Cpu,
  Globe,
  LifeBuoy,
  Package,
  Server,
  ShieldCheck,
  Sparkles,
  Wrench,
  type LucideIcon,
} from "lucide-react";

/** Precio en centavos → texto legible. Ej: 3500 → "US$ 35". */
export function formatPrice(cents: number, currency = "USD"): string {
  const value = cents / 100;
  const hasDecimals = Math.round(value * 100) % 100 !== 0;
  const formatted = value.toLocaleString("es-AR", {
    minimumFractionDigits: hasDecimals ? 2 : 0,
    maximumFractionDigits: 2,
  });
  const prefix = currency === "USD" ? "US$" : currency === "ARS" ? "$" : currency;
  return `${prefix} ${formatted}`;
}

/** "US$ 6 / mes" o "US$ 35 pago único". */
export function formatPlanPrice(
  cents: number,
  billing: string,
  currency = "USD",
): string {
  return billing === "monthly"
    ? `${formatPrice(cents, currency)} / mes`
    : `${formatPrice(cents, currency)} pago único`;
}

export function formatDate(value: Date | string | number): string {
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return "-";
  return date.toLocaleString("es-AR", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function formatRelative(value: Date | string | number): string {
  const date = value instanceof Date ? value : new Date(value);
  const diff = Date.now() - date.getTime();
  const minutes = Math.round(diff / 60000);
  if (minutes < 1) return "hace instantes";
  if (minutes < 60) return `hace ${minutes} min`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `hace ${hours} h`;
  const days = Math.round(hours / 24);
  if (days < 30) return `hace ${days} d`;
  return formatDate(date);
}

const ICONS: Record<string, LucideIcon> = {
  bot: Bot,
  server: Server,
  globe: Globe,
  cpu: Cpu,
  lifebuoy: LifeBuoy,
  cloud: Cloud,
  shield: ShieldCheck,
  wrench: Wrench,
  sparkles: Sparkles,
  package: Package,
};

export function iconFor(name: string): LucideIcon {
  return ICONS[name] ?? Package;
}

/* --------------------------- estados de los pedidos ------------------------ */

export const ORDER_STATUS: Record<
  string,
  { label: string; hint: string; tone: string }
> = {
  pending_payment: {
    label: "Pendiente de pago",
    hint: "Esperando que completes el pago en la pantalla de Tebex.",
    tone: "bg-amber-500/12 text-amber-300 border-amber-500/30",
  },
  payment_review: {
    label: "Verificando pago",
    hint: "Estamos revisando tu pago. Suele tardar pocos minutos.",
    tone: "bg-sky-500/12 text-sky-300 border-sky-500/30",
  },
  paid: {
    label: "Pago confirmado",
    hint: "Pago acreditado. Tu pedido entra en producción.",
    tone: "bg-emerald-500/12 text-emerald-300 border-emerald-500/30",
  },
  in_progress: {
    label: "En producción",
    hint: "Estamos trabajando en tu servicio.",
    tone: "bg-primary/12 text-primary border-primary/30",
  },
  delivered: {
    label: "Entregado",
    hint: "Servicio entregado y funcionando.",
    tone: "bg-emerald-500/15 text-emerald-200 border-emerald-500/35",
  },
  cancelled: {
    label: "Cancelado",
    hint: "Este pedido fue cancelado. Escribinos si necesitás ayuda.",
    tone: "bg-destructive/12 text-destructive border-destructive/30",
  },
};

export const ORDER_STATUS_ORDER = [
  "pending_payment",
  "payment_review",
  "paid",
  "in_progress",
  "delivered",
  "cancelled",
] as const;

export function statusInfo(status: string) {
  return (
    ORDER_STATUS[status] ?? {
      label: status,
      hint: "",
      tone: "bg-muted text-muted-foreground border-border",
    }
  );
}
