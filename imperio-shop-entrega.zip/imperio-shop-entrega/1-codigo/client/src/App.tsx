import { OwnerOnly, PanelLayout } from "@/components/panel/PanelLayout";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import Account from "@/pages/Account";
import Home from "@/pages/Home";
import Reviews from "@/pages/Reviews";
import MyOrders from "@/pages/MyOrders";
import NotFound from "@/pages/NotFound";
import Support from "@/pages/Support";
import ServiceDetail from "@/pages/ServiceDetail";
import PanelAccess from "@/pages/panel/Access";
import PanelActivity from "@/pages/panel/Activity";
import PanelCatalog from "@/pages/panel/Catalog";
import PanelCustomers from "@/pages/panel/Customers";
import PanelOrders from "@/pages/panel/Orders";
import PanelOverview from "@/pages/panel/Overview";
import PanelReviews from "@/pages/panel/Reviews";
import PanelSettings from "@/pages/panel/Settings";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/servicio/:slug" component={ServiceDetail} />
      <Route path="/cuenta" component={Account} />
      <Route path="/resenas" component={Reviews} />
      <Route path="/soporte" component={Support} />
      <Route path="/mis-compras" component={MyOrders} />

      <Route path="/panel">
        <PanelLayout>
          <PanelOverview />
        </PanelLayout>
      </Route>
      <Route path="/panel/pedidos">
        <PanelLayout>
          <PanelOrders />
        </PanelLayout>
      </Route>
      <Route path="/panel/clientes">
        <PanelLayout>
          <PanelCustomers />
        </PanelLayout>
      </Route>
      <Route path="/panel/actividad">
        <PanelLayout>
          <PanelActivity />
        </PanelLayout>
      </Route>
      <Route path="/panel/catalogo">
        <PanelLayout>
          <PanelCatalog />
        </PanelLayout>
      </Route>
      <Route path="/panel/configuracion">
        <PanelLayout>
          <OwnerOnly>
            <PanelSettings />
          </OwnerOnly>
        </PanelLayout>
      </Route>
      <Route path="/panel/resenas">
        <PanelLayout>
          <PanelReviews />
        </PanelLayout>
      </Route>
      <Route path="/panel/accesos">
        <PanelLayout>
          <OwnerOnly>
            <PanelAccess />
          </OwnerOnly>
        </PanelLayout>
      </Route>

      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
