import { cn } from "@/lib/utils";

/**
 * Símbolo de Imperio Shop: la corona geométrica sobre el pedestal en T.
 * Es vectorial para que se vea nítido en cualquier tamaño.
 */
export function ImperioMark({
  className,
  size = 40,
  glow = false,
}: {
  className?: string;
  size?: number;
  glow?: boolean;
}) {
  return (
    <svg
      viewBox="0 0 1024 1024"
      width={size}
      height={size}
      role="img"
      aria-label="Imperio Shop"
      className={cn(glow && "drop-shadow-[0_0_18px_rgba(255,31,61,0.55)]", className)}
    >
      <defs>
        <linearGradient id="imperio-mark-red" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#FF2A45" />
          <stop offset="1" stopColor="#F11230" />
        </linearGradient>
      </defs>
      <g
        fill="none"
        stroke="url(#imperio-mark-red)"
        strokeWidth="74"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M212 352 L336 500 L512 214 L688 500 L812 352" />
      </g>
      <g fill="url(#imperio-mark-red)">
        <circle cx="212" cy="352" r="40" />
        <circle cx="512" cy="214" r="40" />
        <circle cx="812" cy="352" r="40" />
      </g>
      <g fill="url(#imperio-mark-red)">
        <rect x="258" y="516" width="508" height="70" rx="4" />
        <rect x="474" y="586" width="76" height="212" rx="3" />
      </g>
      <rect x="282" y="540" width="460" height="22" rx="2" fill="#C60E2A" opacity="0.75" />
    </svg>
  );
}

/** Logo completo: símbolo + nombre + bajada. */
export function ImperioLogo({
  size = 42,
  showTagline = true,
  className,
}: {
  size?: number;
  showTagline?: boolean;
  className?: string;
}) {
  return (
    <span className={cn("flex items-center gap-3", className)}>
      <ImperioMark size={size} glow />
      <span className="flex flex-col leading-none">
        <span className="font-display text-[1.05rem] font-extrabold tracking-tight text-foreground">
          IMPERIO <span className="text-gradient-ember">SHOP</span>
        </span>
        {showTagline && (
          <span className="mt-1 text-[0.6rem] font-medium uppercase tracking-[0.28em] text-muted-foreground">
            Bots · Hosting · Web
          </span>
        )}
      </span>
    </span>
  );
}
