import { useEffect, useState } from "react";
import { BadgeCheck, Clock, Loader2, ShieldCheck, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";

/**
 * Verificación del pago vista desde el panel.
 *
 * Cuando el equipo prueba una compra desde la web y vuelve del checkout de
 * Tebex, mostramos esto: consultamos a Tebex cada pocos segundos y solo damos
 * el pago por bueno cuando Tebex confirma que el dinero llegó. Nunca antes.
 *
 * Al confirmarse, la pantalla queda en "Pago exitoso" hasta que el equipo
 * decida seguir: no se cierra sola, así nadie se pierde la confirmación.
 */
export function PaymentCheckPanel({
  orderCode,
  onFinished,
}: {
  orderCode: string;
  onFinished: () => void;
}) {
  const [segundos, setSegundos] = useState(0);
  const [demorado, setDemorado] = useState(false);
  const utils = trpc.useUtils();

  const check = trpc.admin.orders.checkPayment.useQuery(
    { code: orderCode },
    {
      enabled: Boolean(orderCode),
      // Mientras no haya confirmación, preguntamos seguido. Al confirmarse o
      // quedar sin nada que verificar, dejamos de consultar.
      refetchInterval: (query) => {
        const estado = query.state.data?.status;
        if (estado === "confirmed" || estado === "unavailable") return false;
        return 2500;
      },
      refetchOnWindowFocus: true,
    },
  );

  const estado = check.data?.status;

  // Latido propio: se ve que la verificación sigue viva aunque Tebex tarde.
  useEffect(() => {
    const tic = setInterval(() => setSegundos((s) => s + 1), 1000);
    return () => clearInterval(tic);
  }, []);

  // Si a los 30 segundos todavía no llegó, lo explicamos en lugar de dejar al
  // equipo mirando un spinner sin contexto.
  useEffect(() => {
    if (estado !== "pending") return;
    const t = setTimeout(() => setDemorado(true), 30000);
    return () => clearTimeout(t);
  }, [estado]);

  // Al confirmarse, refrescamos la lista para que el pedido ya figure pagado.
  useEffect(() => {
    if (estado !== "confirmed") return;
    utils.admin.orders.list.invalidate();
    utils.admin.overview.invalidate();
  }, [estado, utils]);

  /* ------------------------------- confirmado ------------------------------ */
  if (estado === "confirmed") {
    return (
      <div className="rounded-2xl border border-emerald-500/35 bg-emerald-500/[0.08] p-6 text-center">
        <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-500/18">
          <BadgeCheck className="h-8 w-8 text-emerald-400" />
        </span>
        <h3 className="mt-3 font-display text-2xl font-black text-emerald-300">Pago exitoso</h3>
        <p className="mt-2 text-sm text-muted-foreground">
          Tebex confirmó que el dinero llegó. El pedido{" "}
          <strong className="text-foreground">{orderCode}</strong> quedó pagado por{" "}
          <strong className="text-foreground">{check.data?.amount}</strong>.
        </p>

        <div className="mt-4 flex flex-wrap items-center justify-center gap-2 text-xs">
          {check.data?.method && (
            <span className="rounded-full border border-white/12 bg-white/4 px-2.5 py-1 text-muted-foreground">
              Método: {check.data.method}
            </span>
          )}
          {check.data?.transactionId && (
            <span className="rounded-full border border-white/12 bg-white/4 px-2.5 py-1 font-mono text-muted-foreground">
              {check.data.transactionId}
            </span>
          )}
          <span className="rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2.5 py-1 font-semibold text-emerald-300">
            Verificado con Tebex
          </span>
        </div>

        <Button size="sm" className="mt-5 gap-2 rounded-full font-semibold" onClick={onFinished}>
          Ver el pedido en el panel
        </Button>
      </div>
    );
  }

  /* -------------------------- nada que verificar --------------------------- */
  if (estado === "unavailable") {
    return (
      <div className="rounded-2xl border border-border/60 bg-card/60 p-6 text-center">
        <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-muted">
          <XCircle className="h-6 w-6 text-muted-foreground" />
        </span>
        <h3 className="mt-3 font-display text-base font-bold">No hay pago que verificar</h3>
        <p className="mt-1.5 text-sm text-muted-foreground">{check.data?.message}</p>
        <Button size="sm" variant="ghost" className="mt-4 rounded-full" onClick={onFinished}>
          Ver el pedido en el panel
        </Button>
      </div>
    );
  }

  /* -------------------------------- esperando ------------------------------ */
  return (
    <div className="rounded-2xl border border-primary/25 bg-primary/[0.05] p-6 text-center">
      <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/15">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </span>
      <h3 className="mt-3 font-display text-lg font-extrabold">
        Esperá un poco mientras verificamos el pago
      </h3>
      <p className="mt-1.5 text-sm text-muted-foreground">
        Estamos confirmando con Tebex que el dinero llegó antes de dar la compra por pagada.
      </p>

      <div className="mx-auto mt-4 flex max-w-sm items-center justify-between rounded-xl border border-border/60 bg-background/40 px-4 py-2.5 text-left">
        <div>
          <p className="text-[11px] uppercase tracking-wider text-muted-foreground">Pedido</p>
          <p className="font-mono text-xs font-bold">{orderCode}</p>
        </div>
        <div className="text-right">
          <p className="text-[11px] uppercase tracking-wider text-muted-foreground">Importe</p>
          <p className="text-xs font-bold">{check.data?.amount ?? "—"}</p>
        </div>
      </div>

      <p className="mt-3 flex items-center justify-center gap-1.5 text-xs text-muted-foreground">
        <Clock className="h-3.5 w-3.5" />
        Verificando… {segundos}s
      </p>

      {demorado && (
        <div className="mt-4 rounded-xl border border-amber-500/25 bg-amber-500/[0.07] p-4 text-left">
          <p className="flex items-center gap-2 text-sm font-semibold">
            <ShieldCheck className="h-4 w-4 text-amber-400" />
            El pago todavía no se acreditó
          </p>
          <p className="mt-1.5 text-xs text-muted-foreground">
            Algunos métodos tardan unos minutos en confirmarse. Seguimos revisando; podés cerrar
            esta pantalla y el estado se actualiza solo en el pedido.
          </p>
        </div>
      )}

      <Button size="sm" variant="ghost" className="mt-4 rounded-full" onClick={onFinished}>
        Seguir revisando después
      </Button>
    </div>
  );
}