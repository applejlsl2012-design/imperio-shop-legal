import { ImperioMark } from "@/components/brand/ImperioLogo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import {
  Activity,
  AlertCircle,
  ArrowLeft,
  BarChart3,
  Boxes,
  Crown,
  KeyRound,
  Loader2,
  LogOut,
  Package,
  Settings,
  ShieldCheck,
  Star,
  Users,
} from "lucide-react";
import { useState } from "react";
import { Link, useLocation } from "wouter";

type PanelPermissions = {
  role: "owner" | "staff";
  isOwner: boolean;
  canManageOrders: boolean;
  canManageCatalog: boolean;
  canViewCustomers: boolean;
  canManageSettings: boolean;
  canManageAccess: boolean;
  canViewLogins: boolean;
};

const PANEL_NAV: {
  href: string;
  label: string;
  icon: typeof BarChart3;
  permission?: keyof PanelPermissions;
  ownerOnly?: boolean;
}[] = [
  { href: "/panel", label: "Resumen", icon: BarChart3 },
  { href: "/panel/actividad", label: "Actividad", icon: Activity, permission: "canViewCustomers" },
  { href: "/panel/pedidos", label: "Pedidos", icon: Package },
  { href: "/panel/clientes", label: "Clientes", icon: Users, permission: "canViewCustomers" },
  { href: "/panel/catalogo", label: "Catálogo", icon: Boxes },
  { href: "/panel/resenas", label: "Reseñas", icon: Star, permission: "canManageCatalog" },
  {
    href: "/panel/configuracion",
    label: "Configuración",
    icon: Settings,
    permission: "canManageSettings",
    ownerOnly: true,
  },
  {
    href: "/panel/accesos",
    label: "Accesos",
    icon: KeyRound,
    permission: "canManageAccess",
    ownerOnly: true,
  },
];

export function PanelLayout({ children }: { children: React.ReactNode }) {
  const session = trpc.admin.session.me.useQuery(undefined, {
    retry: false,
    refetchOnWindowFocus: false,
  });

  if (session.isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }

  if (!session.data?.authenticated) {
    return <StaffLogin />;
  }

  return (
    <div className="min-h-screen bg-[oklch(0.12_0.012_18)]">
      <PanelShell
        label={session.data.label}
        role={session.data.role}
        permissions={session.data.permissions}
      >
        {children}
      </PanelShell>
    </div>
  );
}

function PanelShell({
  children,
  label,
  role,
  permissions,
}: {
  children: React.ReactNode;
  label: string;
  role: string;
  permissions: PanelPermissions;
}) {
  const navItems = PANEL_NAV.filter((item) => {
    if (item.ownerOnly && !permissions.isOwner) return false;
    if (item.permission && !permissions[item.permission]) return false;
    return true;
  });
  const [location, setLocation] = useLocation();
  const utils = trpc.useUtils();
  const logout = trpc.admin.session.logout.useMutation({
    onSuccess: async () => {
      await utils.admin.session.me.invalidate();
      setLocation("/panel");
    },
  });

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-[1500px] flex-col lg:flex-row">
      {/* Barra lateral */}
      <aside className="border-b border-white/8 lg:w-64 lg:shrink-0 lg:border-b-0 lg:border-r">
        <div className="flex items-center justify-between gap-3 p-4 lg:flex-col lg:items-start lg:gap-6 lg:p-5">
          <Link href="/" className="flex items-center gap-3">
            <ImperioMark size={36} glow />
            <span className="flex flex-col leading-none">
              <span className="font-display text-sm font-extrabold">IMPERIO SHOP</span>
              <span className="mt-1 text-[0.6rem] uppercase tracking-[0.22em] text-muted-foreground">
                Panel privado
              </span>
            </span>
          </Link>
        </div>

        <nav className="flex gap-1 overflow-x-auto px-3 pb-3 lg:flex-col lg:overflow-visible lg:px-3 lg:pb-0">
          {navItems.map((item) => {
            const active =
              item.href === "/panel"
                ? location === "/panel"
                : location.startsWith(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex shrink-0 items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-sm font-medium transition-colors",
                  active
                    ? "bg-primary/12 text-primary"
                    : "text-muted-foreground hover:bg-white/5 hover:text-foreground",
                )}
              >
                <item.icon className="h-4 w-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="mt-4 hidden border-t border-white/8 p-4 lg:block">
          <div className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/12 text-xs font-bold text-primary">
              {label.slice(0, 2).toUpperCase()}
            </span>
            <div className="min-w-0">
              <p className="truncate text-sm font-semibold">{label}</p>
              <p className="flex items-center gap-1 text-xs text-muted-foreground">
                {role === "owner" ? (
                  <>
                    <Crown className="h-3 w-3 text-primary" />
                    Dueño · acceso total
                  </>
                ) : (
                  "Socio · pedidos y catálogo"
                )}
              </p>
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            className="mt-4 w-full gap-2 border-white/12 bg-white/4"
            asChild
          >
            <Link href="/">
              <ArrowLeft className="h-3.5 w-3.5" />
              Volver al sitio
            </Link>
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="mt-2 w-full gap-2 border-white/12 bg-white/4"
            onClick={() => logout.mutate()}
            disabled={logout.isPending}
          >
            <LogOut className="h-3.5 w-3.5" />
            Cerrar sesión
          </Button>
        </div>
      </aside>

      {/* Contenido */}
      <main className="min-w-0 flex-1 p-4 sm:p-6 lg:p-8">{children}</main>
    </div>
  );
}

function StaffLogin() {
  const [code, setCode] = useState("");
  const utils = trpc.useUtils();
  const login = trpc.admin.session.login.useMutation({
    onSuccess: async (data) => {
      await utils.admin.session.me.invalidate();
      setCode("");
      // eslint-disable-next-line no-console
      console.log(`Acceso concedido a ${data.label}`);
    },
  });

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden px-4">
      <div
        className="absolute inset-0 -z-10 bg-cover bg-center opacity-40"
        style={{ backgroundImage: "url(/manus-storage/hero-bg_55705e89.jpg)" }}
        aria-hidden
      />
      <div
        className="absolute inset-0 -z-10 bg-[linear-gradient(180deg,oklch(0.11_0.01_18/0.9),oklch(0.11_0.01_18/0.98))]"
        aria-hidden
      />

      <div className="surface w-full max-w-md rounded-3xl p-8">
        <Link
          href="/"
          className="mb-6 inline-flex items-center gap-2 rounded-xl border border-white/12 bg-white/4 px-3.5 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-white/8 hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" />
          Volver al sitio
        </Link>
        <div className="flex flex-col items-center text-center">
          <ImperioMark size={56} glow />
          <h1 className="mt-5 font-display text-2xl font-extrabold">Panel privado</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Acceso exclusivo del equipo de Imperio Shop. Ingresá tu código de acceso.
          </p>
        </div>

        <form
          className="mt-7 space-y-4"
          onSubmit={(event) => {
            event.preventDefault();
            login.mutate({ code });
          }}
        >
          <div className="space-y-2">
            <Label htmlFor="staff-code">Código de acceso</Label>
            <Input
              id="staff-code"
              value={code}
              onChange={(event) => setCode(event.target.value.toUpperCase())}
              placeholder="IMP-XXXX-XXXX"
              autoComplete="off"
              className="border-white/12 bg-white/4 text-center font-mono text-base tracking-[0.18em]"
            />
          </div>

          {login.error && (
            <div className="flex items-start gap-2.5 rounded-2xl border border-destructive/30 bg-destructive/8 p-3.5">
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
              <p className="text-sm text-destructive">{login.error.message}</p>
            </div>
          )}

          <Button
            type="submit"
            className="glow-ring w-full gap-2 font-semibold"
            disabled={login.isPending || code.trim().length < 6}
          >
            {login.isPending ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Verificando…
              </>
            ) : (
              <>
                <ShieldCheck className="h-4 w-4" />
                Ingresar al panel
              </>
            )}
          </Button>
        </form>

        <p className="mt-5 text-center text-xs text-muted-foreground">
          ¿No tenés código? Pedíselo al administrador principal del sitio.
        </p>
      </div>
    </div>
  );
}

export function PanelHeading({
  title,
  description,
  action,
}: {
  title: string;
  description?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex flex-wrap items-start justify-between gap-4">
      <div>
        <h1 className="font-display text-2xl font-extrabold sm:text-3xl">{title}</h1>
        {description && (
          <p className="mt-1.5 max-w-2xl text-sm text-muted-foreground">{description}</p>
        )}
      </div>
      {action}
    </div>
  );
}

export function PanelLoading() {
  return (
    <div className="space-y-4">
      <Skeleton className="h-9 w-56 rounded-xl" />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {Array.from({ length: 4 }).map((_, index) => (
          <Skeleton key={index} className="h-28 rounded-2xl" />
        ))}
      </div>
      <Skeleton className="h-72 rounded-2xl" />
    </div>
  );
}

/**
 * Sección reservada al dueño.
 *
 * Un socio no debe ver esta pantalla: antes intentaba cargarla, el servidor
 * respondía 403 y aparecían errores en la consola. Ahora mostramos un aviso
 * claro y no se dispara ninguna consulta.
 */
export function OwnerOnly({ children }: { children: React.ReactNode }) {
  const session = trpc.admin.session.me.useQuery(undefined, {
    retry: false,
    refetchOnWindowFocus: false,
  });

  if (session.isLoading) {
    return (
      <div className="flex min-h-[40vh] items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }

  if (session.data?.authenticated && !session.data.permissions.isOwner) {
    return (
      <div className="space-y-4">
        <PanelHeading title="Sección reservada" />
        <div className="surface flex items-start gap-3 rounded-2xl p-6">
          <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
          <div>
            <p className="text-sm font-semibold">
              Esta sección es solo para el dueño de la cuenta
            </p>
            <p className="mt-1.5 text-sm text-muted-foreground">
              Tu acceso cubre pedidos y catálogo. Si necesitás entrar acá, pedile al
              dueño principal que te habilite el permiso.
            </p>
            <Link
              href="/panel/pedidos"
              className="mt-4 inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground"
            >
              Ir a pedidos
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
