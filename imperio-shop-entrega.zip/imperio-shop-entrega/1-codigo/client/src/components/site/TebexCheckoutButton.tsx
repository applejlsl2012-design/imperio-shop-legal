import { CreditCard, Loader2 } from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

/**
 * Cobro con Tebex dentro de la propia web.
 *
 * Usa Tebex.js, la herramienta oficial de Tebex: el cliente carga los datos de
 * su tarjeta (o paga con PayPal) en el marco seguro de Tebex, sin salir del
 * sitio. Los datos de la tarjeta nunca pasan por esta web ni por nuestro
 * servidor.
 *
 * Importante: este componente NO da el pago por confirmado. Cuando Tebex avisa
 * que el pago terminó, avisamos al padre, que es quien verifica contra Tebex y
 * consulta el webhook firmado antes de marcar el pedido como pagado.
 */

/** Declaración mínima del objeto global que expone Tebex.js. */
type TebexGlobal = {
  checkout: {
    init: (config: {
      ident: string;
      locale?: string;
      theme?: "light" | "dark" | "auto" | "default";
      defaultPaymentMethod?: number;
      closeOnPaymentComplete?: boolean;
    }) => void;
    launch: () => void;
    on: (evento: string, callback: (event: unknown) => void) => void;
  };
};

declare global {
  interface Window {
    Tebex?: TebexGlobal;
  }
}

/** ¿Ya cargó el script oficial de Tebex? */
function tebexListo(): boolean {
  return typeof window !== "undefined" && Boolean(window.Tebex?.checkout);
}

export function TebexCheckoutButton({
  basketIdent,
  className,
  etiqueta = "Pagar ahora",
  /** Se llama cuando Tebex avisa que el pago terminó. No confirma nada: solo avisa. */
  onPagoCompletado,
  /** Se llama si el pago falla (tarjeta rechazada, fondos insuficientes, etc.). */
  onPagoFallido,
}: {
  basketIdent: string;
  className?: string;
  etiqueta?: string;
  onPagoCompletado?: () => void;
  onPagoFallido?: (detalle: string) => void;
}) {
  // El script de Tebex se carga con `defer`: esperamos a que esté disponible.
  const [cargado, setCargado] = useState(tebexListo());
  const [abriendo, setAbriendo] = useState(false);

  useEffect(() => {
    if (cargado) return;
    let vivo = true;
    // El script puede tardar; revisamos hasta que aparezca.
    const timer = setInterval(() => {
      if (!vivo) return;
      if (tebexListo()) {
        setCargado(true);
        clearInterval(timer);
      }
    }, 250);
    // A los 10 segundos dejamos de insistir.
    const limite = setTimeout(() => clearInterval(timer), 10_000);
    return () => {
      vivo = false;
      clearInterval(timer);
      clearTimeout(limite);
    };
  }, [cargado]);

  // Los avisos de Tebex no confirman el pago: la confirmación real la hace el
  // servidor consultando a Tebex. Acá solo adelantamos la pantalla de espera.
  useEffect(() => {
    if (!cargado || !window.Tebex) return;
    const tebex = window.Tebex;
    const alCompletar = () => onPagoCompletado?.();
    const alFallar = (event: unknown) => {
      const detalle =
        typeof event === "object" && event && "message" in event
          ? String((event as { message?: unknown }).message ?? "")
          : "";
      onPagoFallido?.(detalle);
    };
    tebex.checkout.on("payment:complete", alCompletar);
    tebex.checkout.on("payment:error", alFallar);
    return () => {
      tebex.checkout.on("payment:complete", () => {});
      tebex.checkout.on("payment:error", () => {});
    };
  }, [cargado, onPagoCompletado, onPagoFallido]);

  const pagar = useCallback(() => {
    if (!basketIdent) {
      toast.error("Falta el identificador del pago", {
        description: "Volvé a generar el pedido e intentá de nuevo.",
      });
      return;
    }
    if (!tebexListo() || !window.Tebex) {
      toast.error("La pantalla de pago todavía está cargando", {
        description: "Esperá unos segundos y volvé a intentarlo.",
      });
      return;
    }
    setAbriendo(true);
    try {
      window.Tebex.checkout.init({
        ident: basketIdent,
        locale: "es_ES",
        theme: "dark",
        closeOnPaymentComplete: false,
      });
      window.Tebex.checkout.launch();
    } catch {
      toast.error("No pudimos abrir la pantalla de pago", {
        description: "Recargá la página e intentá de nuevo.",
      });
    } finally {
      // El marco de Tebex ya quedó abierto: soltamos el estado del botón.
      setTimeout(() => setAbriendo(false), 1200);
    }
  }, [basketIdent]);

  return (
    <Button
      type="button"
      onClick={pagar}
      disabled={!cargado || abriendo}
      className={className ?? "w-full gap-2 font-semibold"}
    >
      {!cargado || abriendo ? (
        <>
          <Loader2 className="h-4 w-4 animate-spin" />
          {cargado ? "Abriendo el pago…" : "Cargando el pago…"}
        </>
      ) : (
        <>
          <CreditCard className="h-4 w-4" />
          {etiqueta}
        </>
      )}
    </Button>
  );
}