import { useEffect, useRef, useState } from "react";
import { CheckCircle2, Clock, Loader2, MessageCircle, ShieldCheck, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";

/**
 * Pantalla de verificación del pago.
 *
 * Cuando el cliente vuelve del checkout de Tebex mostramos esto: consultamos
 * el estado real del pago contra Tebex cada pocos segundos hasta confirmarlo.
 * Así el cliente nunca queda con la duda de si el dinero llegó.
 */
export function PaymentVerification({
  orderCode,
  onFinished,
}: {
  orderCode: string;
  onFinished: () => void;
}) {
  // Contador de espera: avanza solo, cada segundo, mientras verificamos.
  const [segundos, setSegundos] = useState(0);
  const [demorado, setDemorado] = useState(false);
  const montado = useRef(Date.now());

  // Consulta periódica: se detiene sola cuando el pago queda confirmado.
  const check = trpc.customer.checkPayment.useQuery(
    { code: orderCode },
    {
      enabled: Boolean(orderCode),
      refetchInterval: (query) => {
        const estado = query.state.data?.status;
        if (estado === "confirmed" || estado === "unavailable") return false;
        // Cada 3 segundos: lo suficiente para que se sienta inmediato sin castigar a Tebex.
        return 3000;
      },
      refetchOnWindowFocus: true,
    },
  );

  const estado = check.data?.status;

  // Latido propio: no depende de que lleguen datos nuevos, así el cliente ve
  // que la verificación sigue viva aunque Tebex todavía no confirme nada.
  useEffect(() => {
    const tic = setInterval(() => {
      setSegundos(Math.round((Date.now() - montado.current) / 1000));
    }, 1000);
    return () => clearInterval(tic);
  }, []);

  // Si a los 30 segundos todavía no llegó, explicamos que puede demorar.
  useEffect(() => {
    if (estado !== "pending") return;
    const t = setTimeout(() => setDemorado(true), 30000);
    return () => clearTimeout(t);
  }, [estado]);

  // Al confirmarse avisamos a la página para que refresque las compras.
  useEffect(() => {
    if (estado === "confirmed") {
      const t = setTimeout(onFinished, 1800);
      return () => clearTimeout(t);
    }
  }, [estado, onFinished]);

  const discord = check.data?.discord ?? "";
  const nextStep = check.data?.nextStep ?? "";

  const abrirDiscord = () => {
    if (!discord) return;
    const url = discord.startsWith("http") ? discord : `https://${discord}`;
    window.open(url, "_blank", "noopener,noreferrer");
  };

  /* ------------------------------ confirmado ------------------------------ */
  if (estado === "confirmed") {
    return (
      <div className="rounded-3xl border border-emerald-500/35 bg-emerald-500/[0.08] p-6 text-center">
        <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-500/18">
          <CheckCircle2 className="h-9 w-9 text-emerald-400" />
        </span>
        <h3 className="mt-4 font-display text-2xl font-black text-emerald-300">Pago exitoso</h3>
        <p className="mt-2 text-sm text-muted-foreground">
          Verificamos con Tebex que el dinero llegó. Tu pago de{" "}
          <strong className="text-foreground">{check.data?.amount}</strong> para el pedido{" "}
          <strong className="text-foreground">{orderCode}</strong> ya quedó registrado en tu cuenta.
        </p>
        {check.data?.method && (
          <p className="mt-1 text-xs text-muted-foreground">Método: {check.data.method}</p>
        )}
        {nextStep && (
          <div className="mt-5 rounded-2xl border border-primary/25 bg-primary/[0.06] p-4 text-left">
            <p className="flex items-center gap-2 text-sm font-semibold">
              <MessageCircle className="h-4 w-4 text-primary" />
              Último paso para arrancar
            </p>
            <p className="mt-1.5 text-sm text-muted-foreground">{nextStep}</p>
            {discord && (
              <Button size="sm" className="mt-3 rounded-full" onClick={abrirDiscord}>
                Abrir ticket en Discord
              </Button>
            )}
          </div>
        )}
        <p className="mt-4 text-xs text-muted-foreground">
          Actualizando tus compras…
        </p>
      </div>
    );
  }

  /* -------------------------- sin pago que verificar ----------------------- */
  if (estado === "unavailable") {
    return (
      <div className="rounded-3xl border border-border/60 bg-card/60 p-6 text-center">
        <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-muted">
          <XCircle className="h-7 w-7 text-muted-foreground" />
        </span>
        <h3 className="mt-4 font-display text-lg font-extrabold">No pudimos verificar el pago</h3>
        <p className="mt-2 text-sm text-muted-foreground">{check.data?.message}</p>
        {discord && (
          <Button size="sm" variant="outline" className="mt-4 rounded-full" onClick={abrirDiscord}>
            Abrir ticket en Discord
          </Button>
        )}
        <Button size="sm" variant="ghost" className="mt-4 rounded-full" onClick={onFinished}>
          Ver mis compras
        </Button>
      </div>
    );
  }

  /* ------------------------------ esperando ------------------------------- */
  return (
    <div className="rounded-3xl border border-primary/25 bg-primary/[0.05] p-6 text-center">
      <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/15">
        <Loader2 className="h-7 w-7 animate-spin text-primary" />
      </span>
      <h3 className="mt-4 font-display text-xl font-extrabold">
        Esperá un poco mientras verificamos tu pago
      </h3>
      <p className="mt-2 text-sm text-muted-foreground">
        Estamos confirmando con Tebex que el dinero llegó correctamente. No cierres esta página.
      </p>

      <div className="mx-auto mt-5 flex max-w-xs items-center justify-between rounded-2xl border border-border/60 bg-background/40 px-4 py-3 text-left">
        <div>
          <p className="text-[11px] uppercase tracking-wider text-muted-foreground">Pedido</p>
          <p className="font-mono text-sm font-bold">{orderCode}</p>
        </div>
        <div className="text-right">
          <p className="text-[11px] uppercase tracking-wider text-muted-foreground">Importe</p>
          <p className="text-sm font-bold">{check.data?.amount ?? "—"}</p>
        </div>
      </div>

      <p className="mt-4 flex items-center justify-center gap-1.5 text-xs text-muted-foreground">
        <Clock className="h-3.5 w-3.5" />
        Verificando… {segundos}s
      </p>

      {demorado && (
        <div className="mt-5 rounded-2xl border border-amber-500/25 bg-amber-500/[0.07] p-4 text-left">
          <p className="flex items-center gap-2 text-sm font-semibold">
            <ShieldCheck className="h-4 w-4 text-amber-400" />
            El pago todavía no se acreditó
          </p>
          <p className="mt-1.5 text-sm text-muted-foreground">
            Algunos métodos (transferencias y pagos en efectivo) tardan unos minutos en confirmarse.
            Seguimos revisando. Si querés adelantarlo, abrí un ticket con tu código{" "}
            <strong className="text-foreground">{orderCode}</strong>.
          </p>
          {discord && (
            <Button size="sm" variant="outline" className="mt-3 rounded-full" onClick={abrirDiscord}>
              Abrir ticket en Discord
            </Button>
          )}
        </div>
      )}

      <p className="mt-4 text-xs text-muted-foreground">
        Podés ir a <strong className="text-foreground">Mis compras</strong> cuando quieras: el estado
        se actualiza solo.
      </p>
      <Button size="sm" variant="ghost" className="mt-3 rounded-full" onClick={onFinished}>
        Ver mis compras igual
      </Button>
    </div>
  );
}
