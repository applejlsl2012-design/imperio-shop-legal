import { SiteFooter } from "@/components/site/SiteFooter";
import { SiteHeader } from "@/components/site/SiteHeader";
import { trpc } from "@/lib/trpc";
import { ArrowUp } from "lucide-react";
import { useEffect, useState } from "react";

export function SiteLayout({ children }: { children: React.ReactNode }) {
  const { data } = trpc.catalog.list.useQuery(undefined, {
    staleTime: 60_000,
  });
  const visit = trpc.orders.visit.useMutation();
  const [showTop, setShowTop] = useState(false);

  // Avisamos al panel qué página se abrió. Se manda una sola vez por visita
  // para no llenar la bitácora con el mismo movimiento repetido.
  useEffect(() => {
    const path = `${window.location.pathname}${window.location.search}`;
    const key = `imperio-visit:${path}`;
    if (sessionStorage.getItem(key)) return;
    sessionStorage.setItem(key, "1");
    visit.mutate({ path, referrer: document.referrer.slice(0, 300) });
    // Solo debe ejecutarse al montar el layout.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 800);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1 pt-16 sm:pt-18">{children}</main>
      <SiteFooter
        settings={data?.settings}
        services={(data?.services ?? []).map((s) => ({ name: s.name, slug: s.slug }))}
      />
      {showTop && (
        <button
          type="button"
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          aria-label="Volver arriba"
          className="fixed bottom-6 right-6 z-40 flex h-11 w-11 items-center justify-center rounded-full border border-white/12 bg-[oklch(0.2_0.02_18/0.9)] text-foreground backdrop-blur transition-colors hover:border-primary/50 hover:text-primary"
        >
          <ArrowUp className="h-4 w-4" />
        </button>
      )}
    </div>
  );
}
