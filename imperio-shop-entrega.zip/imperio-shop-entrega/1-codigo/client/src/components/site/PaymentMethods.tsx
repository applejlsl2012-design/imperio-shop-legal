import { CreditCard, MessageCircle } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Botones de los métodos de pago que acepta la tienda.
 *
 * Los métodos son los mismos que Tebex tiene activados en su checkout: tarjetas
 * (Visa, Mastercard, JCB y American Express), Google Pay y PayPal.
 * La lista se puede ajustar desde el panel (Configuración → Métodos de pago),
 * así nunca mostramos una opción que la pasarela no acepte.
 *
 * Importante: acá no se cobra nada. El cliente elige con qué quiere pagar y el
 * cobro ocurre después, en la pantalla segura de Tebex. Los datos de la tarjeta
 * nunca pasan por esta web.
 */

/** Logotipo de PayPal, dibujado con las letras de su marca. */
function PayPalLogo() {
  return (
    <span className="font-display text-lg font-black italic tracking-tight">
      <span style={{ color: "#003087" }}>Pay</span>
      <span style={{ color: "#009cde" }}>Pal</span>
    </span>
  );
}

/** Logotipo de Google Pay: la G de colores y el nombre. */
function GooglePayLogo() {
  return (
    <span className="flex items-center gap-2">
      <svg viewBox="0 0 24 24" className="h-5 w-5" aria-hidden>
        <path
          fill="#4285F4"
          d="M21.6 12.23c0-.71-.06-1.4-.18-2.05H12v3.88h5.38a4.6 4.6 0 0 1-2 3.02v2.51h3.24c1.9-1.75 2.98-4.32 2.98-7.36Z"
        />
        <path
          fill="#34A853"
          d="M12 22c2.7 0 4.96-.9 6.62-2.41l-3.24-2.51c-.9.6-2.05.96-3.38.96-2.6 0-4.8-1.76-5.59-4.12H3.06v2.59A10 10 0 0 0 12 22Z"
        />
        <path
          fill="#FBBC05"
          d="M6.41 13.92a6 6 0 0 1 0-3.84V7.49H3.06a10 10 0 0 0 0 9.02l3.35-2.59Z"
        />
        <path
          fill="#EA4335"
          d="M12 5.96c1.47 0 2.79.51 3.83 1.5l2.87-2.87C16.95 2.99 14.7 2 12 2A10 10 0 0 0 3.06 7.49l3.35 2.59C7.2 7.72 9.4 5.96 12 5.96Z"
        />
      </svg>
      <span className="font-display text-base font-black">Google Pay</span>
    </span>
  );
}

/** Tarjetas: las cuatro marcas que acepta el checkout de Tebex. */
function CardLogo() {
  return (
    <span className="flex items-center gap-2.5">
      <CreditCard className="h-5 w-5 text-foreground" />
      <span className="font-display text-base font-black">Tarjetas</span>
      <span className="flex items-center gap-1">
        <span className="h-4 w-6 rounded-[3px] bg-[#1a1f71] text-center text-[8px] font-black leading-4 text-white">
          VISA
        </span>
        <span className="relative flex h-4 w-6 items-center justify-center rounded-[3px] bg-[#f7f7f7]">
          <span className="absolute left-[5px] h-2.5 w-2.5 rounded-full bg-[#eb001b]" />
          <span className="absolute left-[9px] h-2.5 w-2.5 rounded-full bg-[#f79e1b]" />
        </span>
        <span className="h-4 w-6 rounded-[3px] bg-[#0b4ea2] text-center text-[7px] font-black leading-4 text-white">
          JCB
        </span>
        <span className="h-4 w-6 rounded-[3px] bg-[#2e77bc] text-center text-[7px] font-black leading-4 text-white">
          AMEX
        </span>
      </span>
    </span>
  );
}

/** Pago coordinado por ticket: el que siempre está disponible. */
function ManualLogo() {
  return (
    <span className="flex items-center gap-2">
      <MessageCircle className="h-5 w-5" />
      <span className="font-display text-base font-black">Pago por ticket</span>
    </span>
  );
}

type Metodo = {
  id: string;
  /** Clases de la caja: acá vive el color de cada marca. */
  caja: string;
  /** Color del brillo al pasar el cursor: el de la propia marca. */
  glow: string;
  logo: React.ReactNode;
  /** Nombre para lectores de pantalla y para el resumen del pago. */
  nombre: string;
  /**
   * ¿Se puede usar hoy? Cuando la pasarela todavía no habilita el cobro, los
   * botones de pago en línea se muestran igual (para que el cliente sepa con
   * qué va a poder pagar) pero quedan marcados como no disponibles.
   */
  siempreDisponible?: boolean;
};

/**
 * Los métodos que la tienda puede mostrar. El orden es el que ve el cliente:
 * primero lo más usado.
 */
const METODOS: Metodo[] = [
  {
    id: "tarjetas",
    caja: "border-white/12 bg-[oklch(0.28_0.012_18)] text-foreground",
    glow: "#1a1f71",
    logo: <CardLogo />,
    nombre: "Tarjeta de crédito o débito",
  },
  {
    id: "googlepay",
    caja: "border-white/20 bg-white text-[#3c4043]",
    glow: "#4285f4",
    logo: <GooglePayLogo />,
    nombre: "Google Pay",
  },
  {
    id: "paypal",
    caja: "border-white/20 bg-white text-[#003087]",
    glow: "#009cde",
    logo: <PayPalLogo />,
    nombre: "PayPal",
  },
  {
    id: "ticket",
    caja: "border-white/12 bg-[oklch(0.22_0.012_18)] text-foreground",
    glow: "#ff1f3d",
    logo: <ManualLogo />,
    nombre: "Pago coordinado por ticket",
    siempreDisponible: true,
  },
];

/** Métodos activos por defecto: los que Tebex tiene habilitados hoy. */
export const METODOS_POR_DEFECTO = "tarjetas,googlepay,paypal";

/**
 * Lee del panel qué métodos mostrar.
 *
 * Si la configuración viene vacía o con nombres desconocidos, mostramos los de
 * Tebex: es preferible mostrar de más (el checkout filtra) que dejar al cliente
 * sin saber con qué puede pagar.
 */
function leerActivos(config: string | undefined): Set<string> {
  const ids = (config ?? "")
    .split(",")
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
  if (ids.length === 0) return new Set(METODOS.map((m) => m.id));
  const validos = new Set(METODOS.map((m) => m.id));
  const activos = new Set(ids.filter((id) => validos.has(id)));
  // El ticket siempre queda disponible como respaldo.
  activos.add("ticket");
  return activos;
}

export function PaymentMethods({
  canCharge,
  activos,
  className,
  onElegir,
  elegido,
}: {
  /** ¿La pasarela ya puede cobrar hoy? Si no, lo aclaramos sin ocultar nada. */
  canCharge: boolean;
  /** Métodos activados en la configuración del sitio, separados por coma. */
  activos?: string;
  className?: string;
  /**
   * Si se pasa, los botones se pueden tocar para elegir con qué se paga. El
   * cobro siempre ocurre después en la pantalla segura de la pasarela: acá solo
   * registramos la preferencia del cliente.
   */
  onElegir?: (id: string, nombre: string) => void;
  /** Método elegido, para marcarlo visualmente. */
  elegido?: string | null;
}) {
  const seleccionable = Boolean(onElegir);
  const habilitados = leerActivos(activos);
  const visibles = METODOS.filter((m) => habilitados.has(m.id));

  return (
    <div className={cn("space-y-3", className)}>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        {visibles.map((metodo) => {
          const activo = elegido === metodo.id;
          // Cuando el cobro todavía no está habilitado, solo el ticket sirve.
          const usable = canCharge || metodo.siempreDisponible;
          const caja = cn(
            "pay-btn flex w-full items-center justify-center rounded-xl border px-6 py-4 shadow-[0_2px_0_rgba(0,0,0,0.25)]",
            metodo.caja,
            activo && "ring-2 ring-primary ring-offset-2 ring-offset-[oklch(0.17_0.014_18)]",
            // Lo que todavía no se puede usar pierde fuerza visual, no se esconde.
            !usable && "opacity-45",
          );
          // Cada botón se enciende con el color de su marca al pasar el cursor.
          const estilo = { "--glow": metodo.glow } as React.CSSProperties;
          if (!seleccionable) {
            return (
              <span key={metodo.id} className={caja} style={estilo}>
                {metodo.logo}
              </span>
            );
          }
          return (
            <button
              key={metodo.id}
              type="button"
              aria-label={`Pagar con ${metodo.nombre}`}
              aria-pressed={activo}
              onClick={() => onElegir?.(metodo.id, metodo.nombre)}
              style={estilo}
              className={cn(caja, "cursor-pointer")}
            >
              {metodo.logo}
            </button>
          );
        })}
      </div>

      <p className="text-xs text-muted-foreground">
        {canCharge
          ? "Elegís el método y completás el pago en la pantalla segura de Tebex. Los datos de tu tarjeta nunca pasan por esta web."
          : "El cobro en línea se está terminando de habilitar: muy pronto vas a poder pagar con estos métodos. Mientras tanto, coordinamos el pago por Discord con tu código de pedido."}
      </p>
    </div>
  );
}
