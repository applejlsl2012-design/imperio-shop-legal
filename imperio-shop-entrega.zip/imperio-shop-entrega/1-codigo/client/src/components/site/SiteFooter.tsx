import { ImperioLogo } from "@/components/brand/ImperioLogo";
import { DiscordIcon } from "@/components/brand/DiscordIcon";
import { Mail, MessageCircle, ShieldCheck, Zap } from "lucide-react";
import { Link } from "wouter";

type Settings = Record<string, string>;

export function SiteFooter({
  settings = {},
  services = [],
}: {
  settings?: Settings;
  services?: { name: string; slug: string }[];
}) {
  const discord = settings["contact.discord"] ?? "";
  const email = settings["contact.email"] ?? "";
  const whatsapp = settings["contact.whatsapp"] ?? "";
  const provider = settings["payment.provider"] ?? "Tebex";

  return (
    <footer className="relative mt-24 border-t border-white/8 bg-[oklch(0.12_0.012_18)]">
      <div className="pointer-events-none absolute inset-x-0 -top-px h-px hairline" />
      <div className="container grid gap-12 py-14 lg:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
        <div className="max-w-sm">
          <ImperioLogo size={40} />
          <p className="mt-5 text-sm leading-relaxed text-muted-foreground">
            {settings["brand.description"] ??
              "Creamos bots de Discord, hosting, servidores y páginas web para comunidades y emprendimientos."}
          </p>
          <div className="mt-6 flex flex-wrap gap-3 text-xs text-muted-foreground">
            <span className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/4 px-3 py-1.5">
              <ShieldCheck className="h-3.5 w-3.5 text-primary" />
              Pago seguro con {provider}
            </span>
            <span className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/4 px-3 py-1.5">
              <Zap className="h-3.5 w-3.5 text-primary" />
              Entrega rápida
            </span>
          </div>
          {discord && (
            <a
              href={discord}
              target="_blank"
              rel="noreferrer"
              className="mt-6 inline-flex items-center gap-2.5 rounded-xl border border-[#5865F2]/45 bg-[#5865F2]/15 px-4 py-3 text-sm font-semibold text-foreground transition-colors hover:border-[#5865F2]/70 hover:bg-[#5865F2]/25"
            >
              <DiscordIcon className="h-4.5 w-4.5 text-[#8b95f7]" />
              Unirse al Discord
            </a>
          )}
        </div>

        <div>
          <h3 className="font-display text-sm font-semibold uppercase tracking-[0.2em] text-foreground">
            Servicios
          </h3>
          <ul className="mt-5 space-y-3 text-sm">
            {services.length > 0 ? (
              services.slice(0, 6).map((service) => (
                <li key={service.slug}>
                  <Link
                    href={`/servicio/${service.slug}`}
                    className="text-muted-foreground transition-colors hover:text-primary"
                  >
                    {service.name}
                  </Link>
                </li>
              ))
            ) : (
              <li className="text-muted-foreground">Cargando catálogo…</li>
            )}
          </ul>
        </div>

        <div>
          <h3 className="font-display text-sm font-semibold uppercase tracking-[0.2em] text-foreground">
            Ayuda
          </h3>
          <ul className="mt-5 space-y-3 text-sm">
            <li>
              <a
                href="/#como-comprar"
                className="text-muted-foreground transition-colors hover:text-primary"
              >
                Cómo comprar
              </a>
            </li>
            <li>
              <a
                href="/#faq"
                className="text-muted-foreground transition-colors hover:text-primary"
              >
                Preguntas frecuentes
              </a>
            </li>
            <li>
              <Link
                href="/resenas"
                className="text-muted-foreground transition-colors hover:text-primary"
              >
                Reseñas de clientes
              </Link>
            </li>
            <li>
              <Link
                href="/soporte"
                className="text-muted-foreground transition-colors hover:text-primary"
              >
                Soporte y ayuda
              </Link>
            </li>
            <li>
              <Link
                href="/panel"
                className="text-muted-foreground transition-colors hover:text-primary"
              >
                Panel privado
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h3 className="font-display text-sm font-semibold uppercase tracking-[0.2em] text-foreground">
            Contacto
          </h3>
          <ul className="mt-5 space-y-3 text-sm">
            {discord && (
              <li>
                <a
                  href={discord}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 text-muted-foreground transition-colors hover:text-primary"
                >
                  <MessageCircle className="h-4 w-4" />
                  Servidor de Discord
                </a>
              </li>
            )}
            {email && (
              <li>
                <a
                  href={`mailto:${email}`}
                  className="inline-flex items-center gap-2 text-muted-foreground transition-colors hover:text-primary"
                >
                  <Mail className="h-4 w-4" />
                  {email}
                </a>
              </li>
            )}
            {whatsapp && (
              <li>
                <a
                  href={whatsapp}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 text-muted-foreground transition-colors hover:text-primary"
                >
                  <MessageCircle className="h-4 w-4" />
                  WhatsApp
                </a>
              </li>
            )}
          </ul>
        </div>
      </div>

      <div className="border-t border-white/8">
        <div className="container flex flex-col items-center justify-between gap-3 py-6 text-xs text-muted-foreground sm:flex-row">
          <p>
            © {new Date().getFullYear()} {settings["brand.name"] ?? "Imperio Shop"}. Todos los
            derechos reservados.
          </p>
          <p>
            Los pagos se procesan de forma externa mediante{" "}
            <span className="font-medium text-foreground/80">{provider}</span>
            .
          </p>
        </div>
      </div>
    </footer>
  );
}
