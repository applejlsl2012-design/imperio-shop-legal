import { ImperioLogo } from "@/components/brand/ImperioLogo";
import { DiscordIcon } from "@/components/brand/DiscordIcon";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";
import { Lock, Menu, ShoppingBag, UserRound } from "lucide-react";
import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";

const NAV = [
  { label: "Servicios", href: "/#servicios" },
  { label: "Precios", href: "/#precios" },
  { label: "Cómo comprar", href: "/#como-comprar" },
  { label: "Reseñas", href: "/resenas" },
  { label: "Soporte", href: "/soporte" },
  { label: "Contacto", href: "/#contacto" },
];

export function SiteHeader() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [location] = useLocation();
  const { data } = trpc.catalog.list.useQuery(undefined, { staleTime: 60_000 });
  const discord = data?.settings["contact.discord"] ?? "";
  const session = trpc.customer.me.useQuery(undefined, {
    retry: false,
    refetchOnWindowFocus: false,
  });
  const account = session.data?.authenticated ? session.data.customer : null;

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [location]);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-300",
        scrolled
          ? "border-b border-white/8 bg-[oklch(0.13_0.012_18/0.88)] backdrop-blur-xl"
          : "border-b border-transparent bg-transparent",
      )}
    >
      <div className="container flex h-16 items-center justify-between gap-4 sm:h-18">
        <Link href="/" className="shrink-0">
          <ImperioLogo size={38} />
        </Link>

        <nav className="hidden items-center gap-1 lg:flex">
          {NAV.map((item) =>
            item.href.startsWith("/#") ? (
              <a
                key={item.href}
                href={item.href}
                className="rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-white/5 hover:text-foreground"
              >
                {item.label}
              </a>
            ) : (
              <Link
                key={item.href}
                href={item.href}
                className="rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-white/5 hover:text-foreground"
              >
                {item.label}
              </Link>
            ),
          )}
        </nav>

        <div className="flex items-center gap-2">
          <Link
            href="/panel"
            className="hidden items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-white/5 hover:text-foreground sm:flex"
          >
            <Lock className="h-3.5 w-3.5" />
            Panel
          </Link>
          {account ? (
            <Link
              href="/mis-compras"
              className="hidden items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-white/5 hover:text-foreground sm:flex"
            >
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary/15 text-[0.6rem] font-bold text-primary">
                {account.name.slice(0, 2).toUpperCase()}
              </span>
              Mis compras
            </Link>
          ) : (
            <Link
              href="/cuenta"
              className="hidden items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-white/5 hover:text-foreground sm:flex"
            >
              <UserRound className="h-3.5 w-3.5" />
              Ingresar
            </Link>
          )}
          {discord && (
            <a
              href={discord}
              target="_blank"
              rel="noreferrer"
              className="hidden items-center gap-2 rounded-lg border border-[#5865F2]/45 bg-[#5865F2]/15 px-3 py-2 text-sm font-semibold text-foreground transition-colors hover:border-[#5865F2]/70 hover:bg-[#5865F2]/25 md:flex"
            >
              <DiscordIcon className="h-4 w-4 text-[#8b95f7]" />
              Unirse al Discord
            </a>
          )}
          <a href="/#servicios" className="hidden sm:block">
            <Button size="sm" className="glow-ring gap-2 font-semibold">
              <ShoppingBag className="h-4 w-4" />
              Ver precios
            </Button>
          </a>

          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="lg:hidden"
                aria-label="Abrir menú"
              >
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent
              side="right"
              className="w-[86vw] max-w-sm border-white/10 bg-[oklch(0.15_0.014_18)] p-0"
            >
              <div className="flex h-full flex-col">
                <div className="border-b border-white/8 px-5 py-5">
                  <ImperioLogo size={36} />
                </div>
                <nav className="flex flex-col gap-1 p-4">
                  {NAV.map((item) =>
                    item.href.startsWith("/#") ? (
                      <a
                        key={item.href}
                        href={item.href}
                        onClick={() => setOpen(false)}
                        className="rounded-xl px-4 py-3 text-base font-medium text-foreground/90 transition-colors hover:bg-white/5"
                      >
                        {item.label}
                      </a>
                    ) : (
                      <Link
                        key={item.href}
                        href={item.href}
                        onClick={() => setOpen(false)}
                        className="rounded-xl px-4 py-3 text-base font-medium text-foreground/90 transition-colors hover:bg-white/5"
                      >
                        {item.label}
                      </Link>
                    ),
                  )}
                  <Link
                    href="/panel"
                    onClick={() => setOpen(false)}
                    className="flex items-center gap-2 rounded-xl px-4 py-3 text-base font-medium text-foreground/90 transition-colors hover:bg-white/5"
                  >
                    <Lock className="h-4 w-4" />
                    Panel privado
                  </Link>
                  <Link
                    href={account ? "/mis-compras" : "/cuenta"}
                    onClick={() => setOpen(false)}
                    className="flex items-center gap-2 rounded-xl px-4 py-3 text-base font-medium text-foreground/90 transition-colors hover:bg-white/5"
                  >
                    <UserRound className="h-4 w-4" />
                    {account ? `Mis compras (${account.name.split(" ")[0]})` : "Ingresar o crear cuenta"}
                  </Link>
                </nav>
                <div className="mt-auto p-4">
                  {discord && (
                    <a
                      href={discord}
                      target="_blank"
                      rel="noreferrer"
                      onClick={() => setOpen(false)}
                      className="mb-3"
                    >
                      <Button
                        variant="outline"
                        className="w-full gap-2 border-[#5865F2]/45 bg-[#5865F2]/15 font-semibold"
                      >
                        <DiscordIcon className="h-4 w-4 text-[#8b95f7]" />
                        Unirse al Discord
                      </Button>
                    </a>
                  )}
                  <a href="/#servicios" onClick={() => setOpen(false)}>
                    <Button className="glow-ring w-full font-semibold">
                      Ver servicios y precios
                    </Button>
                  </a>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
