# Integración Tebex — notas técnicas

Fuente: https://docs.tebex.io/creators y https://docs.tebex.io/developers (consultado 2026-09-27)

## Qué es

Tebex es la plataforma de pagos (merchant of record) para comunidades de gaming.
La web crea una canasta y manda al cliente a un checkout seguro alojado por Tebex.
Tebex procesa PayPal, tarjetas y +120 métodos locales, cobra las comisiones y liquida al comercio.

## Métodos de pago relevantes

**Importante:** por defecto TODOS los métodos vienen activados, excepto Paysafecard
(requiere aprobación aparte). Se administran en el panel:
**Payments → Payment Methods** (https://creator.tebex.io/payment-methods), con interruptores
por método. Ahí mismo se ve, por método: países, monedas, comisión de pasarela,
tiempo de liquidación y si soporta suscripciones.

Globales: PayPal (USD, EUR, GBP, CAD, AUD, PLN), Credit/Debit Cards (idem), Pay With Crypto,
Razer Gold (PIN y wallet), oBucks (gift card), Paysafecard (con aprobación).

Argentina: **PagoFacil** (ARS) y **RapiPago** (ARS).
Chile: WebPay, MACH, Servipag, Sencillito (CLP).
Colombia: Efecty, Nequi, PSE, ViaBaloto (COP).
México: Mercado Pago MX, OXXO, SPEI (MXN).
Brasil: Mercado Pago, Boleto, Pix, PicPay, Bradesco (BRL).
Perú: PagoEfectivo (PEN); SafetyPay (varios de LatAm).

Lista completa con comisiones: https://creator.tebex.io/payment-methods
Lista pública: https://www.tebex.io/payment-methods

## Cómo llega el dinero (4 etapas)

1. **El cliente paga** → se descuentan comisión de pasarela + comisión de plataforma
   y se disparan las entregas automáticas (nuestro webhook).
2. **Liquidación en la Wallet de Tebex** → promedio 14 días (varía por método).
   Los fondos quedan en `wallet.tebex.io` hasta liquidarse.
3. **Retiro** → desde el saldo liquidado, mínimo USD 5. Métodos:
   - PayPal: mínimo $5, 1–2 días hábiles, comisión fija baja (el más barato).
   - Transferencia bancaria: mínimo ~$20, hasta 7 días.
   - Wire: mínimo ~$50, 5–10 días, £12 por transferencia.
4. **El dinero llega** a la cuenta de PayPal o banco.

Restricciones a tener en cuenta:
- Un método de retiro nuevo tiene 5 días de retención.
- Solo se puede cambiar el método una vez cada 30 días por moneda.
- Un retiro cada 24 h; el primero tiene tope de USD 1.000.
- Los retiros pueden pasar por revisión de compliance (HyperWallet): +1–2 días.

**Recomendación:** usar PayPal como método de retiro (más rápido y barato).
Configurar en **Control Panel → Payments → Wallet**.

## URLs verificadas del panel

- Panel de creador: https://creator.tebex.io/ (la ruta `/login` NO existe; la raíz
  redirige al SSO de accounts.tebex.io)
- Métodos de pago: https://creator.tebex.io/payment-methods
- Wallet y retiros: https://wallet.tebex.io/withdraw
- Paquetes: https://creator.tebex.io/packages
- Claves de API y webhooks: sección **Developers** del panel
- Checkout (configuración): Settings → Checkout

Ojo: el acceso está detrás de Cloudflare con verificación humana. Hay que iniciar
sesión manualmente en el navegador; no se puede automatizar.

## Credenciales necesarias

| Dato | Uso | Formato |
| --- | --- | --- |
| Public Token | Va en la URL de la API. No es secreto. | 4 caracteres + guion, ej. `spk3-d515a30...` |
| Private Key | Acceso total a la cuenta. Solo en el servidor. | string largo |
| Webhook Secret | Valida la firma de los webhooks. | string hex |

Base URL de la API Headless: `https://headless.tebex.io/api/accounts/{PUBLIC_TOKEN}`

Regla: la mayoría de endpoints NO requieren autorización. Cuando se necesita,
es HTTP Basic con usuario = Public Token y contraseña = Private Key.
La Private Key NUNCA debe ir en el código del navegador.

## Flujo de compra

1. **Crear la canasta** — `POST /baskets`
   ```json
   {
     "complete_url": "https://dominio.com/mis-compras?pago=ok",
     "cancel_url": "https://dominio.com/servicio/slug",
     "complete_auto_redirect": true,
     "custom": { "orderCode": "IMP-XXXXXX" }
   }
   ```
   `custom` viaja de vuelta en los webhooks: sirve para atar el pago a nuestro pedido.

2. **Agregar el paquete** — `POST /baskets/{basket_ident}/packages`
   con el `package_id` y `quantity`.

3. **Enviar al cliente al pago** — usar `links.checkout` de la respuesta.

4. **Confirmación** — llega el webhook `payment.completed`.

## Webhooks

Configurar en **Developers > Webhooks > Endpoints** del panel de Tebex.

- Al agregar el endpoint, Tebex manda `validation.webhook` y exige responder
  `200 OK` con `{ "id": "<id del webhook>" }`.
- Firma: header `X-Signature` = HMAC-SHA256( SHA256(cuerpo crudo JSON), webhookSecret ).
  Hay que usar el cuerpo CRUDO, no el JSON ya parseado.
- IPs de origen: `18.209.80.3` y `54.87.231.232`.

Eventos: `payment.completed`, `payment.declined`, `payment.refunded`,
`payment.dispute.opened`, `recurring-payment.started/.renewed/.ended`, `validation.webhook`.

Status IDs útiles: 1 = Complete, 2 = Refund, 3 = Chargeback, 18 = Declined,
19 = Pending Checkout, 21 = Refund Pending.

## Estado de la implementación en Imperio Shop

Ya construido y probado (33 pruebas en verde, sin errores de tipos):

- `server/tebex.ts` — cliente de la API: crear canasta, agregar paquete, leer canasta,
  verificar firma del webhook, helpers de origen público e IP real del visitante.
- `server/tebexWebhook.ts` — endpoint `POST /api/tebex/webhook`, registrado ANTES del
  parser de JSON (guarda el cuerpo crudo para poder validar la firma). Responde la
  validación inicial y actualiza el pedido con `payment.completed/declined/refunded`.
- `server/_core/env.ts` — variables `TEBEX_PUBLIC_TOKEN`, `TEBEX_PRIVATE_KEY`,
  `TEBEX_WEBHOOK_SECRET`.
- `drizzle/schema.ts` — `plans.tebexPackageId` y en `orders`: `tebexBasketIdent`,
  `tebexTransactionId`, `tebexPaymentMethod`. `paymentMethod` por defecto = `tebex`.
  Migración aplicada: `drizzle/0006_narrow_tattoo.sql`.
- `server/routers.ts` — al confirmar la compra crea el checkout de Tebex y devuelve
  `checkoutUrl`; si el plan no tiene paquete, el cobro queda manual.
- `client/src/pages/ServiceDetail.tsx` — botón "Pagar ahora" que lleva al checkout
  seguro de Tebex; los textos manuales solo aparecen si no hay checkout.
- `client/src/pages/panel/Catalog.tsx` — campo "Paquete de Tebex" por plan.
- `client/src/pages/Home.tsx` — bloque con los métodos de pago disponibles.

## Credenciales cargadas (27/09)

Las claves de la cuenta quedaron cargadas como secretos del proyecto y
**validadas contra la API real** (prueba `server/tebex.credentials.test.ts`:
crea canastas, lee canastas y autoriza consultas Basic con la Private Key):

- `TEBEX_PUBLIC_TOKEN` → identifica la tienda en la API Headless.
- `TEBEX_PRIVATE_KEY` → consultas autenticadas (solo servidor).
- `TEBEX_WEBHOOK_SECRET` → pendiente, se completa al crear el endpoint.

Datos de la cuenta: Project ID **1901648**, cuenta `tienda@imperioshopp.com`,
proyecto "Imperio Shop" (plan FIVEM | PLUS PLAN TRIAL).

## Pendientes

1. **Vincular planes ↔ paquetes** — el usuario está creando/ajustando los
   paquetes en Tebex y avisa cuando estén listos para mapearlos. Los paquetes
   actuales (Bot Básico $8, Bot Avanzado $16, Bot Pro $28) no coinciden con los
   planes del sitio, y Hosting y Páginas Web aún no tienen paquete.
   El campo a completar es `plans.tebexPackageId` (se edita desde el panel del
   sitio, en Catálogo → editar plan → "Paquete de Tebex").
2. **Webhook** — crear el endpoint en Tebex → Integrations → Webhooks apuntando
   a `https://<dominio>/api/tebex/webhook`, copiar el secreto y cargarlo como
   `TEBEX_WEBHOOK_SECRET`. Tebex manda `validation.webhook` al guardar y el
   endpoint ya responde como corresponde.
3. **Aprobación de Tebex** — el proyecto está al 33% y sigue en modo prueba:
   *"You can only checkout using test payment methods until your project is
   setup & approved by our Content and Safety team."* Hay que completar los
   pasos de onboarding (contacto de soporte, Wallet, Cfx.re, storefront,
   entrega y primer paquete) y enviar a revisión. Recién ahí los pagos reales
   (Visa, PayPal, etc.) quedan operativos para los clientes.
4. **Métodos de pago del sitio** — el inicio lista Mercado Pago, Pago Fácil,
   RapiPago, Paysafecard y Cripto, que hoy están desactivados en el panel.
   Los activos son Credit/Debit Cards (Visa/Master/Google Pay/Apple Pay),
   PayPal, Pay by Bank y MACH. Conviene alinear el texto cuando el usuario
   confirme qué métodos deja habilitados.

## Enlaces de referencia

- Docs creadores: https://docs.tebex.io/creators
- Índice completo: https://docs.tebex.io/creators/sitemap.md
- Cómo funcionan los pagos: https://docs.tebex.io/creators/tebex-checkout/how-payments-work.md
- Retiros: https://docs.tebex.io/creators/tebex-checkout/fund-withdrawals-and-transfers.md
- Métodos de pago: https://docs.tebex.io/creators/tebex-control-panel/payments-overview/payment-methods.md
- Paquetes: https://docs.tebex.io/creators/tebex-control-panel/how-to-create-packages.md
- API Headless: https://docs.tebex.io/developers
- Webhooks: https://docs.tebex.io/developers/webhooks/overview.md
