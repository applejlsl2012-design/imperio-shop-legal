# Estado real de la integración con Tebex

Documento de trabajo con los hallazgos verificados contra la API real.

## Datos de la tienda actual

- Tienda: **Imperio Shop** (`imperio-shop.tebex.store`)
- ID de proyecto: `1901648`
- `platform_type`: **FiveM** (platform_type_id 15)
- `disabled`: **true**
- Moneda: USD
- La webstore pública responde **503 Store unavailable** (por estar deshabilitada).

## Por qué no se puede cobrar hoy

1. **Es un proyecto de tipo FiveM.** Ese tipo obliga al comprador a iniciar
   sesión con una cuenta de Cfx.re/FiveM antes de agregar cualquier producto a
   la canasta. La API responde:
   `422 User must login before adding packages to basket`.
   Los clientes de bots de Discord, hosting y webs no tienen esa cuenta.
2. **La tienda está deshabilitada** (`disabled: true`), así que la webstore da 503.
3. **La private key no es de un servidor plugin**: `plugin.tebex.io` responde
   `403 No server could be found with the specified secret key`.

Para vender bots/hosting/web hace falta un proyecto de tipo **Universal**,
activo, con Stripe y PayPal conectados.

## Rutas de la API verificadas

| Ruta | Resultado |
| --- | --- |
| `GET /api/accounts/{token}` | 200 · datos de la tienda (incluye `platform_type`, `disabled`) |
| `GET /api/accounts/{token}/packages` | 200 · 9 paquetes |
| `GET /api/accounts/{token}/categories` | 200 |
| `POST /api/accounts/{token}/baskets` | 200 · crea la canasta |
| `GET /api/accounts/{token}/baskets/{ident}` | 200 · estado de la canasta |
| `POST /api/baskets/{ident}/packages` | **422** · exige login (FiveM) |
| `POST /api/accounts/{token}/baskets/{ident}/packages` | 404 · ruta inexistente |
| `GET /api/accounts/{token}/baskets/{ident}/auth` | 200 · devuelve proveedor FiveM |
| `GET /api/accounts/{token}/payments` | 404 · no existe |

La Headless API **no expone los métodos de pago habilitados**. Los datos de la
tarjeta se cargan siempre en la pantalla de pago de Tebex, nunca en la web.

## Paquetes actuales (9)

Bot Básico `7700329` · Bot Avanzado `7700426` · Bot Pro `7700432` ·
Hosting `7700744` · Web Basic `7700788` · Web Advanced `7702701` ·
Web Pro `7702717` · Web Ultimate `7702719` · Unban `7711501`

## Documentación consultada

- https://docs.tebex.io/developers/headless-api/guides/baskets/authorize-a-basket
- https://docs.tebex.io/developers/headless-api/endpoints.md
- https://docs.tebex.io/developers/headless-api/authorization

## Lo que hace la web hoy

- `getTebexStatus()` consulta el estado de la tienda (con 5 min de caché) y
  decide si se puede cobrar.
- Si **no** se puede cobrar: el pedido se registra sin crear canasta, la web
  avisa con honestidad y ofrece abrir ticket en Discord.
- Si **sí** se puede cobrar: crea la canasta, y si Tebex exige login devuelve el
  enlace de autorización para retomar el pago después.
- La verificación del pago consulta la canasta real; solo confirma cuando Tebex
  la marca completa o llega un webhook firmado.
