# Imperio Shop — Entrega completa

Bots de Discord, hosting y desarrollo web. Todo el proyecto en una sola carpeta.

---

## Qué hay en cada carpeta

### `1-codigo/` — El sitio completo
Todo el código fuente del sitio, listo para subir a GitHub.

- `client/` → la web que ve el cliente (inicio, servicios, precios, reseñas, soporte, cuenta, mis compras)
- `server/` → el backend (pedidos, pagos con Tebex, correo, panel privado)
- `drizzle/` → la base de datos
- `client/src/pages/panel/` → el panel privado de los dueños
- `package.json` → los comandos para ejecutarlo

**Cómo ejecutarlo en tu computadora:**
```bash
pnpm install     # instala todo (una sola vez)
pnpm dev         # abre el sitio en http://localhost:3000
```

---

### `2-videos/` — Demostraciones
- `video-compra-completa.mp4` → el proceso de compra de punta a punta, con narración (3:03)
- `video-registro-de-cuentas.mp4` → cómo un cliente crea su cuenta con el código, con narración (2:35)

---

### `3-imagenes/` — Gráficos
- `donde-paga-el-cliente.png` → diagrama que explica dónde carga la tarjeta el cliente

---

### `4-documentacion/` — Notas técnicas
- `1-que-falta-para-cobrar.md` → **lo más importante**: qué falta para que el dinero llegue de verdad
- `2-notas-tecnicas-tebex.md` → cómo está armada la integración de pagos
- `3-estado-de-la-tienda.md` → el estado del proyecto en Tebex

---

## Estado del sitio

**Terminado y funcionando.** Todo verificado:

| Área | Estado |
|---|---|
| Inicio, servicios, precios, cómo comprar, reseñas, soporte, contacto | Funciona |
| Cuenta, registro por código, recuperar contraseña, mis compras | Funciona |
| Panel privado (8 secciones, solo dueños) | Funciona |
| Compra con Tebex y confirmación del pago | Funciona |
| Métodos de pago visibles | Solo los activos: tarjetas, Google Pay, PayPal y ticket |

---

## Lo que falta hacer (depende de vos)

### 1. Verificación de identidad en Tebex — **el paso más importante**
Tebex exige verificar quién cobra antes de habilitar los pagos reales. Se hace desde el panel de Tebex con **Onfido**: aceptás los términos, escaneás un QR con el celular, subís un documento (DNI, pasaporte o licencia) y una selfie. Hay que ser mayor de 18 años.

**Después:** en Tebex, ir a **Settings → Checkout → Test Mode** y desactivarlo.

Hasta que hagas esto, el checkout muestra una pantalla de prueba y **no descuenta dinero de verdad**. Cuando lo completes, el cobro real empieza a funcionar solo, sin tocar el código.

### 2. Publicar la web y conectar el dominio
Subí el código a GitHub, publicá el sitio y conectá `imperioshopp.com`.

### 3. Cargar el webhook en Tebex
En Tebex → Webhooks, apuntar a:
```
https://tudominio.com/api/tebex/webhook
```
Con los eventos: **pago completado**, **pago rechazado** y **pago reembolsado**.

### 4. Configurar el correo
Hoy no hay ningún correo configurado, así que los códigos de registro y de recuperar contraseña **no salen por email**. Hay que cargar una de estas opciones:
- **Gmail** → usuario + contraseña de aplicación
- **Resend** → clave de API + remitente verificado
- **SMTP propio** → los datos del servidor de correo de tu dominio

Mientras tanto, los códigos quedan visibles en **Panel → Clientes** para que puedas usarlos.

---

## Tu cuenta

`angelvicente1298@gmail.com` figura activa pero **sin contraseña**, por eso no podías entrar. Para arreglarlo:

1. En la web, andá a **Ingresar** y tocá **"Olvidé mi contraseña"**
2. Pedí el código con tu correo
3. Como el correo aún no está configurado, el código aparece en **Panel → Clientes**
4. Usá ese código para definir tu contraseña nueva

---

## Acceso al panel privado

Se entra desde **/panel** con un código tipo `IMP-XXXX-XXXX`. Solo lo tienen los dueños. El código de dueño se administra desde **Panel → Accesos**.

---

## Precios del catálogo

| Servicio | Planes |
|---|---|
| Bots de Discord | Bot Básico US$ 8 · Bot Avanzado US$ 16 · Bot Pro US$ 28 |
| Hosting de Bots | Hosting Bot Dedicado US$ 5 por mes |
| Desarrollo Web | Web Basic US$ 30 · Web Advanced US$ 60 · Web Pro US$ 80 · Web Ultimate US$ 155 |

Todo se puede editar desde **Panel → Catálogo**.
